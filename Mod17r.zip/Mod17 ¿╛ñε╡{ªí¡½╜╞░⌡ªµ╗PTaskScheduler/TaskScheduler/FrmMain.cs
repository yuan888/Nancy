﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data.SqlClient;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading;
using System.Windows.Forms;

namespace TaskScheduler
{
    public partial class FrmMain : Form
    {
        private SqlConnection cn;
        private string production, watchDirectory, cc, logFile, logJsonFile;
        private BindingSource source = new BindingSource();
        private SortableBindingList<TaskItem> tasks = null;

        public FrmMain()
        {
            InitializeComponent();
            SetFormSizeAuto(this, 960, 700);
        }

        /// <summary>
        /// 訊息等級
        /// </summary>
        private enum MessageLevel
        {
            /// <summary>
            /// 資訊，僅紀錄，不發EMail。
            /// </summary>
            Info,

            /// <summary>
            /// 通知，紀錄且發EMail。
            /// </summary>
            Notify,

            /// <summary>
            /// 錯誤，紀錄且發EMail。
            /// </summary>
            Error
        }

        private void DgvSchedule_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == dgvSchedule.Columns["colExecute"].Index)
            {
                TaskItem task = tasks.Where(t => t.Name == dgvSchedule.Rows[e.RowIndex].Cells[0].Value.ToString() && !t.InProgress).FirstOrDefault();

                if (task != null)
                {
                    ScheduleItem si = new ScheduleItem() { Time = DateTime.Now.ToString("HHmm"), Auto = "N" };

                    if (task.Schedule == null) task.Schedule = new List<ScheduleItem>();
                    task.Schedule.Add(si);
                    si.TaskResult = Result.InProgress;
                    RunTask(task, si);
                }
            }
        }

        private void DgvSchedule_RowPrePaint(object sender, DataGridViewRowPrePaintEventArgs e)
        {
            if (e.RowIndex < 0) return;
            if (dgvSchedule.Rows.Count <= e.RowIndex) return;

            var row = dgvSchedule.Rows[e.RowIndex];

            if (row.Cells[4].Value.ToString() != "")
            {
                row.DefaultCellStyle.BackColor = row.Cells[4].Value.ToString() == "Red" ? Color.Red : Color.Yellow;
            }
            else
            {
                row.DefaultCellStyle.BackColor = Color.White;
            }

            if (row.Selected)
            {
                row.DefaultCellStyle.SelectionBackColor = Color.FromArgb(250, 240, 229);
                row.DefaultCellStyle.SelectionForeColor = Color.Black;
            }
        }

        private void FrmMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            SerializeTaskObject();
            ShowMessage(MessageLevel.Info, "主程式關閉。");
        }

        private void FrmMain_Load(object sender, EventArgs e)
        {
            //Log設定
            Directory.CreateDirectory(Environment.CurrentDirectory + "\\Logs");
            logFile = Environment.CurrentDirectory + "\\Logs\\" + DateTime.Now.ToString("yyyyMMdd") + ".log";
            logJsonFile = Environment.CurrentDirectory + "\\Logs\\" + DateTime.Now.ToString("yyyyMMdd") + "Json.log";

            //將今日執行紀錄還原
            if (File.Exists(logFile))
            {
                try
                {
                    rtbMessage.AppendText(File.ReadAllText(logFile));
                }
                catch (Exception ex)
                {
                    ShowMessage(MessageLevel.Error, $"將今日執行紀錄還原發生錯誤，錯誤訊息為{ex.ToString()}");
                }
            }

            ShowMessage(MessageLevel.Info, "主程式啟動。");

            //程式設定
            production = ConfigurationManager.AppSettings["Production"] ?? "";
            watchDirectory = ConfigurationManager.AppSettings["WatchDirectory"] ?? "";
            cc = ConfigurationManager.AppSettings["CC"] ?? "";

            if (production == "Y") cn = new SqlConnection("Data Source=Production;Initial Catalog=BI;User ID=sa;Password=megasa;Min Pool Size=5;Max Pool Size=100");
            else cn = new SqlConnection("Data Source=WMTEST;Initial Catalog=BI;User ID=sa;Password=megasa;Min Pool Size=5;Max Pool Size=100");

            //工作排程式設定
            List<TaskItem> taskList = new List<TaskItem>();

#if DEBUG
            //測試
            taskList.Add(new TaskItem()
            {
                Name = nameof(Etf),
                Description = "ETF基金資料轉檔",
                Program = new Etf(),
                Schedule = new List<ScheduleItem>() {
                    new ScheduleItem() { Time = "1720" } }
            });
            taskList.Add(new TaskItem()
            {
                Name = nameof(EtfAsset),
                Description = "ETF淨資產價值轉檔",
                Program = new EtfAsset(),
                Type = TaskType.File,
                File = "123.txt",
                //解決不知檔案沒有傳送過來，增加此時間排程，
                //時間過了0833，沒有檔案傳送過來，其警示等級就為紅色。
                Schedule = new List<ScheduleItem>() {
                    new ScheduleItem() { Time = "0833" } }
            });
#else
            //正式
            taskList.Add(new TaskItem()
            {
                Name = nameof(ETFAsset),
                Description = "ETF股票處置注意轉檔",
                Program = new ETFAsset(),
                Type = TaskType.File,
                File = "EFCTRLCV.csv",
                //解決不知檔案沒有傳送過來，增加此時間排程，
                //時間過了0833，沒有檔案傳送過來，其警示等級就為紅色。
                Schedule = new List<ScheduleItem>() {
                    new ScheduleItem() { Time = "0833" } }
            });
#endif

            taskList.Add(new TaskItem()
            {
                Name = nameof(SendTaskResult),
                Description = "排程結果寄送",
                Program = new SendTaskResult(taskList, cc),
                Schedule = new List<ScheduleItem>() {
                    new ScheduleItem() { Time = "0835" },
                    new ScheduleItem() { Time = "2345" } }
            });

            //設定排程類型為即時，排程執行時間。
            foreach (var task in taskList.Where(t => t.Type == TaskType.RealTime).Select(t => t))
            {
                if (task.Schedule == null) task.Schedule = new List<ScheduleItem>();
                task.Schedule.Add(new ScheduleItem() { Time = DateTime.Now.AddMinutes(1).ToString("HHmm") });
            }

            //DataGridView設定
            source.DataSource = tasks = new SortableBindingList<TaskItem>(taskList);
            dgvSchedule.AutoGenerateColumns = false;
            dgvSchedule.Columns["colDesc"].Frozen = true;
            dgvSchedule.DataSource = source;

            //檔案觸發目錄設定
            if (watchDirectory != "" && Directory.Exists(watchDirectory))
            {
                FileSystemWatcher watcher = new FileSystemWatcher();
                DirectoryInfo di = new DirectoryInfo(Path.Combine(watchDirectory, "Backup"));

                watcher.Path = watchDirectory;
                watcher.NotifyFilter = NotifyFilters.FileName | NotifyFilters.LastWrite;
                watcher.Filter = "*.*";
                watcher.IncludeSubdirectories = false;
                watcher.Changed += new FileSystemEventHandler(WatcherOnChanged);
                watcher.EnableRaisingEvents = true;
                Text += "：監控目錄 " + watchDirectory;

                if (!di.Exists) di.Create();
            }

            //Timer設定
            System.Timers.Timer timer = new System.Timers.Timer();

            timer.Interval = 20000;
            timer.Elapsed += new System.Timers.ElapsedEventHandler(Timer_Elapsed);
            timer.Enabled = true;

            //將排程進度反序列化
            if (File.Exists(logJsonFile))
            {
                try
                {
                    foreach (var logTask in (from ti in JsonConvert.DeserializeObject<List<TaskItem>>(File.ReadAllText(logJsonFile))
                                             where ti.Schedule != null
                                             from si in ti.Schedule
                                             where si.TaskResult == Result.Failure || si.TaskResult == Result.Success
                                             select new { Name = ti.Name, Schedule = si })
                                       )
                    {
                        foreach (var currTask in tasks.Where(ti => ti.Name == logTask.Name).Select(ti => ti))
                        {
                            ScheduleItem currSI = null;

                            if (currTask.Type != TaskType.File)
                            {
                                currSI = currTask.Schedule?.Where(s => s.Time == logTask.Schedule.Time).FirstOrDefault();
                            }
                            else
                            {
                                //尋找在設定的時間點（currTask.Schedule[].Time）往前十五分鐘內，
                                //是否有已執行完成的排程（logTask.Schedule.Time），
                                //如果有，此排程（不會實際執行）為預防檔案沒有傳送過來的警示排程，
                                //其正確執行時間為logTask.Schedule.Time。
                                currSI = currTask.Schedule?.Where(
                                    si => si.Time.CompareTo(logTask.Schedule.Time) >= 0 &&
                                    DateTime.ParseExact(si.Time, "HHmm", CultureInfo.InvariantCulture).AddMinutes(-15).ToString("HHmm").CompareTo(logTask.Schedule.Time) <= 0
                                    ).FirstOrDefault();
                                if (currSI != null) currSI.Time = logTask.Schedule.Time;
                            }

                            if (currSI != null) currSI.TaskResult = logTask.Schedule.TaskResult;
                            else
                            {
                                if (currTask.Schedule == null) currTask.Schedule = new List<ScheduleItem>();
                                currTask.Schedule.Add(logTask.Schedule);
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    ShowMessage(MessageLevel.Error, $"排程進度反序列化失敗，錯誤訊息為{ex.ToString()}");
                }
            }

            //Log保留30天
            foreach (var file in (from o in Directory.GetFiles(Environment.CurrentDirectory + "\\Logs", "*.log", SearchOption.TopDirectoryOnly)
                                  let x = new FileInfo(o)
                                  where x.LastWriteTime < DateTime.Now.AddDays(-30)
                                  select o))
            {
                File.Delete(file);
            }
        }

        private void RunTask(TaskItem ti, ScheduleItem si)
        {
            try
            {
                BackgroundWorker bw = new BackgroundWorker();
                System.Diagnostics.Stopwatch watch = new System.Diagnostics.Stopwatch();

                bw.WorkerReportsProgress = true;

                bw.DoWork += (sender, e) =>
                {
                    if (ti.Type == TaskType.File)
                    {
                        Action act1 = () =>
                        {
                            ShowMessage(MessageLevel.Info, "檔案：" + ti.File + " 發生異動，等待5秒後開始轉檔。");
                        };

                        Invoke(act1);
                        Thread.Sleep(5000);
                    }

                    Action act2 = () =>
                    {
                        ShowMessage(MessageLevel.Info, $"排程 {ti.Description} 開始執行。");
                    };

                    Invoke(act2);
                    watch.Start();
                    ti.Program.Start(bw, si, Path.Combine(watchDirectory, ti.File), cn);
                };

                bw.ProgressChanged += (sender, e) =>
                {
                    si.Progress = e.ProgressPercentage;
                    ShowMessage(MessageLevel.Info, $"排程 {ti.Description} 執行進度{e.ProgressPercentage}%。");
                    dgvSchedule.Refresh();
                };

                bw.RunWorkerCompleted += (sender, e) =>
                {
                    watch.Stop();
                    ti.InProgress = false;

                    if (e.Error == null)
                    {
                        si.TaskResult = Result.Success;
                        ShowMessage(MessageLevel.Info, $"排程 {ti.Description} 執行完成，花費 " +
                            Math.Round((decimal)watch.ElapsedMilliseconds / 1000, 0, MidpointRounding.AwayFromZero).ToString() + " 秒。");

                        //當si.Message不為空白時，會寄出通知EMail。
                        if (si.Message != "") ShowMessage(MessageLevel.Notify, ti, si);
                    }
                    else
                    {
                        //當背景所執行的程式有Exception（不管是程式throw，或者是程式發生錯誤）時，會寄出錯誤EMail。
                        si.TaskResult = Result.Failure;
                        if (e.Error is CustomException) si.Message = e.Error.Message;
                        else si.Message = e.Error.ToString();
                        ShowMessage(MessageLevel.Error, ti, si);
                    }

                    dgvSchedule.Refresh();
                    SerializeTaskObject();

                    if (ti.Type == TaskType.File)
                    {
                        FileInfo fi = new FileInfo(Path.Combine(watchDirectory, ti.File));

                        try
                        {
                            if (fi.Exists) File.Move(Path.Combine(watchDirectory, ti.File),
                                Path.Combine(watchDirectory, ti.File).Replace(ti.File, @"Backup\" + ti.File.Replace(fi.Extension, "") + DateTime.Now.ToString("_yyyyMMddHHmmss") + fi.Extension));
                        }
                        catch (Exception ex)
                        {
                            si.Message = $"檔案 {ti.File} 無法備份，錯誤訊息為{ex.ToString()}";
                            ShowMessage(MessageLevel.Error, ti, si);
                        }
                    }
                };

                ShowMessage(MessageLevel.Info, $"排程 {ti.Description} 開始執行。");
                si.TaskResult = Result.InProgress;
                si.Progress = 0;
                ti.InProgress = true;
                dgvSchedule.Refresh();
                watch.Start();
                bw.RunWorkerAsync();
            }
            catch (Exception ex)
            {
                si.Message = ex.ToString();
                ShowMessage(MessageLevel.Error, ti, si);
            }
        }

        private void SerializeTaskObject()
        {
            //將排程進度序列化
            using (StreamWriter sw = File.CreateText(logJsonFile))
            {
                sw.WriteLine(JsonConvert.SerializeObject(tasks, Formatting.Indented));
            }
        }

        private void SetControlSizeAuto(Control container)
        {
            foreach (Control c in container.Controls)
            {
                if (c is DataGridView)
                {
                    DataGridView dgv = c as DataGridView;
                    int widthFill = 0, widthAllCells = 0;

                    dgv.ScrollBars = ScrollBars.Vertical;
                    dgv.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

                    for (int i = 0; i < dgv.Columns.Count; i++)
                    {
                        widthFill += dgv.Columns[i].Width;
                    }

                    for (int i = 0; i < dgv.Columns.Count; i++)
                    {
                        //將每一列都調整為自動適應模式
                        dgv.AutoResizeColumn(i, DataGridViewAutoSizeColumnMode.AllCells);
                        widthAllCells += dgv.Columns[i].Width;
                    }

                    dgv.Width += widthAllCells - widthFill;
                }

                if (c.Controls.Count != 0) SetControlSizeAuto(c);
            }
        }

        private void SetFormSizeAuto(Form form, int designWidth, int designHeight)
        {
            if (form.Width == designWidth && form.Height == designHeight) return;

            float rateW = (float)designWidth / form.Width, rateH = (float)designHeight / form.Height;

            form.Location = new Point((int)(form.Location.X * rateW), (int)(form.Location.Y * rateH));
            form.Size = new Size((int)(form.Size.Width * rateW), (int)(form.Size.Height * rateH));

            if (form.Controls.Count != 0) SetControlSizeAuto(form);
        }

        private void ShowMessage(MessageLevel level, string message, TaskItem ti, ScheduleItem si)
        {
            //秀訊息
            if (level != MessageLevel.Info && ti != null)
            {
                message = "排程 " + ti.Description + " {0}，{1}" + (si != null ? si.Message : message);

                if (level == MessageLevel.Error) message = string.Format(message, "發生錯誤", Environment.NewLine);
                else message = string.Format(message, "通知", "");
            }

            message = $"{DateTime.Now.ToString("HH:mm:ss")} [{level.ToString()}]{"".PadLeft(6 - level.ToString().Length)}：{message}";
            rtbMessage.AppendText(message + Environment.NewLine);
            rtbMessage.SelectionStart = rtbMessage.Text.Length;
            rtbMessage.ScrollToCaret();

            //紀錄Log
            try
            {
                using (StreamWriter sw = File.AppendText(logFile))
                {
                    sw.WriteLine(message);
                }
            }
            catch (Exception)
            {
            }

            //發送EMail
            if (level != MessageLevel.Info)
            {
                string subject = "", from = "", to = "";

                if (ti != null && si != null)
                {
                    from = ti.MailFrom;
                    to = ti.MailTo;

                    if (level == MessageLevel.Error)
                    {
                        string format = @"<table border='1' cellpadding='5' cellspacing='0' style=""font-family:'微軟正黑體'"">
<tr><td>名稱</td><td>{0}</td></tr>
<tr><td>敘述</td><td>{1}</td></tr>
<tr><td>類型</td><td>{2}</td></tr>
<tr><td style='width:78px;'>執行時間</td><td>{3}</td></tr>
<tr style='background-color:#ffecec'><td>訊息</td><td>{4}</td></tr></table>";

                        subject = $"金商中後台 排程發生錯誤：{ti.Description}";
                        message = string.Format(format, ti.Name, ti.Description, ti.Type.ToFriendlyString(), si.Time + (si.Auto != "N" ? "" : "，手動"), si.Message.Replace("\r\n", "<br />"));
                    }
                    else
                    {
                        if (string.IsNullOrWhiteSpace(to)) return;
                        subject = $"金商中後台 排程通知：{ti.Description}";
                        message = si.Message;
                    }
                }
                else
                {
                    subject = "金商中後台 排程程式" + (level == MessageLevel.Error ? "發生錯誤：" : "通知：");
                    from = "";
                    to = cc;
                    cc = "";
                }

                try
                {
                    Module.SendEMail(subject, message, from, to, cc);
                }
                catch (Exception ex)
                {
                    ShowMessage(MessageLevel.Info, ex.ToString());
                }
            }
        }

        private void ShowMessage(MessageLevel level, string message)
        {
            ShowMessage(level, message, null, null);
        }

        private void ShowMessage(MessageLevel level, TaskItem ti, ScheduleItem si)
        {
            ShowMessage(level, "", ti, si);
        }

        private void Timer_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
        {
            string hhmm = DateTime.Now.ToString("HHmm");

            if (hhmm.CompareTo("2350") >= 0)
            {
                Action act = () =>
                {
                    Close();
                };

                Invoke(act);
            }

            foreach (var task in (from t in tasks
                                  where t.Type != TaskType.File && !t.InProgress
                                  from si in t.Schedule
                                  where si.TaskResult == Result.Not && si.Time.CompareTo(hhmm) == 0
                                  select new { Task = t, Schedule = si }))
            {
                Action act = () =>
                {
                    RunTask(task.Task, task.Schedule);
                };

                Invoke(act);
            }
        }

        private void WatcherOnChanged(object source, FileSystemEventArgs e)
        {
            foreach (var task in tasks.Where(t => t.Type == TaskType.File && t.File.ToLower() == e.Name.ToLower() && !t.InProgress).Select(t => t))
            {
                ScheduleItem si = null;

                if (task.Schedule != null)
                {
                    //尋找在目前時間點往後十五分鐘內，是否有指定時間的排程（並不會實際執行），
                    //如果有，當此排程過了指定時間，檔案沒有傳送過來，其警示等級就為紅色。
                    si = task.Schedule.FirstOrDefault(s => DateTime.Now.ToString("HHmm").CompareTo(s.Time) <= 0 && DateTime.Now.AddMinutes(15).ToString("HHmm").CompareTo(s.Time) >= 0);
                    if (si != null) si.Time = DateTime.Now.ToString("HHmm");
                }
                else
                {
                    task.Schedule = new List<ScheduleItem>();
                }

                if (si == null)
                {
                    si = new ScheduleItem() { Time = DateTime.Now.ToString("HHmm") };

                    task.Schedule.Add(si);
                }

                si.TaskResult = Result.InProgress;

                Action act = () =>
                {
                    RunTask(task, si);
                };

                Invoke(act);
            }
        }
    }
}