﻿using System.ComponentModel;
using System.DirectoryServices;
using System.Net.Mail;
using System.Reflection;

namespace TaskScheduler
{
    internal static class Module
    {
        public static string GetEMailAddress(string empNo)
        {
            DirectorySearcher searcher = new DirectorySearcher("LDAP://bisc.com.tw");

            searcher.PropertiesToLoad.Add("mail");
            searcher.Filter = "(SAMAccountName=" + empNo + ")";

            string email = "";
            SearchResult user = searcher.FindOne();

            if (user != null) email = user.Properties["mail"][0].ToString();
            searcher.Dispose();

            return email;
        }

        public static void SendEMail(string subject, string message, string from = "", string to = "", string cc = "", bool bodyHtml = true)
        {
            MailMessage Mail = new MailMessage();
            SmtpClient smtp = new SmtpClient("10.0.4.32");

            Mail.From = new MailAddress(string.IsNullOrWhiteSpace(from) ? "TaskScheduler@megasec.com.tw" : from);
            Mail.Subject = subject;
            Mail.Body = message;
            Mail.IsBodyHtml = bodyHtml;

            if (!string.IsNullOrWhiteSpace(to))
            {
                foreach (string email in to.Split(';'))
                {
                    if (email.Trim() != "") Mail.To.Add(email);
                }
            }

            if (!string.IsNullOrWhiteSpace(cc))
            {
                foreach (string email in cc.Split(';'))
                {
                    if (email.Trim() != "") Mail.CC.Add(email);
                }
            }

            smtp.Credentials = new System.Net.NetworkCredential("apperror@bisc.com.tw", "apperror");
            smtp.Send(Mail);
        }

        public static string ToFriendlyString(this Result value)
        {
            return ToFriendlyString<Result>(value);
        }

        public static string ToFriendlyString(this TaskType value)
        {
            return ToFriendlyString<TaskType>(value);
        }

        private static string ToFriendlyString<T>(T value)
        {
            DescriptionAttribute[] attrAry = (DescriptionAttribute[])(
                value.GetType().GetField(value.ToString())
                .GetCustomAttributes(typeof(DescriptionAttribute), false));

            return attrAry != null ? attrAry[0].Description : value.ToString();
        }
    }
}