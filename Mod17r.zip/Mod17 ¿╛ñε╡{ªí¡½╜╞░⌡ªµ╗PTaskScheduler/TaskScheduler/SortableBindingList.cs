﻿using System;
using System.Collections.Generic;
using System.ComponentModel;

namespace TaskScheduler
{
    public class SortableBindingList<T> : BindingList<T>
    {
        private readonly Dictionary<string, PropertyComparer<T>> _comparerList = new Dictionary<string, PropertyComparer<T>>();
        private PropertyDescriptor _property;
        private ListSortDirection _sortDirection;

        public SortableBindingList()
            : base(new List<T>())
        {
        }

        public SortableBindingList(IList<T> List)
            : base(List)
        {
        }

        public SortableBindingList(IEnumerable<T> Enumerable)
            : base(new List<T>(Enumerable))
        {
        }

        protected override bool IsSortedCore
        {
            get { return true; }
        }

        protected override ListSortDirection SortDirectionCore
        {
            get { return _sortDirection; }
        }

        protected override PropertyDescriptor SortPropertyCore
        {
            get { return _property; }
        }

        protected override bool SupportsSortingCore
        {
            get { return true; }
        }

        protected override void ApplySortCore(PropertyDescriptor property, ListSortDirection direction)
        {
            List<T> itemsList = (List<T>)Items;

            if (property.PropertyType.GetInterface("IComparable") != null)
            {
                itemsList.Sort((x, y) =>
                {
                    if (property.GetValue(x) != null)
                        return ((IComparable)property.GetValue(x)).CompareTo(property.GetValue(y)) *
                               (direction == ListSortDirection.Descending ? -1 : 1);
                    else if (property.GetValue(y) != null)
                        return ((IComparable)property.GetValue(y)).CompareTo(property.GetValue(x)) *
                               (direction == ListSortDirection.Descending ? 1 : -1);
                    else
                        return 0;
                });
            }

            _property = property;
            _sortDirection = direction;
        }
    }
}