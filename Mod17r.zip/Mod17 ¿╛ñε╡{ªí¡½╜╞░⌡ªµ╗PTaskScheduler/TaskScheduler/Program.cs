﻿using System;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;

namespace TaskScheduler
{
    internal static class Program
    {
        /// <summary>
        /// 應用程式的主要進入點。
        /// </summary>
        [STAThread]
        private static void Main()
        {
            using (Mutex m = new Mutex(false, "Global\\{B19DAFCB-729C-43A6-8232-F3C320180124}"))
            {
                //檢查是否同名Mutex已存在(表示另一份程式正在執行)
                if (!m.WaitOne(0, false))
                {
                    Process firstProc = null, current = Process.GetCurrentProcess();

                    //程式Debug時，執行程式名稱後會加上.vshost，所以要移除。
                    foreach (Process process in Process.GetProcessesByName(current.ProcessName.Replace(".vshost", "")))
                    {
                        //Ignore the current process
                        if (process.Id != current.Id)
                        {
                            //Make sure that the process is running from the exe file.
                            if (Assembly.GetExecutingAssembly().Location.Replace("/", "\\") == current.MainModule.FileName.Replace(".vshost", ""))
                            {
                                firstProc = process;
                                break;
                            }
                        }
                    }

                    const int SW_SHOWNORMAL = 1;

                    if (firstProc != null)
                    {
                        ShowWindowAsync(firstProc.MainWindowHandle, SW_SHOWNORMAL);
                        SetForegroundWindow(firstProc.MainWindowHandle);
                    }
                }
                else
                {
                    //如果是Windows Form，Application.Run()要包在using Mutex範圍內
                    //以確保WinForm執行期間Mutex一直存在
                    Application.EnableVisualStyles();
                    Application.SetCompatibleTextRenderingDefault(false);
                    Application.Run(new FrmMain());
                }
            }
        }

        [DllImport("User32.dll")]
        private static extern bool SetForegroundWindow(IntPtr hWnd);

        [DllImport("User32.dll")]
        private static extern bool ShowWindowAsync(IntPtr hWnd, int cmdShow);
    }
}