﻿using System;
using System.ComponentModel;
using System.Data;
using System.IO;

namespace TaskScheduler
{
    internal class EtfAsset : ITask
    {
        public void Start(BackgroundWorker bw, ScheduleItem si, string file, IDbConnection cn)
        {
            //寄發排程發生錯誤EMail
            if (!File.Exists(file)) throw new Exception($"{file} 檔案不存在！無法轉檔。");

            //cn.Open();

            //string[] lines = null;
            //DataTable dt = cn.GetTable("select * from ETFAsset where 1=2");

            //try
            //{
            //    lines = File.ReadAllLines(file);
            //}
            //catch (Exception ex)
            //{
            //    //寄發排程發生錯誤EMail
            //    throw new Exception(ex.ToString());
            //}

            string errMsg = "";
            //int stockNo, assetDate, asset, recCnt = 0;
            //DataRow row;

            //stockNo = dt.Columns["StockNo"].Ordinal;
            //assetDate = dt.Columns["AssetDate"].Ordinal;
            //asset = dt.Columns["Asset"].Ordinal;

            //foreach (string line in lines)
            //{
            //    string[] lineAry = line.Split(',');

            //    if (lineAry.Length != 8 && lineAry[2] != "  ") continue;

            //    try
            //    {
            //        row = dt.NewRow();
            //        row[assetDate] = DateTime.ParseExact((Convert.ToInt32(lineAry[0]) + 19110000).ToString(), "yyyyMMdd", CultureInfo.InvariantCulture);
            //        row[stockNo] = lineAry[1].Trim();
            //        row[asset] = Convert.ToInt32(lineAry[2].TrimStart('+'));
            //        dt.Rows.Add(row);

            //        if (++recCnt % 2 == 1 || recCnt == lines.Length) bw.ReportProgress((int)(recCnt * 0.9 * 100 / lines.Length));
            //    }
            //    catch (Exception ex)
            //    {
            //        errMsg += ex.ToString() + Environment.NewLine;
            //    }
            //}

            //if (dt.Rows.Count > 0)
            //{
            //    cn.Execute("delete from ETFAsset where AssetDate=@AssetDate", new { AssetDate = dt.Rows[0][assetDate] });
            //    cn.BulkCopy("ETFAsset", dt);
            //    si.Message = "ETFAsset資料總共轉檔 " + recCnt.ToString("#,0") + " 筆資料。";
            //}
            //else
            //{
            //    errMsg += "ETFAsset資料轉檔筆數為0！";
            //}

            //cn.Close();

            if (errMsg == "") bw.ReportProgress(100);
            else throw new Exception(errMsg);
        }
    }
}