﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Text;

namespace TaskScheduler
{
    internal class SendTaskResult : ITask
    {
        public SendTaskResult(List<TaskItem> tasks, string cc)
        {
            Tasks = tasks;
            CC = cc;
        }

        public string CC { get; set; }
        public List<TaskItem> Tasks { get; set; }

        public void Start(BackgroundWorker bw, ScheduleItem si, string file, IDbConnection cn)
        {
            StringBuilder sb = new StringBuilder();
            string format = "<tr class='{0}'><td>{1}</td><td>{2}</td><td>{3}</td><td>{4}</td></tr>";

            sb.Append(@"<style>th{text-align:center;}.yellow{background-color:yellow;}.red{background-color:red;}.white{background-color:white;}</style>
<table border='1' cellpadding='5' cellspacing='0' style=""font-family:'微軟正黑體';background-color: #cccccc;"">
<tr style='background-color:#fad8e9;'><th>名稱</th><th>敘述</th><th>類型</th><th>執行結果</th></tr>");

            foreach (TaskItem ti in Tasks.Where(t => t.Name != "SendTaskResult" &&
                (t.Type == TaskType.RealTime ||
                (t.Type != TaskType.RealTime && (t.Schedule == null || t.Schedule?.FirstOrDefault(s => s.Time.CompareTo(DateTime.Now.ToString("HHmm")) <= 0) != null)))))
            {
                sb.Append(string.Format(format, ti.WarnLeval != "" ? (ti.WarnLeval == "Yellow" ? "yellow" : "red") : "white", ti.Name, ti.Description, ti.Type.ToFriendlyString(), ti.Result));
            }

            sb.Append("</table>");

            Module.SendEMail("金商排程結果", sb.ToString(), "", "", CC);
        }
    }
}