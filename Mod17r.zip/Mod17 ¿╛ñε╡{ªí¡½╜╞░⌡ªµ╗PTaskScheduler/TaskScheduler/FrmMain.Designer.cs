﻿namespace TaskScheduler
{
    partial class FrmMain
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmMain));
            this.tabMain = new System.Windows.Forms.TabControl();
            this.tbSchedule = new System.Windows.Forms.TabPage();
            this.dgvSchedule = new System.Windows.Forms.DataGridView();
            this.tbMessage = new System.Windows.Forms.TabPage();
            this.rtbMessage = new System.Windows.Forms.RichTextBox();
            this.colName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colDesc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colResutl = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colWarnLeval = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colExecute = new System.Windows.Forms.DataGridViewButtonColumn();
            this.tabMain.SuspendLayout();
            this.tbSchedule.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSchedule)).BeginInit();
            this.tbMessage.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabMain
            // 
            this.tabMain.Controls.Add(this.tbSchedule);
            this.tabMain.Controls.Add(this.tbMessage);
            this.tabMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabMain.Font = new System.Drawing.Font("微軟正黑體", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.tabMain.Location = new System.Drawing.Point(0, 0);
            this.tabMain.Name = "tabMain";
            this.tabMain.SelectedIndex = 0;
            this.tabMain.Size = new System.Drawing.Size(998, 744);
            this.tabMain.TabIndex = 0;
            // 
            // tbSchedule
            // 
            this.tbSchedule.Controls.Add(this.dgvSchedule);
            this.tbSchedule.Font = new System.Drawing.Font("微軟正黑體", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.tbSchedule.Location = new System.Drawing.Point(4, 34);
            this.tbSchedule.Name = "tbSchedule";
            this.tbSchedule.Padding = new System.Windows.Forms.Padding(3);
            this.tbSchedule.Size = new System.Drawing.Size(990, 706);
            this.tbSchedule.TabIndex = 0;
            this.tbSchedule.Text = "排程";
            this.tbSchedule.UseVisualStyleBackColor = true;
            // 
            // dgvSchedule
            // 
            this.dgvSchedule.AllowUserToAddRows = false;
            this.dgvSchedule.AllowUserToDeleteRows = false;
            this.dgvSchedule.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSchedule.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colName,
            this.colDesc,
            this.colType,
            this.colResutl,
            this.colWarnLeval,
            this.colExecute});
            this.dgvSchedule.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvSchedule.Location = new System.Drawing.Point(3, 3);
            this.dgvSchedule.Name = "dgvSchedule";
            this.dgvSchedule.ReadOnly = true;
            this.dgvSchedule.RowTemplate.Height = 29;
            this.dgvSchedule.Size = new System.Drawing.Size(984, 700);
            this.dgvSchedule.TabIndex = 0;
            this.dgvSchedule.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DgvSchedule_CellContentClick);
            this.dgvSchedule.RowPrePaint += new System.Windows.Forms.DataGridViewRowPrePaintEventHandler(this.DgvSchedule_RowPrePaint);
            // 
            // tbMessage
            // 
            this.tbMessage.Controls.Add(this.rtbMessage);
            this.tbMessage.Font = new System.Drawing.Font("微軟正黑體", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.tbMessage.Location = new System.Drawing.Point(4, 34);
            this.tbMessage.Name = "tbMessage";
            this.tbMessage.Padding = new System.Windows.Forms.Padding(3);
            this.tbMessage.Size = new System.Drawing.Size(1110, 719);
            this.tbMessage.TabIndex = 1;
            this.tbMessage.Text = "訊息";
            this.tbMessage.UseVisualStyleBackColor = true;
            // 
            // rtbMessage
            // 
            this.rtbMessage.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rtbMessage.Location = new System.Drawing.Point(3, 3);
            this.rtbMessage.Name = "rtbMessage";
            this.rtbMessage.Size = new System.Drawing.Size(1104, 713);
            this.rtbMessage.TabIndex = 0;
            this.rtbMessage.Text = "";
            // 
            // colName
            // 
            this.colName.DataPropertyName = "Name";
            this.colName.FillWeight = 117F;
            this.colName.HeaderText = "名稱";
            this.colName.Name = "colName";
            this.colName.ReadOnly = true;
            this.colName.Width = 117;
            // 
            // colDesc
            // 
            this.colDesc.DataPropertyName = "Description";
            this.colDesc.FillWeight = 132F;
            this.colDesc.HeaderText = "敘述";
            this.colDesc.Name = "colDesc";
            this.colDesc.ReadOnly = true;
            this.colDesc.Width = 132;
            // 
            // colType
            // 
            this.colType.DataPropertyName = "TypeName";
            this.colType.FillWeight = 60F;
            this.colType.HeaderText = "類型";
            this.colType.Name = "colType";
            this.colType.ReadOnly = true;
            this.colType.Width = 60;
            // 
            // colResutl
            // 
            this.colResutl.DataPropertyName = "Result";
            this.colResutl.FillWeight = 260F;
            this.colResutl.HeaderText = "執行結果";
            this.colResutl.Name = "colResutl";
            this.colResutl.ReadOnly = true;
            this.colResutl.Width = 260;
            // 
            // colWarnLeval
            // 
            this.colWarnLeval.DataPropertyName = "WarnLeval";
            this.colWarnLeval.HeaderText = "警示等級";
            this.colWarnLeval.Name = "colWarnLeval";
            this.colWarnLeval.ReadOnly = true;
            this.colWarnLeval.Visible = false;
            // 
            // colExecute
            // 
            this.colExecute.FillWeight = 40F;
            this.colExecute.HeaderText = "";
            this.colExecute.Name = "colExecute";
            this.colExecute.ReadOnly = true;
            this.colExecute.Text = "執行";
            this.colExecute.UseColumnTextForButtonValue = true;
            this.colExecute.Width = 40;
            // 
            // FrmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(998, 744);
            this.Controls.Add(this.tabMain);
            this.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FrmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "工作排程";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FrmMain_FormClosing);
            this.Load += new System.EventHandler(this.FrmMain_Load);
            this.tabMain.ResumeLayout(false);
            this.tbSchedule.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvSchedule)).EndInit();
            this.tbMessage.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabMain;
        private System.Windows.Forms.TabPage tbSchedule;
        private System.Windows.Forms.DataGridView dgvSchedule;
        private System.Windows.Forms.TabPage tbMessage;
        private System.Windows.Forms.RichTextBox rtbMessage;
        private System.Windows.Forms.DataGridViewTextBoxColumn colName;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDesc;
        private System.Windows.Forms.DataGridViewTextBoxColumn colType;
        private System.Windows.Forms.DataGridViewTextBoxColumn colResutl;
        private System.Windows.Forms.DataGridViewTextBoxColumn colWarnLeval;
        private System.Windows.Forms.DataGridViewButtonColumn colExecute;
    }
}

