﻿using Newtonsoft.Json;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;

namespace TaskScheduler
{
    /// <summary>
    /// 結果
    /// </summary>
    internal enum Result
    {
        /// <summary>
        /// 尚未執行
        /// </summary>
        [Description("尚未")]
        Not,

        /// <summary>
        /// 執行中
        /// </summary>
        [Description("執行中")]
        InProgress,

        /// <summary>
        /// 執行成功
        /// </summary>
        [Description("成功")]
        Success,

        /// <summary>
        /// 執行失敗
        /// </summary>
        [Description("失敗")]
        Failure
    }

    /// <summary>
    /// 排程類型
    /// </summary>
    internal enum TaskType
    {
        /// <summary>
        /// 指定時間
        /// </summary>
        [Description("時間")]
        Time,

        /// <summary>
        /// 檔案觸發
        /// </summary>
        [Description("檔案")]
        File,

        /// <summary>
        /// 即時觸發
        /// </summary>
        [Description("即時")]
        RealTime
    }

    internal interface ITask
    {
        void Start(BackgroundWorker bw, ScheduleItem si, string file, IDbConnection cn);
    }

    internal class ScheduleItem
    {
        public string Auto { get; set; } = "Y";  // Auto = "N"，代表手動執行
        public string Message { get; set; } = "";
        public int Progress { get; set; } = 0;
        public Result TaskResult { get; set; } = Result.Not;
        public string Time { get; set; } = "";
    }

    internal class TaskItem
    {
        public string Description { get; set; } = "";
        public string File { get; set; } = "";
        public bool InProgress { get; set; } = false;
        public string MailFrom { get; set; } = "";
        public string MailTo { get; set; } = "";
        public string Name { get; set; } = "";

        [JsonIgnore]
        public ITask Program { get; set; }

        public string Result
        {
            get
            {
                string file = Type == TaskType.File ? "檔案：" + File : "";
                string schedules = Schedule == null ? "" :
                    string.Join("，", (from t in Schedule
                                      orderby t.Time
                                      select t.Time + '：' + (t.Auto == "N" ? "手動-" : "") + t.TaskResult.ToFriendlyString() +
                                      (t.TaskResult == TaskScheduler.Result.InProgress && t.Progress != 0 ? " 進度" + t.Progress.ToString() + "%" : "")).ToArray());

                return file != "" && schedules != "" ? file + "，" + schedules : file + schedules;
            }
        }

        public List<ScheduleItem> Schedule { get; set; }
        public TaskType Type { get; set; } = TaskType.Time;

        [JsonIgnore]
        public string TypeName
        {
            get
            {
                return Type.ToFriendlyString();
            }
        }

        public string WarnLeval
        {
            get
            {
                if (Schedule == null) return "Yellow";

                var warnR = Schedule.Where(t => t.TaskResult == TaskScheduler.Result.Failure ||
                        (t.TaskResult == TaskScheduler.Result.Not && t.Time.CompareTo(System.DateTime.Now.ToString("HHmm")) < 0)).FirstOrDefault();

                if (warnR != null) return "Red";

                var warnY = Schedule.Where(t => t.TaskResult == TaskScheduler.Result.InProgress ||
                        (t.TaskResult == TaskScheduler.Result.Not && t.Time.CompareTo(System.DateTime.Now.ToString("HHmm")) >= 0)).FirstOrDefault();

                return warnY != null ? "Yellow" : "";
            }
        }
    }
}