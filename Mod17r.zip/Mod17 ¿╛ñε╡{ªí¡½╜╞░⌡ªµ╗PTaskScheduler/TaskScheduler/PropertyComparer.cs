﻿using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;

namespace TaskScheduler
{
    public class PropertyComparer<T> : IComparer<T>
    {
        private IComparer _comparer;
        private PropertyDescriptor _property;
        private ListSortDirection _sortDirection;

        public PropertyComparer(PropertyDescriptor property, ListSortDirection sortDirection)
        {
            _property = property;
            _sortDirection = sortDirection;
            _comparer = Comparer.Default;
        }

        public int Compare(T x, T y)
        {
            var reverse = _sortDirection == ListSortDirection.Ascending ? 1 : -1;
            return reverse * _comparer.Compare(_property.GetValue(x), _property.GetValue(y));
        }

        public void SetDirection(ListSortDirection sortDirection)
        {
            _sortDirection = sortDirection;
        }
    }
}