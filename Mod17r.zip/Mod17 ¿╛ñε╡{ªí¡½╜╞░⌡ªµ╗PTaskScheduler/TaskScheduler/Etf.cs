﻿using System.ComponentModel;
using System.Data;

namespace TaskScheduler
{
    internal class Etf : ITask
    {
        public void Start(BackgroundWorker bw, ScheduleItem si, string file, IDbConnection cn)
        {
            string errMsg = "123";

            si.Message = "ETF資料總共轉檔 100 筆資料。"; //當si.Message不為空白時，會寄出通知EMail

            if (errMsg == "") bw.ReportProgress(100);
            else throw new CustomException(errMsg); //當有Exception時，會寄出錯誤EMail
        }
    }
}