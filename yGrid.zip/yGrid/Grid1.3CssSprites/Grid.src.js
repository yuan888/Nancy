﻿var PopupWindow = function (msg) {
  this.message = msg;
};

PopupWindow.popSCnt = 0;
PopupWindow.popHCnt = 0;
PopupWindow.popTimeId = new Array(12);

PopupWindow.show = function (msg) {
  PopupWindow.popSCnt++;
  var cnt = PopupWindow.popSCnt, divPop = document.getElementById("divPop" + cnt);

  if (! divPop) {
    divPop = document.createElement("divPop" + cnt);
    divPop.id = "divPop" + cnt;
    divPop.style.position = "absolute";
    divPop.style.width = "200px";
    divPop.style.height = "82px";
    divPop.style.right = "30px";
    divPop.style.overflow = "hidden";
    divPop.style.filter = "alpha(opacity=100)";
    divPop.style.zIndex = 99 - cnt;
    divPop.innerHTML = "<table class='PopupBorder' border='0' cellpadding='0' cellspacing='0'>" +
      "<tr><td width='10' class='PopupHead1'>&nbsp;</td>" +
      "<td width='185' height='22' align='center' valign='bottom' class='PopupHead1' onmouseover=\"this.className='PopupHead2';\" onmouseout=\"this.className='PopupHead1';\">&nbsp;系統訊息</td>" +
      "<td class='PopupHead1' align='left'>" +
      "<span class='PopupX1' onclick='PopupWindow.close(" + cnt + ");' onmouseover=\"this.className='PopupX2';\" onmouseout=\"this.className='PopupX1';\">X</span> " +
      "</td></tr><tr>" +
      "<td width='10' class='PopupText'>&nbsp;</td>" +
      "<td id='tdPopupMsg" + cnt + "' height='58' colspan='2' valign='middle' class='PopupText'></td>" +
      "</tr></table>";
    document.body.appendChild(divPop);
  }

  document.getElementById("tdPopupMsg" + cnt).innerHTML = msg;
  divPop.style.bottom = ((cnt - 1) * parseFloat(divPop.style.height.replace("px", ""))) + "px";

  if (window.ActiveXObject) {
    divPop.filters.alpha.opacity = 100;
  } else {
    divPop.style.opacity = 1;
  }

  divPop.style.display = "";
  PopupWindow.popTimeId[cnt - 1] = setInterval("PopupWindow.move(" + cnt + ")", 10);
};

PopupWindow.move = function (cnt) {
  var divPop = document.getElementById("divPop" + cnt);

  if (divPop.style.display === "") {
    var popH = parseFloat(divPop.style.bottom.replace("px", "")) + 1;
    divPop.style.bottom = popH + "px";

    if (popH >= (cnt * parseFloat(divPop.style.height.replace("px", "")) - 30)) {
      clearInterval(PopupWindow.popTimeId[cnt - 1]);
      PopupWindow.popTimeId[cnt - 1] = setInterval("PopupWindow.hide1(" + cnt + ")", 4000);
    }
  } else {
    clearInterval(PopupWindow.popTimeId[cnt - 1]);
  }
};

PopupWindow.hide1 = function (cnt) {
  var divPop = document.getElementById("divPop" + cnt);
  clearInterval(PopupWindow.popTimeId[cnt - 1]);

  if (divPop.style.display === "") {
    PopupWindow.popTimeId[cnt - 1] = setInterval("PopupWindow.hide2(" + cnt + ")", 100);
  }
};

PopupWindow.hide2 = function (cnt) {
  var divPop = document.getElementById("divPop" + cnt);

  if (divPop.style.display === "") {
    var popOpa;

    if (window.ActiveXObject) {
      popOpa = parseFloat(divPop.filters.alpha.opacity);
      divPop.filters.alpha.opacity = popOpa - 4;
    } else {
      popOpa = parseFloat(divPop.style.opacity);
      divPop.style.opacity = popOpa - 0.04;
    }

    if (popOpa <= 0.04) {
      clearInterval(PopupWindow.popTimeId[cnt - 1]);
      divPop.style.display = "none";
      PopupWindow.popHCnt++;

      if (PopupWindow.popSCnt === PopupWindow.popHCnt) {
        PopupWindow.popSCnt = 0;
        PopupWindow.popHCnt = 0;
      }
    }
  } else {
    clearInterval(PopupWindow.popTimeId[cnt - 1]);
  }
};

PopupWindow.close = function (cnt) {
  var divPop = document.getElementById("divPop" + cnt);
  divPop.style.display = "none";
  PopupWindow.popHCnt++;

  if (PopupWindow.popSCnt === PopupWindow.popHCnt) {
    PopupWindow.popSCnt = 0;
    PopupWindow.popHCnt = 0;
  }
};

var Grid = function (config) {
// private
  function $(id) {
    var tmp = document.getElementById(id);

    if (! tmp) {
      var tmp2 = document.getElementsByName(id);
      if (tmp2) {
        tmp = tmp2[0];
      }
    }

    return document.getElementById(id);
  }

  function runJS(js) {
    var script = document.createElement("SCRIPT");

    document.body.appendChild(script);
    script.text = js;
    document.body.removeChild(script);
  }

  function formatNumber(dec) {
    var ifMinus = false, num = "", l = "", r = "", ret = "", p = 0, i = 0, j = 0;

    if (dec < 0) {
      ifMinus = true;
      num = ( - dec).toString();
    } else {
      num = dec.toString();
    }

    p = num.indexOf(".");
    if (p > 0) {
      l = num.substring(0, p);
      r = num.substring(p + 1);
    } else {
      l = num;
      r = "";
    }

    for (i = l.length - 1; i >= 0; i--) {
      ret = l.charAt(i) + ret;
      if (i && (++j % 3 === 0)) { ret = "," + ret; }
    }

    if (ifMinus) { ret = "-" + ret; }
    if (p > 0) { ret = ret + "." + r; }

    return ret;
  }

  function getAbsolutePos(t) {
    var p = { x: t.offsetLeft, y: t.offsetTop };
    if (t.offsetParent) {
      var tmp = getAbsolutePos(t.offsetParent);
      p.x += tmp.x;
      p.y += tmp.y;
    }
    return p;
  }

  function getStyle(name) {
    var rules, i, j;

    for (i = 0; i < document.styleSheets.length; i++) {

      if (document.styleSheets[i].cssRules) {
        rules = document.styleSheets[i].cssRules;
      } else {
        rules = document.styleSheets[i].rules;
      }

      for (j = 0; j < rules.length; j++) {
        if (rules[j].selectorText.toUpperCase() === name.toUpperCase()) {
          return rules[j].style;
        }
      }
    }
  }

  function getParamValue(pars, tag) {
    var ary = pars.split("&"), i;

    for (i = 0 ; i < ary.length ; i++) {
      if (ary[i].indexOf("=") > 0 && tag === ary[i].substring(0, ary[i].indexOf("="))) {
        return unescape(ary[i].substring(ary[i].indexOf("=") + 1, ary[i].length));
      }
    }

    return "";
  }

  function adjustGridSize() {
    // 預先塞入pageSize大小的筆數，以得到Grid高度。
    var i, html = "<table id='tbGridData" + ID + "' class='GridTable' style='width:" + gridRealW + "px;' border='0' cellspacing='1' cellpadding='1'>" + hideTr;

    for (i = 0; i < pageSize; i++) {
      html += "<tr class='GridDataTr" + (i % 2) + "'><td colspan='" + config.columns.length + "'>　</td></tr>";
    }

    html += "</table>";
    $("divGridData" + ID).innerHTML = html;
    setGridSize(true);
    $("divGridData" + ID).innerHTML = "";
  }

  function init() {
    var widthType = "auto", html = "<tr class='GridTitle' style='line-height:20px;'>", i = 0, w = 0;

    if (resolution === 800) { html = html.replace("20", "18"); }
    if (config.gridWidthType) { widthType = config.gridWidthType; }

    if (widthType === "fixed") {
      if (config.gridWidth) { gridW = config.gridWidth; }
    } else { // auto
      if (resolution === 800) { // 解析度=800，如有gridWidth800設定，寬度=gridWidth800。
        if (config.gridWidth800) { gridW = config.gridWidth800; }
      }
    }

    // 組Grid Title
    for (i = 0; i < config.columns.length; i++) {
      gridRealW += config.columns[i].width + 1;
      hideTr += "<th style='height:0px;width:";
      w = config.columns[i].width;
      if (resolution === 800) { w = w * 14 / 16; }
      hideTr += Math.ceil(w) + "px;' />";
      html += "<th";
      if (config.columns[i].sort) { html += " class='GridTitleSort' onclick='" + config.name + ".sortOnClick(this," + config.columns[i].data.index + ");'"; }
      if (config.columns[i].title.align) { html += " align='" + config.columns[i].title.align + "'"; }
      html += ">" + getBlank(config.columns[i].title.align, "left") + config.columns[i].title.word + getBlank(config.columns[i].title.align, "right", config.columns[i].sort) + "</th>";
    }

    hideTr += "</tr>";
    html += "</tr>";

    // 設定Gird Width
    var scrollW = 17;

    if (gridW === 0) { gridW = gridRealW; }
    html = "<div id='divGrid" + ID + "' class='GridContainer GridDiv' style='top:0px;width:" + (gridW + scrollW) + "px;'>" +
      "<div id='divGridHead" + ID + "' class='GridDiv' style='background-color:#cccccc;top:0px;width:" + gridW + "px;z-index:2'>" +
      "<table id='tbGridHead" + ID + "' class='GridTable' style='margin-top:-4px;width:" + gridRealW + "px;' border='0' cellspacing='1' cellpadding='1'>" +
      hideTr + html + "</table></div>" +
      "<div id='divGridData" + ID + "' class='GridDiv' style='background-color:#cccccc;overflow:scroll;top:-4px;width:" + (gridW + scrollW) + "px;height:" + gridDataH + "px;z-index:1' onscroll=\"document.getElementById('divGridHead" + ID + "').scrollLeft=this.scrollLeft;\"></div>" +
      "<div id='divGridFooter" + ID + "' class='GridToolbar GridDiv' style='top:0px;width:" + gridW + "px;z-index:3'>" +
      "<table class='GridTable' align='left' border='0' width='100%' cellspacing='1' cellpadding='1'><tr height='25' valign='top'>";

    // 導入Footer列內容
    var block = false, imgGrid = imgPath + "yGrid.gif", splitHtm = "&nbsp;<img src='" + imgPath + "ySplit.gif' align='absmiddle'>&nbsp;";

    if (config.pageSize > 0) {
      html += "<td width='21'><div class='GridDivButton'><a id='aGridFirst" + ID + "' class='GridButtonDis' hideFocus href='javascript:" + config.name + ".showPage(\"first\");' title='第一頁'><img id='imgGridFirst" + ID + "' class='GridFirstDis' src='" + imgGrid + "'></a></div></td>" +
        "<td width='21'><div class='GridDivButton'><a id='aGridPrev" + ID + "' class='GridButtonDis' hideFocus href='javascript:" + config.name + ".showPage(\"prev\");' title='上一頁'><img id='imgGridPrev" + ID + "' class='GridPrevDis' src='" + imgGrid + "'></a></div></td>" +
        "<td width='21'><div class='GridDivButton'><a id='aGridNext" + ID + "' class='GridButtonDis' hideFocus href='javascript:" + config.name + ".showPage(\"next\");' title='下一頁'><img id='imgGridNext" + ID + "' class='GridNextDis' src='" + imgGrid + "'></a></div></td>" +
        "<td width='21'><div class='GridDivButton'><a id='aGridLast" + ID + "' class='GridButtonDis' hideFocus href='javascript:" + config.name + ".showPage(\"last\");' title='末頁'><img id='imgGridLast" + ID + "' class='GridLastDis' src='" + imgGrid + "'></a></div></td>";
      block = true;
    }

    if (config.authority) {
      if (config.authority.ins || config.authority.del) {
        if (block) { html += "<td width='10'>" + splitHtm + "</td>"; }
        block = true;
      }
      if (config.authority.ins) {
        html += "<td width='21'><div class='GridDivButton'><a class='GridButton' hideFocus href='javascript:" + config.name + ".rowInsMode();' title='新增'><img class='GridRowAdd' src='" + imgGrid + "'></a></div></td>" +
          "<td width='21'><div class='GridDivButton'><a class='GridButton' hideFocus href='javascript:" + config.name + ".rowCopyMode();' title='複製'><img class='GridRowCopy' src='" + imgGrid + "'></a></div></td>";
      }
      if (config.authority.del) {
        html += "<td width='21'><div class='GridDivButton'><a class='GridButton' hideFocus href='javascript:" + config.name + ".rowDelMode();' title='刪除'><img class='GridRowDel' src='" + imgGrid + "'></a></div></td>";
      }
    }

    html += "<td>";

    if (config.pageSize > 0) {
      var func = "setPage";

      if (block) { html += splitHtm; }
      if (config.pageAjax) { func = "callAjaxQuery"; }
      html += "第 <select id='sltGoToPage" + ID + "' onchange='" + config.name + "." + func + "(this.value)'></select> 頁";
      block = true;
    } else {
      config.pageAjax = false;
    }

    if (config.pageSizeList) {
      var setPage = "", selected = "", ifSelected = false;

      if (config.pageSize > 0) {
        setPage = "每頁";
      } else {
        setPage = "顯示";
      }

      if (block) { html += splitHtm; }
      html += setPage + " <select onchange='" + config.name + ".setPageSize(this.value)'>";

      for (i = 0; i < config.pageSizeList.length; i++) {
        if (config.pageSizeList[i] === pageSize) {
          selected = " selected";
          ifSelected = true;
        } else {
          selected = "";
        }
        if (! ifSelected && pageSize < config.pageSizeList[i]) {
          html += "<option value='" + pageSize + "' selected>" + pageSize + "</option>";
          ifSelected = true;
        }
        html += "<option value='" + config.pageSizeList[i] + "'" + selected + ">" + config.pageSizeList[i] + "</option>";
      }

      html += "</select> 筆";
      block = true;
    }

    var mode = "模式：新增", modeW = 82;

    if (config.dataBind.length === 0) {
      mode = "";
      modeW = 1;
      action = "";
    }

    if (block) { html += splitHtm; }
    html += "<span id='spPagerInfo" + ID + "' /></td><td id='tdMode" + ID + "' width='" + modeW + "'>" + mode + "</td>" +
      "</tr></table></div></div>";

    $(config.target).innerHTML = html;
    adjustGridSize();

    // 修改css style
    var stl = null;

    if (resolution <= 800) {
      stl = getStyle(".GridTable td");
      if (stl) { stl.fontSize = "14px"; }
      stl = getStyle(".GridTable th");
      if (stl) { stl.fontSize = "14px"; }
      stl = getStyle(".GridWaiting");
      if (stl) { stl.fontSize = "14px"; }
    }

    if (imgPath !== "") {
      stl = getStyle("a.GridButton:hover");
      stl.background = stl.background.replace("yButtonBG.gif", imgPath + "yButtonBG.gif");
      stl = getStyle(".GridToolbar table");
      stl.backgroundImage = stl.backgroundImage.replace("yFooterBG.gif", imgPath + "yFooterBG.gif");
      stl = getStyle(".GridTitleSort");
      stl.backgroundImage = stl.backgroundImage.replace("ySort.gif", imgPath + "ySort.gif");
      stl = getStyle(".GridTitleSortA");
      stl.backgroundImage = stl.backgroundImage.replace("yAsc.gif", imgPath + "yAsc.gif");
      stl = getStyle(".GridTitleSortD");
      stl.backgroundImage = stl.backgroundImage.replace("yDesc.gif", imgPath + "yDesc.gif");
    }

    if (config.checkForm) {
      if (typeof config.checkForm === "function") {
        var tar, frm;

        if (config.dataBind) {
          for (i = 0; i < config.dataBind.length; i++) {
            tar = $(config.dataBind[i].target);
            if (tar) {
              frm = tar.form;
              break;
            }
          }
        }

        if (frm) {
          frm.onsubmit = function() {
            runJS(config.name + ".submit()");
            return false;
          };
        }
      }
    }

    bindData(); //使編輯欄位為Add Mode
  }

  function getBlank(align, dir, sorted) {
    var ret = "", ifOk = false, b = "", i = 0;

    if (align) {
      if (align.toLowerCase() === dir) { ifOk = true; }
    } else {
      if (dir === "left") { ifOk = true; }
    }

    if (arguments.length === 3) {
      b = "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
    } else {
      b = "&nbsp;"
    }

    if (ifOk) { ret = "<font class='GridBlank'>" + b + "</font>"; }
    return ret;
  }

  function setPageImage() {
    if (pageIdx === 1 || pageIdx === 2 || pageIdx === (pageCnt - 1) || pageIdx === pageCnt) {
      if (config.pageSize > 0) {
        var first = "", last = "";

        if (pageIdx === 1 || rowsCnt === 0) { first = "Dis"; }
        if (pageIdx === pageCnt || rowsCnt === 0) { last = "Dis"; }

        $("aGridFirst" + ID).className = "GridButton" + first;
        $("aGridPrev" + ID).className = "GridButton" + first;
        $("aGridNext" + ID).className = "GridButton" + last;
        $("aGridLast" + ID).className = "GridButton" + last;
        $("imgGridFirst" + ID).className = "GridFirst" + first;
        $("imgGridPrev" + ID).className = "GridPrev" + first;
        $("imgGridNext" + ID).className = "GridNext" + last;
        $("imgGridLast" + ID).className = "GridLast" + last;
      }
    }
  }

  function setGoToPage() {
    if (config.pageSize > 0) {
      var pages = pageCnt, i;

      if (pages === 0) { pages = 1; }
      $("sltGoToPage" + ID).length = 0;
      for (i = 1; i <= pages; i++) {
        $("sltGoToPage" + ID).options[i - 1] = new Option(i, i);
      }
      if (rowsCnt > 0) {
        $("sltGoToPage" + ID).options.selectedIndex = pageIdx - 1;
      } else {
        $("sltGoToPage" + ID).options.selectedIndex = 0;
      }
    }
  }

  function setFooter() {
    var no1 = 0, no2 = 0;

    if (rowsCnt > 0) {
      no1 = (pageIdx - 1) * pageSize + 1;
      no2 = pageIdx * pageSize;
      if (no2 > rowsCnt) { no2 = rowsCnt; }
    }

    if (config.pageSize > 0) {
      $("spPagerInfo" + ID).innerHTML = "顯示第" + no1 + "~" + no2 + "筆，共" + pageCnt + "頁 " + rowsCnt + "筆資料";
    } else {
      $("spPagerInfo" + ID).innerHTML = "共" + rowsCnt + "筆資料";
    }
  }

  function setGridSize(adjHeight) {
    var widthType = "auto", heightType = "auto", divGrDt = $("divGridData" + ID);

    if (config.gridWidthType) { widthType = config.gridWidthType; }

    if (widthType === "auto") {
      // 微調Grid寬度，避免scroll bar出現
      var divGrHd = $("divGridHead" + ID), taGrHd = $("tbGridHead" + ID), gridDataTbW = $("tbGridData" + ID).offsetWidth;

      divGrHd.style.width = gridDataTbW + "px";
      taGrHd.style.width =  gridDataTbW + "px";
      divGrDt.style.width = (gridDataTbW + 17) + "px";

      $("divGrid" + ID).style.width = (parseFloat(divGrDt.style.width) - 1) + "px";
      $("divGridFooter" + ID).style.width = divGrDt.style.width;
    }

    if (config.gridHeightType) {
      // heightType初始值為auto，gridHeight有設定者，heightType才有可能為fixed
      if (config.gridHeight) { heightType = config.gridHeightType; }
    }

    if (nonDataH === 0) { nonDataH = $("divGrid" + ID).offsetHeight - gridDataH; }
    if (heightType === "fixed") { gridDataH = config.gridHeight - nonDataH; }

    // 記住微調後Data Table Height
    gridDataTbH = $("tbGridData" + ID).offsetHeight;

    if (heightType === "auto") {
      // 微調Grid高度，避免scroll bar出現
      if ((rowsCnt >= pageIdx * pageSize && config.pageSize > 0) || adjHeight) {
        // 最後一頁如果資料數不滿一頁不做
        var divGr = $("divGrid" + ID);

        divGrDt.style.height = (gridDataTbH + 17) + "px";
        divGr.style.height = (nonDataH + gridDataTbH + 17 - 3) + "px";
      }
    }
  }

  function setDisabled(obj, comd, cnt) {
    if (comd !== "params") {
      if (config.dataBind[cnt].disabled || (comd === "" && action === "upd"  && ! config.authority.upd)) {
        obj.disabled = true;
      } else {
        obj.disabled = false;
      }
    }
  }

  function bindData() {
    // cmd = ""，連結Grid資料到html物件。
    // cmd = "copy"，連結Grid資料到html物件，disabled物件值清空。
    // cmd = "params"，將html物件的值轉為資料維護參數字串。
    var params = "hidAction=" + action, cmd = "", i;

    if (config.dataBind) {
      var tar, tmp;

      if (arguments.length === 1) { cmd = arguments[0]; }

      for (i = 0; i < config.dataBind.length; i++) {
        if (! config.dataBind[i].setVal || (config.dataBind[i].setVal && cmd === "params")) {
          tar = document.getElementsByName(config.dataBind[i].target);
          if (tar) {
            tmp = tar[0];
          } else {
            tar = $(config.dataBind[i].target);
            tmp = tar;
          }

          if (tmp) {
            var t = "", j = 0;

            switch (tmp.type) {
              case "button":
              case "reset":
              case "submit":
                setDisabled(tmp, cmd, i);
                break;
              case "checkbox":
              case "radio":
                t = "";

                if (tar.length) {
                  for (j = 0; j < tar.length; j++) {
                    if (cmd !== "params") {
                      tar[j].checked = false;

                      if (action !== "ins") {
                        if (typeof config.dataBind[i].index !== "undefined") {
                          if  (tar[j].value === rowsAry[recNo][config.dataBind[i].index]) {
                            if (! (cmd === "copy" && config.dataBind[i].disabled)) {
                              tar[j].checked = true;
                            } else {
                              tar[j].checked = false;
                            }
                          }
                        }
                      }

                      setDisabled(tar[j], cmd, i);
                    } else {
                      if (tar[j].checked) { t += escape(tar[j].value) + ","; }
                    }
                  }

                  if (cmd === "params") {
                    params += "&" + config.dataBind[i].target + "=";
                    if (t !== "") {
                      params += escape(t.substring(0, t.length - 1));
                    } else {
                      params += escape(t);
                    }
                  }
                } else {
                  if (cmd !== "params") {
                    tmp.checked = false;

                    if (action !== "ins") {
                      if (tmp.value === rowsAry[recNo][config.dataBind[i].index]) {
                        if (! (cmd === "copy" && config.dataBind[i].disabled)) {
                          tmp.checked = true;
                        }
                      }
                    }

                    setDisabled(tmp, cmd, i);
                  } else {
                    params += "&" + config.dataBind[i].target + "=";
                    if (tmp.checked) { params += escape(tmp.value); }
                  }
                }
                break;
              case "text":
              case "textarea":
              case "hidden":
              case "password":
                if (cmd !== "params") {
                  tmp.value = "";

                  if (action !== "ins") {
                    if (typeof config.dataBind[i].index !== "undefined") {
                      if (! (cmd === "copy" && config.dataBind[i].disabled)) {
                        tmp.value = rowsAry[recNo][config.dataBind[i].index];
                      } else {
                        tmp.value = "";
                      }
                    }
                  }

                  if (tmp.type !== "hidden") {
                    setDisabled(tmp, cmd, i);
                  }
                } else {
                  params += "&" + config.dataBind[i].target + "=" + escape(tmp.value);
                }
                break;
              case "select-one":
              case "select-multiple":
                var ifSelected = false;

                t = "";

                for (j = 0; j < tmp.options.length; j++) {
                  if (cmd !== "params") {
                    tmp.options[j].selected = false;

                    if (action !== "ins") {
                      if (typeof config.dataBind[i].index !== "undefined") {
                        if (rowsAry[recNo][config.dataBind[i].index].indexOf(tmp.options[j].value) >= 0) {
                          if (! (cmd === "copy" && config.dataBind[i].disabled)) {
                            tmp.options[j].selected = true;
                          } else {
                            tmp.options[j].selected = false;
                          }
                          ifSelected = true;
                        }
                      }
                    }
                  } else {
                    if (tmp.options[j].selected) { t += tmp.options[j].value + ","; }
                  }
                }

                if (cmd !== "params") {
                  if (action !== "ins" && ! ifSelected && typeof config.dataBind[i].index !== "undefined") {
                    tmp.length++;
                    tmp.options[tmp.length - 1] = new Option(rowsAry[recNo][config.dataBind[i].index], rowsAry[recNo][config.dataBind[i].index]);
                    tmp.options.selectedIndex = tmp.length - 1;
                  }

                  setDisabled(tmp, cmd, i);
                } else {
                  params += "&" + config.dataBind[i].target + "=";
                  if (t !== "") { params += escape(t.substring(0, t.length - 1)); }
                }
                break;
            }
          }
        } else {
          if (typeof config.dataBind[i].setVal === "function") {
            if (action !== "ins" && (config.dataBind[i].index + "") !== "undefined") {
              config.dataBind[i].setVal(rowsAry[recNo][config.dataBind[i].index], action);
            } else {
              config.dataBind[i].setVal("", action);
            }
          }
        }
      }
    }

    return params;
  }

  function updArray(ary) {
    var i, tar, tmp, params = bindData("params"), stop = "button,reset,submit";

    for (i = 0; i < config.dataBind.length; i++) {
      tar = document.getElementsByName(config.dataBind[i].target);
      if (tar.length > 0) {
        tmp = tar[0];
      } else {
        tar = $(config.dataBind[i].target);
        tmp = tar;
      }

      if (tmp) {
        if (stop.indexOf(tmp.type) < 0 && ((typeof config.dataBind[i].index) === "number")) {
          if (typeof config.dataBind[i].getVal === "undefined") {
            ary[config.dataBind[i].index] = getParamValue(params, config.dataBind[i].target);
          } else {
            ary[config.dataBind[i].index] = config.dataBind[i].getVal(action);
          }
        }
      }
    }
  }

  function updGridTr(tr, no) {
    var i, td = "";

    for (i = 0; i < config.columns.length; i++) {
      if (config.columns[i].data.align) {
        tr.cells[i].style.cssText = "text-align:" + config.columns[i].data.align;
      }

      if (config.columns[i].data.setVal) {
        switch (typeof config.columns[i].data.setVal) {
          case "string":
            if (config.columns[i].data.setVal === ",") {
              td = formatNumber(rowsAry[no][config.columns[i].data.index]);
            } else {
              td = rowsAry[no][config.columns[i].data.index];
            }
            break;
          case "function":
            td = config.columns[i].data.setVal(rowsAry[no][config.columns[i].data.index], rowsAry[no], no);
            break;
          default :
            td = rowsAry[no][config.columns[i].data.index];
        }
      } else {
        td = rowsAry[no][config.columns[i].data.index];
      }
      tr.cells[i].innerHTML = getBlank(config.columns[i].data.align, "left") + td + getBlank(config.columns[i].data.align, "right");
    }
  }

  function convertFloat(f) {
    var t = parseFloat(f.replace(/[+,%]/g, ""));
    return (isNaN(t)) ? 0 : t;
  }

  function convertDate(d) {
    var t = d.replace(/-/g, "/"), r;

    r = new Date(t);
    return (isNaN(r)) ? 0 : r.getTime();
  }

  function convertDateTime(dt) {
    var t = dt.replace(/-/g, "/"), r;

    if (t.indexOf(" 上午") >= 0) {
      t = t.replace(/上午 /g, '') + " AM";
    } else if (t.indexOf(" 下午") >= 0) {
      t = t.replace(/下午 /g, '') + " PM";
    }

    r = new Date(t);
    return (isNaN(r)) ? 0 : r.getTime();
  }

  function convertTime(ti) {
    var t = ti, r;

    if (t.indexOf("上午") >= 0) {
      t = t.replace(/上午/g, '') + " AM";
    } else if (t.indexOf("下午 ") >= 0) {
      t = t.replace(/下午/g, '') + " PM";
    }

    r = new Date("1970/1/1 " + t);
    return (isNaN(r)) ? 0 : r.getTime();
  }

  var ID = 0;
  var resolution; // 畫面解析度
  var gridW = 0, gridDataH = 0, gridRealW = 0, gridDataTbH = 0; // Grid的尺寸
  var hideTr = "<tr style='height:auto;'>"; // Grid控制寬度之隱藏Tr
  var rowsAry = []; // Grid資料之物件
  var imgPath = ""; // 圖片路徑
  var rowsCnt = 0; // 資料筆數
  var pageSize = 0; // 頁數大小
  var pageIdx = 0; // 目前頁數
  var pageCnt = 0; // 總頁數
  var nonDataH = 0; // 總高度-Data高度
  var recNo = -1; // 記錄目前在資料中所選定的record number
  var bgcRowClicked = "#cedfff"; // 資料中所選定的Tr背景顏色
  var gridTr = null; // 記錄在Grid中所選定的Tr
  var action = "ins"; // 目前編輯模式：ins,upd,del,qry,ref
  var initAddMode = true;
  var oldAction = "";
  var ajaxWhere = ""; // 記錄Ajax跳頁where條件
  var ajax; // Ajax呼叫元件
  var sortIdxes =[]; // 排序indexes

  var sortDate = function(a, b) {
    var cA = convertDate(a[sortIdxes[0][0]]), cB = convertDate(b[sortIdxes[0][0]]);
    return (cA < cB) ? -1 : (cA > cB) ? 1 : 0;
  };

  var sortDateD = function(a, b) {
    return -1 * sortDate(a, b);
  };

  var sortDateTime = function(a, b) {
    var cA = convertDateTime(a[sortIdxes[0][0]]), cB = convertDateTime(b[sortIdxes[0][0]]);
    return (cA < cB) ? -1 : (cA > cB) ? 1 : 0;
  };

  var sortDateTimeD = function(a, b) {
    return -1 * sortDateTime(a, b);
  };

  var sortTime = function(a, b) {
    var cA = convertTime(a[sortIdxes[0][0]]), cB = convertTime(b[sortIdxes[0][0]]);
    return (cA < cB) ? -1 : (cA > cB) ? 1 : 0;
  };

  var sortTimeD = function(a, b) {
    return -1 * sortTime(a, b);
  };

  var sortNumber = function(a, b) {
    var cA = convertFloat(a[sortIdxes[0][0]]), cB = convertFloat(b[sortIdxes[0][0]]);
    return (cA < cB) ? -1 : (cA > cB) ? 1 : 0;
  };

  var sortNumberD = function(a, b) {
    return -1 * sortNumber(a, b);
  };

  var sortText = function(a, b) {
    return a[sortIdxes[0][0]].localeCompare(b[sortIdxes[0][0]]);
  };

  var sortTextD = function(a, b) {
    return -1 * sortText(a, b);
  };

  if (window.XMLHttpRequest) { // If IE7, Mozilla, Safari, and so on
    ajax = new XMLHttpRequest();
  } else { // for IE6, IE5
    var i, ie = ["MSXML2.XMLHTTP.6.0", "MSXML2.XMLHTTP.5.0", "MSXML2.XMLHTTP.4.0", "MSXML2.XMLHTTP.3.0", "MSXML2.XMLHTTP", "Microsoft.XMLHTTP"];

    for (i = 0; i < ie.length && !ajax; i++) {
      try {
        ajax = new ActiveXObject(ie[i]);
      } catch (e) {}
    }
  }

  Grid.count++;
  ID = Grid.count;

  if (config.imagePath) {
    if (config.imagePath.substring(config.imagePath.length - 1, config.imagePath.length) === "/") {
      imgPath = config.imagePath;
    } else {
      imgPath = config.imagePath + "/";
    }
  }

  if (config.pageSize) {
    pageSize = Math.abs(config.pageSize);
    if (pageSize < 5) { pageSize = 5; }
  } else {
    pageSize = 5;
  }

  if (screen.width <= 800) {
    resolution = 800;
    gridDataH = 121;
  } else {
    resolution = screen.width;
    gridDataH = 116 + (pageSize - 5) * 22;
  }

  init();

// public
  this.setQueryURL = function (url) {
    config.queryURL = url;
  };

  this.load = function () {
    var grData, rows;

    grData = arguments[0];

    if (typeof grData === "object") {
      var ifSetGridSize = false;

      rowsAry = grData;

      if (arguments.length === 2) {
        rows = arguments[1];
        if (rowsCnt === 0 && rows > 0 && pageIdx === 1) { ifSetGridSize = true; }
        rowsCnt = rows;
      } else {
        if (rowsCnt === 0 && rowsAry.length > 0 && pageIdx === 1) { ifSetGridSize = true; }
        rowsCnt = rowsAry.length;
      }

      if (pageIdx === 0) {
        pageIdx = 1;
        ifSetGridSize = true;
      }

      pageCnt = Math.ceil(rowsCnt / pageSize);
      this.setPage(pageIdx);
      setGoToPage();
      if (pageIdx === 1 && ifSetGridSize) { setGridSize(false); }
    } else {
      pageIdx = 0;
      if (arguments.length === 0) { this.callAjaxQuery(); }
      else { this.callAjaxQuery(arguments[0]); }
    }
  };

  this.callAjaxQuery = function () {
    var params = "hidAction=qry&pageSize=" + pageSize;

    if (action !== "ref") { action = "qry"; }

    if (arguments.length === 0) {
      params += "&pageIdx=" + pageIdx;
    } else if (arguments.length === 1) {
      if (! isNaN(arguments[0])) {
        params += "&pageIdx=" + arguments[0];
        pageIdx = parseFloat(arguments[0]);
      } else {
        if (arguments[0].length > 0) {
          var t = "";

          if (arguments[0].charAt(0) !== "&") {  t = "&" + arguments[0]; }
          else { t = arguments[0]; }

          params += t;
          if (config.pageAjax) { ajaxWhere = t; }
        }
      }
    }

    params += "&pageAjax=";

    if (config.pageAjax) {
      params += "true";

      if (ajaxWhere !== "") {
        // Ajax跳頁時，將之前的查詢條件帶入
        if (arguments.length === 0) {
          params += ajaxWhere;
        } else if (arguments.length === 1) {
          if (! isNaN(arguments[0])) {
            params += ajaxWhere;
          }
        }
      }
    } else { params += "false"; }

    if (sortIdxes.length > 0) {
      params += "&sortIdxes=" + sortIdxes.join("|");
    }

    this.callAjax(config.queryURL, params, this);
  };

  this.setPage = function (goToPage) {
    var i, j, min = 0, max = 0, html = "<table id='tbGridData" + ID + "' class='GridTable' style='width:" + gridRealW + "px;' border='0' cellspacing='1' cellpadding='1'>" + hideTr;

    pageIdx = parseFloat(goToPage);

    if (! config.pageAjax) {
      if (goToPage > 0) {
        min = (goToPage - 1) * pageSize;
      }

      if (config.pageSize <= 0) {
        max = rowsCnt;
      } else {
         if (goToPage * pageSize > rowsCnt) {
           max = rowsCnt;
        } else {
          max = goToPage * pageSize;
        }
      }
    } else {
      min = 0;
      max = rowsAry.length;
    }

    for (i = min; i < max; i++) {
      html += "<tr class='GridDataTr" + (i % 2) + "' onclick='" + config.name + ".rowOnClick(this);'>";
      for (j = 0; j < config.columns.length; j++) {
        html += "<td";
        if (config.columns[j].data.align) { html += " align='" + config.columns[j].data.align + "'"; }
        html += ">" + getBlank(config.columns[j].data.align, "left");

        if (config.columns[j].data.setVal) {
          switch (typeof config.columns[j].data.setVal) {
            case "string":
              if (config.columns[j].data.setVal === ",") {
                html += formatNumber(rowsAry[i][config.columns[j].data.index]);
              } else {
                html += rowsAry[i][config.columns[j].data.index];
              }
              break;
            case "function":
              html += config.columns[j].data.setVal(rowsAry[i][config.columns[j].data.index], rowsAry[i], i);
              break;
            default :
              html += rowsAry[i][config.columns[j].data.index];
          }
        } else {
          html += rowsAry[i][config.columns[j].data.index];
        }
        html += getBlank(config.columns[j].data.align, "right") + "</td>";
      }
      html += "</tr>";
    }

    html += "</table>";
    $("divGridData" + ID).innerHTML = html;
    setPageImage();

    if (config.pageSize > 0) {
      if (rowsCnt > 0) {
        $("sltGoToPage" + ID).options.selectedIndex = goToPage - 1;
      } else {
        $("sltGoToPage" + ID).options.selectedIndex = 0;
      }
    }
    setFooter();

    if (gridDataTbH !== $("tbGridData" + ID).offsetHeight) {
      setGridSize(false);
    }
  };

  this.showPage = function (goTo) {
    var ifShow = true;

    if (rowsCnt === 0) { return; }

    switch (goTo) {
      case "first":
        if (pageIdx !== 1) {
          pageIdx = 1;
        } else {
          ifShow = false;
        }
        break;
      case "prev":
        if (pageIdx > 1) {
          pageIdx--;
        } else {
          ifShow = false;
        }
        break;
      case "next":
        if (pageIdx !== pageCnt) {
          pageIdx++;
        } else {
          ifShow = false;
        }
        break;
      case "last":
        if (pageIdx !== pageCnt) {
          pageIdx = pageCnt;
        } else {
          ifShow = false;
        }
        break;
    }

    if (ifShow) {
      if (! config.pageAjax) {
        this.setPage(pageIdx);
      } else {
        this.callAjaxQuery();
      }
    }
  };

  this.setPageSize = function (size) {
    gridDataH = gridDataH / pageSize * size;
    $("divGridData" + ID).style.height = gridDataH + "px";
    $("divGrid" + ID).style.height = (nonDataH + gridDataH - 3) + "px";
    pageSize = size;
    pageIdx = 1;
    adjustGridSize();

    if (! config.pageAjax) {
      pageCnt = Math.ceil(rowsCnt / pageSize);
      this.setPage(pageIdx);
      setGoToPage();
      setGridSize(false);
    } else {
      pageIdx = 0; // pageIdx = 0，才能執行setGridSize()
      this.callAjaxQuery();
    }
  };

  this.sortOnClick = function (th, idx) {
    var i = 0, asc = false;

    sortIdxes = [];

    if (th.className.indexOf("GridTitleSortA") < 0) {
      th.className = "GridTitleSort GridTitleSortA";
      asc = true;
      sortIdxes.push([idx, ""]);
    } else {
      th.className = "GridTitleSort GridTitleSortD";
      sortIdxes.push([idx, "desc"]);
    }

    for (i = 0; i < th.parentNode.childNodes.length; i++) {
      if (th.parentNode.childNodes[i].className !== "" && th.parentNode.childNodes[i] !== th) {
        th.parentNode.childNodes[i].className = "GridTitleSort";
      }
    }

    if (! config.pageAjax) {
      var func;

      switch (config.columns[idx].sort.type) {
        case "number":
        case "percent":
          if (asc) {
            func = sortNumber;
          } else {
            func = sortNumberD;
          }
          break;
        case "date":
          if (asc) {
            func = sortDate;
          } else {
            func = sortDateD;
          }
          break;
        case "dateTime":
          if (asc) {
            func = sortDateTime;
          } else {
            func = sortDateTimeD;
          }
          break;
        case "time":
          if (asc) {
            func = sortTime;
          } else {
            func = sortTimeD;
          }
          break;
        case "text":
        default:
          if (asc) {
            func = sortText;
          } else {
            func = sortTextD;
          }
          break;
      }

      rowsAry.sort(func);
      this.setPage(pageIdx);
    } else {
      this.callAjaxQuery();
    }
    this.rowInsMode();
  };

  this.rowOnClick = function (tmp) {
    var tr, i;

    //之前row ins時bind onclick，使用this傳遞tr物件，可是有時在IE6，this不會傳遞tr，
    //改使用row ins傳遞event，其他時候然傳遞tr
    //底下if試著解決這個問題
    if (tmp.tagName) {
      tr = tmp;
    } else {
      tr = (window.event) ? window.event.srcElement : tmp.target;

      for (i = 0; i < 10; i++) {
        if (tr.tagName === "TR") {
          break;
        } else {
          tr = tr.parentNode;
        }
      }

    }

    if (config.dataBind) {
      if (action !== "ref") {
        action = "upd";
        if (config.dataBind.length > 0) {
          var mode = "修改";

          if (! config.authority.upd) { mode = "查詢"; }
          $("tdMode" + ID).innerHTML = "模式：" + mode;
        }
      }

      if (gridTr) {
        var stl = getStyle("." + gridTr.className);
        if (stl) { gridTr.style.backgroundColor = stl.backgroundColor; }
      }

      tr.style.backgroundColor = bgcRowClicked;
      gridTr = tr;
      recNo = (config.pageAjax) ? tr.rowIndex - 1 : (pageIdx - 1) * pageSize + tr.rowIndex - 1;
      bindData();
    }
  };

  this.rowMoveClicked = function () {
    if (gridTr) {
      var stl = getStyle("." + gridTr.className);
      if (stl) { gridTr.style.backgroundColor = stl.backgroundColor; }
      recNo = -1;
      gridTr = null;
    }
  };

  this.action = function () {
    return action;
  };

  this.rowInsMode = function () {
    action = "ins";
    this.rowMoveClicked();
    $("tdMode" + ID).innerHTML = "模式：新增";
    bindData();
  };

  this.rowCopyMode = function () {
    if (! gridTr) {
      alert("尚未點選要複製的資料！");
    } else {
      action = "upd";
      bindData("copy");
      action = "ins";
      this.rowMoveClicked();
      $("tdMode" + ID).innerHTML = "模式：新增";
    }
  };

  this.rowDelMode = function () {
    if (! gridTr) {
      alert("尚未點選要刪除的資料！");
    } else {
      if (confirm("是否刪除此筆資料？")) {
        action = "del";
        this.submit();
      }
    }
  };

  this.rowReset = function () {
     bindData();
  };

  this.submit = function () {
    var ifOk = true;

    if (config.checkForm) {
      if (typeof config.checkForm === "function") {
        var tar, frm, i;

        if (config.dataBind) {
          for (i = 0; i < config.dataBind.length; i++) {
            tar = $(config.dataBind[i].target);
            if (tar) {
              frm = tar.form;
              break;
            }
          }
        }
        ifOk = config.checkForm(frm, action);
      }
    }

    if (ifOk) {
      if (config.maintainURL) {
        this.callAjax(config.maintainURL, bindData("params"), this);
      } else {
        alert("請定義maintainURL參數！");
      }
    }
  };

  this.callAjax = function (url, params, grid) {
    var ret = "", tar;

    this.waiting("show");
    this.setBindButton(true);
    ajax.open("POST", url, true);
    ajax.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    ajax.setRequestHeader("Content-length", params.length);
    ajax.setRequestHeader("Connection", "close");
    ajax.onreadystatechange = function() {
      var ok = false, ifRefresh = false, refresh = "", grData = null, rows = 0;

      if (ajax.readyState === 4) {
        grid.waiting("hide");

        if (ajax.status === 200) {
          if (! ajax.responseText.match(/<html>/ig)) {
            //eval(ajax.responseText);
            var res = (new Function("return " + ajax.responseText))();
            if (res.runJS) { runJS(res.runJS); }
            ok = res.ok;

            if (ok) {
              switch (action) {
                case "ins":
                  grid.rowIns();
                  break;
                case "upd":
                  grid.rowUpd();
                  break;
                case "del":
                  grid.rowDel();
                  break;
                case "qry":
                case "ref":
                  grData = res.grData;

                  if (grData) {
                    if (res.rows) { rows = res.rows; }
                    if (config.pageAjax) { grid.load(grData, rows); }
                    else { grid.load(grData); }
                  }

                  if (action === "ref") {
                    if (recNo >= 0) {
                      if (oldAction === "upd") {
                        var ta = $("tbGridData" + ID), tr = ta.rows[recNo + 1];

                        grid.rowOnClick(tr);
                      }
                      action = oldAction;
                    } else {
                      action = "qry";
                    }
                  }

                  break;
              }

              if (initAddMode) {
                action = "ins";
                initAddMode = false;
              }
            }

            if (res.ifRefresh) { ifRefresh = res.ifRefresh; }
            if (ifRefresh) {
              if (res.refresh) { refresh = res.refresh; }
              grid.refresh(refresh);
            }
          } else {
            document.write(ajax.responseText);
          }
        } else {
          if (config.debug) { document.write(ajax.responseText); }
          else { alert("Ajax呼叫程式失敗，失敗代碼：" + ajax.status); }
        }

        if (! ok || (action !== "del" && action !== "qry")) { grid.setBindButton(false); }
        if (res.alert) {
          alert(res.alert);
        } else {
          if (res.msg) { PopupWindow.show(res.msg); }
        }
      }
    };
    ajax.send(params);
  };

  this.waiting = function (show) {
    var divWaiting = $("divGridWaiting");

    if (!divWaiting) {
      divWaiting = document.createElement("div");
      divWaiting.id = "divGridWaiting";
      divWaiting.style.position = "absolute";
      divWaiting.style.left = (Math.ceil((gridW - 226) / 2)) + "px";
      divWaiting.style.top = (Math.ceil(($("divGridData" + ID).offsetHeight - 18) / 2)) + "px";
      divWaiting.style.width = "226px";
      divWaiting.style.height = "18px";
      divWaiting.style.zIndex = 999;
      divWaiting.innerHTML = "資料處理中，請稍候<img align='absbottom' src='" + imgPath + "yWaiting.gif'>";
      divWaiting.className = "GridWaiting";
      $("divGrid" + ID).appendChild(divWaiting);
    }

    if (show === "show") {
      show = "";
    } else {
      show = "none";
    }

    divWaiting.style.display = show;
  };

  this.setBindButton = function (dis) {
    var i;

    for (i = 0; i < config.dataBind.length; i++) {
      tar = $(config.dataBind[i].target);
      if (tar) {
        if (tar.type === "button" || tar.type === "reset" || tar.type === "submit") {
          tar.disabled = dis;
        }
      }
    }
  };

  this.rowIns = function () {
    var row = [];

    updArray(row);
    rowsAry.push(row);

    if (config.pageSize > 0) {
      rowsCnt++;
      if (rowsCnt === 1) { pageCnt = 1; pageIdx = 1; }
      if (pageIdx === pageCnt || rowsCnt === 1) { this.setPage(pageIdx); }
      if (pageCnt !== Math.ceil(rowsCnt / pageSize) || rowsCnt === 1) {
        pageCnt = Math.ceil(rowsCnt / pageSize);
        setPageImage();
        setGoToPage();
      }
      if (rowsCnt === pageSize) { setGridSize(false); }
    } else {
      var i, ta = $("tbGridData" + ID), newTr = ta.insertRow(-1);

      newTr.className = "GridDataTr" + (rowsCnt % 2);
      newTr.onclick = function() {
        runJS(config.name + ".rowOnClick(event);");
      };

      for (i = 0; i < config.columns.length; i++) {
        oTd = newTr.insertCell(i);
      }

      updGridTr(newTr, rowsCnt);
      rowsCnt++;
      pageCnt = Math.ceil(rowsCnt / pageSize);
    }

    setFooter();
    this.rowInsMode();
  };

  this.rowUpd = function () {
    updArray(rowsAry[recNo]);
    updGridTr(gridTr, recNo);
  };

  this.rowDel = function () {
    var i = 0;

    if (! config.pageAjax) {
      rowsAry.splice(recNo, 1);
      rowsCnt--;
      pageCnt = Math.ceil(rowsCnt / pageSize);

      if (config.pageSize > 0) {
        if (pageIdx > pageCnt || rowsCnt === 0) {
          pageIdx = pageCnt;
          setGoToPage();
        }
        this.setPage(pageIdx);
      } else {
        var ta = $("tbGridData" + ID);
        ta.deleteRow(gridTr.rowIndex);

        for (i = recNo + 1; i <= rowsCnt; i++) {
          if (ta.rows(i).className === "GridDataTr0") {
            ta.rows(i).className = "GridDataTr1";
          } else {
            ta.rows(i).className = "GridDataTr0";
          }
        }

        setFooter();
      }

      recNo = -1;
      gridTr = null;
      this.rowInsMode();
      action = "del";
    } else {
      this.rowInsMode();
      this.callAjaxQuery();
    }

    var tar;

    for (i = 0; i < config.dataBind.length; i++) {
      tar = document.getElementsByName(config.dataBind[i].target);
      if (tar) {
        for (var j = 0; j < tar.length; j++) {
          tar[j].disabled = true;
        }
      } else {
        tar = $(config.dataBind[i].target);
        if (tar) { tar.disabled = true; }
      }
    }

    if (config.dataBind.length > 0) {
      $("tdMode" + ID).innerHTML = "模式：&nbsp;&nbsp;&nbsp;&nbsp;";
    }
  };

  this.updRow = function (no, iIdx, sData) {
    rowsAry[no][iIdx] = sData;
  };

  this.getRows = function () {
    return rowsAry;
  };

  this.refresh = function (refresh) {
    oldAction = action;
    action = "ref";
    if (arguments.length === 0) { refresh = "" };
    if (refresh === "") { this.callAjaxQuery(); }
    else { this.callAjaxQuery(refresh); }
  };
};

Grid.count = 0;