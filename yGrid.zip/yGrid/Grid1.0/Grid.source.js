﻿PopupWindow = function (sMsg) {
  this.message = sMsg;
};

PopupWindow.iPopSCnt = 0;
PopupWindow.iPopHCnt = 0;
PopupWindow.sPopTimeId = new Array(12);

PopupWindow.show = function(sMsg) {
  PopupWindow.iPopSCnt++;
  var iCnt = PopupWindow.iPopSCnt;
  divPop = document.getElementById("divPop" + iCnt);

  if (! divPop) {
    divPop = document.createElement("divPop" + iCnt);
    divPop.id = "divPop" + iCnt;
    divPop.style.position = "absolute";
    divPop.style.width = "200px";
    divPop.style.height = "82px";
    divPop.style.right = "30px";
    divPop.style.overflow = "hidden";
    divPop.style.filter = "alpha(opacity=100)";
    divPop.style.zIndex = 99 - iCnt;
    divPop.innerHTML = "<table class='PopupBorder' border='0' cellpadding='0' cellspacing='0'>" +
      "<tr><td width='10' class='PopupHead1'>&nbsp;</td>" +
      "<td width='185' height='22' align='center' valign='bottom' class='PopupHead1' onmouseover=\"this.className='PopupHead2';\" onmouseout=\"this.className='PopupHead1';\">&nbsp;系統訊息</td>" +
      "<td class='PopupHead1' align='left'>" +
      "<span class='PopupX1' onclick='PopupWindow.close(" + iCnt + ");' onmouseover=\"this.className='PopupX2';\" onmouseout=\"this.className='PopupX1';\">X</span> " +
      "</td></tr><tr>" +
      "<td width='10' class='PopupText'>&nbsp;</td>" +
      "<td id='tdPopupMsg" + iCnt + "' height='58' colspan='2' valign='middle' class='PopupText'></td>" +
      "</tr></table>";
    document.body.appendChild(divPop);
  }

  document.getElementById("tdPopupMsg" + iCnt).innerHTML = sMsg;
  divPop.style.bottom = ((iCnt - 1) * parseFloat(divPop.style.height.replace("px", ""))) + "px";

  if (window.ActiveXObject) {
    divPop.filters.alpha.opacity = 100;
  } else {
    divPop.style.opacity = 1;
  }

  divPop.style.display = "";
  PopupWindow.sPopTimeId[iCnt - 1] = setInterval("PopupWindow.move(" + iCnt + ")", 10);
};

PopupWindow.move = function(iCnt) {
  divPop = document.getElementById("divPop" + iCnt);

  if (divPop.style.display === "") {
    iPopH = parseFloat(divPop.style.bottom.replace("px", "")) + 1;
    divPop.style.bottom = iPopH + "px";

    if (iPopH >= (iCnt * parseFloat(divPop.style.height.replace("px", "")) - 30)) {
      clearInterval(PopupWindow.sPopTimeId[iCnt - 1]);
      PopupWindow.sPopTimeId[iCnt - 1] = setInterval("PopupWindow.hide1(" + iCnt + ")", 4000);
    }
  } else {
    clearInterval(PopupWindow.sPopTimeId[iCnt - 1]);
  }
};

PopupWindow.hide1 = function(iCnt) {
  divPop = document.getElementById("divPop" + iCnt);
  clearInterval(PopupWindow.sPopTimeId[iCnt - 1]);
  if (divPop.style.display === "") {
    PopupWindow.sPopTimeId[iCnt - 1] = setInterval("PopupWindow.hide2(" + iCnt + ")", 100);
  }
};

PopupWindow.hide2 = function(iCnt) {
  divPop = document.getElementById("divPop" + iCnt);

  if (divPop.style.display === "") {
    if (window.ActiveXObject) {
      iPopOpa = parseFloat(divPop.filters.alpha.opacity);
      divPop.filters.alpha.opacity = iPopOpa - 4;
    } else {
      iPopOpa = parseFloat(divPop.style.opacity);
      divPop.style.opacity = iPopOpa - 0.04;
    }

    if (iPopOpa <= 0) {
      clearInterval(PopupWindow.sPopTimeId[iCnt - 1]);
      divPop.style.display = "none";
      PopupWindow.iPopHCnt++;

      if (PopupWindow.iPopSCnt === PopupWindow.iPopHCnt) {
        PopupWindow.iPopSCnt = 0;
        PopupWindow.iPopHCnt = 0;
      }
    }
  } else {
    clearInterval(PopupWindow.sPopTimeId[iCnt - 1]);
  }
};

PopupWindow.close = function(iCnt) {
  divPop = document.getElementById("divPop" + iCnt);
  divPop.style.display = "none";
  PopupWindow.iPopHCnt++;

  if (PopupWindow.iPopSCnt === PopupWindow.iPopHCnt) {
    PopupWindow.iPopSCnt = 0;
    PopupWindow.iPopHCnt = 0;
  }
};

Grid = function(config) {
// private
  function $(sID) {
    var oTemp = document.getElementById(sID);

    if (! oTemp) {
      var oTemp2 = document.getElementsByName(sID);
      if (oTemp2) {
        oTemp = oTemp2[0];
      }
    }

    return document.getElementById(sID);
  }

  function FormatNumber(iDec) {
    var bMinus = false;
    var sNum = "", sLeft = "", sRight = "", sReturn = "";
    var iPos = 0, j = 0;

    if (iDec < 0) {
      bMinus = true;
      sNum = "" + ( - iDec);
    } else {
      sNum = "" + iDec;
    }

    iPos = sNum.indexOf(".");
    if (iPos > 0) {
      sLeft = sNum.substring(0, iPos);
      sRight = sNum.substring(iPos + 1);
    } else {
      sLeft = sNum;
      sRight = "";
    }

    for (var i = sLeft.length - 1; i >= 0; i--) {
      sReturn = sLeft.charAt(i) + sReturn;
      if (i && (++j % 3 === 0)) { sReturn = "," + sReturn; }
    }

    if (bMinus) { sReturn = "-" + sReturn; }
    if (iPos > 0) { sReturn = sReturn + "." + sRight; }

    return sReturn;
  }

  function getAbsolutePos(oTar) {
    var oPos = { x: oTar.offsetLeft, y: oTar.offsetTop };
    if (oTar.offsetParent) {
      var oTemp = getAbsolutePos(oTar.offsetParent);
      oPos.x += oTemp.x;
      oPos.y += oTemp.y;
    }
    return oPos;
  }

  function getStyle(sName) {
    for (var i = 0; i < document.styleSheets.length; i++) {
      var oRules;

      if (document.styleSheets[i].cssRules) {
        oRules = document.styleSheets[i].cssRules;
      } else {
        oRules = document.styleSheets[i].rules;
      }

      for (var j = 0; j < oRules.length; j++) {
        if (oRules[j].selectorText.toUpperCase() === sName.toUpperCase()) {
          return oRules[j].style;
        }
      }
    }
  }

  function getParamValue(sPars, sTag) {
    var oAry = sPars.split("&");

    for (var i = 0 ; i < oAry.length ; i++) {
      if (oAry[i].indexOf("=") > 0 && sTag === oAry[i].substring(0, oAry[i].indexOf("="))) {
        return unescape(oAry[i].substring(oAry[i].indexOf("=") + 1, oAry[i].length));
      }
    }

    return "";
  }

  function adjustGridSize() {
    // 預先塞入iPageSize大小的筆數，以得到Grid高度。
    var sHtml = "<table id='tbGridData" + ID + "' class='GridTable' style='width:" + iGridRealWidth + "px;' border='0' cellspacing='1' cellpadding='1'>" + sHideTr;

    for (var i = 0; i < iPageSize; i++) {
      sHtml += "<tr class='GridDataTr" + (i % 2) + "'><td colspan='" + config.columns.length + "'>　</td></tr>";
    }

    sHtml += "</table>";
    $("divGridData" + ID).innerHTML = sHtml;
    setGridSize(true);
    $("divGridData" + ID).innerHTML = "";
  }

  function init() {
    var sWidthType = "auto", sHtml = "<tr class='GridTitle' style='line-height:20px;'>";
    var i = 0, iWidth = 0;

    if (iResolution === 800) { sHtml = sHtml.replace("20", "18"); }
    if (config.gridWidthType) { sWidthType = config.gridWidthType; }

    if (sWidthType === "fixed") {
      if (config.gridWidth) { iGridWidth = config.gridWidth; }
    } else { // auto
      if (iResolution === 800) { // 解析度=800，如有gridWidth800設定，寬度=gridWidth800。
        if (config.gridWidth800) { iGridWidth = config.gridWidth800; }
      }
    }

    // 組Grid Title
    for (i = 0; i < config.columns.length; i++) {
      iGridRealWidth += config.columns[i].width + 1;
      sHideTr += "<th style='height:0px;width:";
      iWidth = config.columns[i].width;
      if (iResolution === 800) { iWidth = iWidth * 14 / 16; }
      sHideTr += Math.ceil(iWidth) + "px;' />";
      sHtml += "<th";
      if (config.columns[i].title.align) { sHtml += " align='" + config.columns[i].title.align + "'"; }
      sHtml += ">" + getBlank(config.columns[i].title.align, "left") + config.columns[i].title.word + getBlank(config.columns[i].title.align, "right") + "</th>";
    }

    sHideTr += "</tr>";
    sHtml += "</tr>";

    // 設定Gird Width
    var iScrollWidth = 17;

    if (iGridWidth === 0) { iGridWidth = iGridRealWidth; }
    sHtml = "<div id='divGrid" + ID + "' class='GridContainer GridDiv' style='top:0px;width:" + (iGridWidth + iScrollWidth) + "px;'>" +
      "<div id='divGridHead" + ID + "' class='GridDiv' style='background-color:#cccccc;top:0px;width:" + iGridWidth + "px;z-index:2'>" +
      "<table id='tbGridHead" + ID + "' class='GridTable' style='margin-top:-4px;width:" + iGridRealWidth + "px;' border='0' cellspacing='1' cellpadding='1'>" +
      sHideTr + sHtml + "</table></div>" +
      "<div id='divGridData" + ID + "' class='GridDiv' style='background-color:#cccccc;overflow:scroll;top:-4px;width:" + (iGridWidth + iScrollWidth) + "px;height:" + iGridDataHeight + "px;z-index:1' onscroll=\"document.getElementById('divGridHead" + ID + "').scrollLeft=this.scrollLeft;\"></div>" +
      "<div id='divGridFooter" + ID + "' class='GridToolbar GridDiv' style='top:0px;width:" + iGridWidth + "px;z-index:3'>" +
      "<table class='GridTable' border='0' width='100%' cellspacing='1' cellpadding='1'><tr><td valign='top'>&nbsp;";

    // 導入Footer列內容
    var sSplit = "&nbsp;<img src='" + sImagePath + "GridSplit.gif' align='baseline'>&nbsp;";

    if (config.pageSize > 0) {
      var sFunc = "setPage";

      if (config.pageAjax) { sFunc = "callAjaxQuery"; }
      sHtml += "<a id='aGridFirst" + ID + "' class='pagerButtonDis' hideFocus href='javascript:" + config.name + ".showPage(\"first\");' title='第一頁'><img id='imgGridFirst" + ID + "' src='" + sImagePath + "DisFirst.gif'></a>" +
        "<a id='aGridPrev" + ID + "' class='pagerButtonDis' hideFocus href='javascript:" + config.name + ".showPage(\"prev\");' title='上一頁'><img id='imgGridPrev" + ID + "' src='" + sImagePath + "DisPrev.gif'></a>" +
        "<a id='aGridNext" + ID + "' class='pagerButtonDis' hideFocus href='javascript:" + config.name + ".showPage(\"next\");' title='下一頁'><img id='imgGridNext" + ID + "' src='" + sImagePath + "DisNext.gif'></a>" +
        "<a id='aGridLast" + ID + "' class='pagerButtonDis' hideFocus href='javascript:" + config.name + ".showPage(\"last\");' title='末頁'><img id='imgGridLast" + ID + "' src='" + sImagePath + "DisLast.gif'></a>" +
        sSplit + "第 <select id='sltGoToPage" + ID + "' onchange='" + config.name + "." + sFunc + "(this.value)'></select> 頁" + sSplit;
    } else {
      config.pageAjax = false;
    }

    if (config.pageSizeList) {
      var sSetPage = "", sSelected = "";
      var bSelected = false;

      if (config.pageSize > 0) {
        sSetPage = "每頁";
      } else {
        sSetPage = "顯示";
      }

      sHtml += sSetPage + " <select onchange='" + config.name + ".setPageSize(this.value)'>";

      for (i = 0; i < config.pageSizeList.length; i++) {
        if (config.pageSizeList[i] === iPageSize) {
          sSelected = " selected";
          bSelected = true;
        } else {
          sSelected = "";
        }
        if (! bSelected && iPageSize < config.pageSizeList[i]) {
          sHtml += "<option value='" + iPageSize + "' selected>" + iPageSize + "</option>";
          bSelected = true;
        }
        sHtml += "<option value='" + config.pageSizeList[i] + "'" + sSelected + ">" + config.pageSizeList[i] + "</option>";
      }

      sHtml += "</select> 筆";
    }

    if (config.authority) {
      if (config.authority.ins || config.authority.upd || config.authority.del) {
        sHtml += sSplit;
      }
      if (config.authority.ins) {
        sHtml += "<a class='pagerButton' hideFocus href='javascript:" + config.name + ".rowInsMode();' title='新增'><img src='" + sImagePath + "RowAdd.gif'></a>" +
          "<a class='pagerButton' hideFocus href='javascript:" + config.name + ".rowCopyMode();' title='複製'><img src='" + sImagePath + "RowCopy.gif'></a>";
      }
      if (config.authority.del) {
        sHtml += "<a class='pagerButton' hideFocus href='javascript:" + config.name + ".rowDelMode();' title='刪除'><img src='" + sImagePath + "RowDel.gif'></a>";
      }
    }

    var sMode = "模式：&nbsp;&nbsp;&nbsp;&nbsp;";
    var iModeWidth = 82;

    if (config.dataBind.length === 0) {
      sMode = "";
      iModeWidth = 1;
    }
    sHtml += sSplit + "<span id='spPagerInfo" + ID + "' /></td><td id='tdMode" + ID + "' width='" + iModeWidth + "'>" + sMode + "</td>" +
      "</tr></table></div></div>";

    $(config.target).innerHTML = sHtml;
    adjustGridSize();

    // 修改css style
    var oStl = null;

    if (iResolution <= 800) {
      oStl = getStyle(".GridTable td");
      if (oStl) { oStl.fontSize = "14px"; }
      oStl = getStyle(".GridTable th");
      if (oStl) { oStl.fontSize = "14px"; }
      oStl = getStyle(".GridWaiting");
      if (oStl) { oStl.fontSize = "14px"; }
    }

    if (sImagePath !== "") {
      oStl = getStyle("a.pagerButton:hover");
      oStl.background = oStl.background.replace("ButtonBG.gif", sImagePath + "ButtonBG.gif");
      oStl = getStyle(".GridToolbar table");
      oStl.backgroundImage = oStl.backgroundImage.replace("FooterBG.gif", sImagePath + "FooterBG.gif");
    }

    if (config.checkForm) {
      if (typeof config.checkForm === "function") {
        var oTar, oFrm;

        if (config.dataBind) {
          for (i = 0; i < config.dataBind.length; i++) {
            oTar = $(config.dataBind[i].target);
            if (oTar) {
              oFrm = oTar.form;
              break;
            }
          }
        }

        if (oFrm) {
          oFrm.onsubmit = function() {
            eval(config.name + ".submit()");
            return false;
          };
        }
      }
    }
  }

  function getBlank(sAlign, sDir) {
    var sReturn = "";
    var bOk = false;

    if (sAlign) {
      if (sAlign.toLowerCase() === sDir) { bOk = true; }
    } else {
      if (sDir === "left") { bOk = true; }
    }

    if (bOk) { sReturn = "<font class='GridBlank'>&nbsp;</font>"; }
    return sReturn;
  }

  function setPageImage() {
    if (iPageIdx === 1 || iPageIdx === 2 || iPageIdx === (iPageCnt - 1) || iPageIdx === iPageCnt) {
      if (config.pageSize > 0) {
        var sFirst = "", sLast = "";

        if (iPageIdx === 1 || iRowsCnt === 0) { sFirst = "Dis"; }
        if (iPageIdx === iPageCnt || iRowsCnt === 0) { sLast = "Dis"; }

        $("aGridFirst" + ID).className = "pagerButton" + sFirst;
        $("aGridPrev" + ID).className = "pagerButton" + sFirst;
        $("aGridNext" + ID).className = "pagerButton" + sLast;
        $("aGridLast" + ID).className = "pagerButton" + sLast;
        $("imgGridFirst" + ID).src = sImagePath + sFirst + "First.gif";
        $("imgGridPrev" + ID).src = sImagePath + sFirst + "Prev.gif";
        $("imgGridNext" + ID).src = sImagePath + sLast + "Next.gif";
        $("imgGridLast" + ID).src = sImagePath + sLast + "Last.gif";
      }
    }
  }

  function setGoToPage() {
    if (config.pageSize > 0) {
      var iPages = iPageCnt;

      if (iPages === 0) { iPages = 1; }
      $("sltGoToPage" + ID).length = 0;
      for (var i = 1; i <= iPages; i++) {
        $("sltGoToPage" + ID).options[i - 1] = new Option(i, i);
      }
      if (iRowsCnt > 0) {
        $("sltGoToPage" + ID).options.selectedIndex = iPageIdx - 1;
      } else {
        $("sltGoToPage" + ID).options.selectedIndex = 0;
      }
    }
  }

  function setFooter() {
    var iNo1 = 0, iNo2 = 0;

    if (iRowsCnt > 0) {
      iNo1 = (iPageIdx - 1) * iPageSize + 1;
      iNo2 = iPageIdx * iPageSize;
      if (iNo2 > iRowsCnt) { iNo2 = iRowsCnt; }
    }

    if (config.pageSize > 0) {
      $("spPagerInfo" + ID).innerHTML = "顯示第" + iNo1 + "~" + iNo2 + "筆，共" + iPageCnt + "頁 " + iRowsCnt + "筆資料";
    } else {
      $("spPagerInfo" + ID).innerHTML = "共" + iRowsCnt + "筆資料";
    }
  }

  function setGridSize(bAdjHeight) {
    var sWidthType = "auto";
    var oDivGrDt;

    oDivGrDt = $("divGridData" + ID);
    if (config.gridWidthType) { sWidthType = config.gridWidthType; }

    if (sWidthType === "auto") {
      // 微調Grid寬度，避免scroll bar出現
      var oDivGrHd = $("divGridHead" + ID);
      var oTaGrHd = $("tbGridHead" + ID);

//      iCnt = 0;

//      do {
//        oDivGrDt.scrollLeft = 1;
//        iCnt++;

//        if (oDivGrDt.scrollLeft === 1) {
//          oDivGrHd.style.width = (parseFloat(oDivGrHd.style.width) + 1) + "px";
//          oTaGrHd.style.width = (parseFloat(oTaGrHd.style.width) + 1) + "px";
//          oDivGrDt.style.width = (parseFloat(oDivGrDt.style.width) + 1) + "px";
//        }
//      } while (oDivGrDt.scrollLeft === 1 && iCnt < 30);
      var iGridDataTbWidth = $("tbGridData" + ID).offsetWidth;

      oDivGrHd.style.width = iGridDataTbWidth + "px";
      oTaGrHd.style.width =  iGridDataTbWidth + "px";
      oDivGrDt.style.width = (iGridDataTbWidth + 17) + "px";

      $("divGrid" + ID).style.width = (parseFloat(oDivGrDt.style.width) - 1) + "px";
      $("divGridFooter" + ID).style.width = oDivGrDt.style.width;
    }

    var sHeightType = "auto";
    var iSubHeight = 0;

    if (config.gridHeightType) {
      // sHeightType初始值為auto，gridHeight有設定者，sHeightType才有可能為fixed
      if (config.gridHeight) { sHeightType = config.gridHeightType; }
    }

    if (iNonDataHeight === 0) { iNonDataHeight = ($("divGrid" + ID).offsetHeight - iSubHeight) - iGridDataHeight; }
    if (sHeightType === "fixed") { iGridDataHeight = config.gridHeight - iNonDataHeight; }
// 底下兩行取消
//    oDivGrDt.style.height = iGridDataHeight + "px";
//    $("divGrid" + ID).style.height = (iNonDataHeight + iGridDataHeight - 3) + "px";

    // 記住微調後Data Table Height
    iGridDataTbHeight = $("tbGridData" + ID).offsetHeight;

    if (sHeightType === "auto") {
      // 微調Grid高度，避免scroll bar出現
      if ((iRowsCnt >= iPageIdx * iPageSize && config.pageSize > 0) || bAdjHeight) {
        // 最後一頁如果資料數不滿一頁不做
        var oDivGr = $("divGrid" + ID);

        oDivGrDt.style.height = (iGridDataTbHeight + 17) + "px";
        oDivGr.style.height = (iNonDataHeight + iGridDataTbHeight + 17 - 3) + "px";
//        iCnt = 0;

//        do {
//          iGridDataHeight--;
//          oDivGrDt.style.height = iGridDataHeight + "px";
//          oDivGr.style.height = (iNonDataHeight + iGridDataHeight - 3) + "px";
//          oDivGrDt.scrollTop = 1;
//          iCnt++;
//        } while (oDivGrDt.scrollTop === 0 && iCnt < 50);

//        iCnt = 0;

//        do {
//          oDivGrDt.scrollTop = 1;
//          iCnt++;

//          if (oDivGrDt.scrollTop === 1) {
//            iGridDataHeight++;
//            oDivGrDt.style.height = iGridDataHeight + "px";
//            oDivGr.style.height = (iNonDataHeight + iGridDataHeight - 3) + "px";
//          }
//        } while (oDivGrDt.scrollTop === 1 && iCnt < 60);
      }
    }
  }

  function bindData() {
    // sCmd = ""，連結Grid資料到html物件。
    // sCmd = "copy"，連結Grid資料到html物件，disabled物件值清空。
    // sCmd = "params"，將html物件的值轉為資料維護參數字串。
    var sParams = "hidAction=" + sAction;
    var sCmd = "";

    if (config.dataBind) {
      var oTar, oTemp;

      if (arguments.length === 1) { sCmd = arguments[0]; }

      for (var i = 0; i < config.dataBind.length; i++) {
        if (! config.dataBind[i].setVal || (config.dataBind[i].setVal && sCmd === "params")) {
          oTar = document.getElementsByName(config.dataBind[i].target);
          if (oTar) {
            oTemp = oTar[0];
          } else {
            oTar = $(config.dataBind[i].target);
            oTemp = oTar;
          }

          if (oTemp) {
            var sTemp = "";
            var j = 0;

            switch (oTemp.type) {
              case "button":
              case "reset":
              case "submit":
                if (sCmd !== "params") {
                  if (config.dataBind[i].disabled) {
                    oTemp.disabled = true;
                  } else {
                    oTemp.disabled = false;
                  }
                }
                break;
              case "checkbox":
              case "radio":
                sTemp = "";

                if (oTar.length) {
                  for (j = 0; j < oTar.length; j++) {
                    if (sCmd !== "params") {
                      oTar[j].checked = false;

                      if (sAction !== "ins") {
                        if (typeof config.dataBind[i].index !== "undefined") {
                          if  (oTar[j].value == oRows[iRecNo][config.dataBind[i].index]) {
                            if (! (sCmd === "copy" && config.dataBind[i].disabled)) {
                              oTar[j].checked = true;
                            } else {
                              oTar[j].checked = false;
                            }
                          }
                        }
                      }

                      if (config.dataBind[i].disabled) { oTar[j].disabled = true; }
                      else { oTar[j].disabled = false; }
                    } else {
                      if (oTar[j].checked) { sTemp += escape(oTar[j].value) + ","; }
                    }
                  }

                  if (sCmd === "params") {
                    sParams += "&" + config.dataBind[i].target + "=";
                    if (sTemp !== "") {
                      sParams += escape(sTemp.substring(0, sTemp.length - 1));
                    } else {
                      sParams += escape(sTemp);
                    }
                  }
                } else {
                  if (sCmd !== "params") {
                    oTemp.checked = false;

                    if (sAction !== "ins") {
                      if (oTemp.value == oRows[iRecNo][config.dataBind[i].index]) {
                        if (! (sCmd === "copy" && config.dataBind[i].disabled)) {
                          oTemp.checked = true;
                        }
                      }
                    }

                    if (config.dataBind[i].disabled) {
                      oTemp.disabled = true;
                    } else {
                      oTemp.disabled = false;
                    }
                  } else {
                    sParams += "&" + config.dataBind[i].target + "=";
                    if (oTemp.checked) { sParams += escape(oTemp.value); }
                  }
                }
                break;
              case "text":
              case "textarea":
              case "hidden":
              case "password":
                if (sCmd !== "params") {
                  oTemp.value = "";

                  if (sAction !== "ins") {
                    if (typeof config.dataBind[i].index !== "undefined") {
                      if (! (sCmd === "copy" && config.dataBind[i].disabled)) {
                        oTemp.value = oRows[iRecNo][config.dataBind[i].index];
                      } else {
                        oTemp.value = "";
                      }
                    }
                  }

                  if (oTemp.type !== "hidden") {
                    if (config.dataBind[i].disabled) {
                      oTemp.disabled = true;
                    } else {
                      oTemp.disabled = false;
                    }
                  }
                } else {
                  sParams += "&" + config.dataBind[i].target + "=" + escape(oTemp.value);
                }
                break;
              case "select-one":
              case "select-multiple":
                var bSelected = false;

                sTemp = "";

                for (j = 0; j < oTemp.options.length; j++) {
                  if (sCmd !== "params") {
                    oTemp.options[j].selected = false;

                    if (sAction !== "ins") {
                      if (typeof config.dataBind[i].index !== "undefined") {
                        if (oRows[iRecNo][config.dataBind[i].index].indexOf(oTemp.options[j].value) >= 0) {
                          if (! (sCmd === "copy" && config.dataBind[i].disabled)) {
                            oTemp.options[j].selected = true;
                          } else {
                            oTemp.options[j].selected = false;
                          }
                          bSelected = true;
                        }
                      }
                    }
                  } else {
                    if (oTemp.options[j].selected) { sTemp += oTemp.options[j].value + ","; }
                  }
                }

                if (sCmd !== "params") {
                  if (sAction !== "ins" && ! bSelected && typeof config.dataBind[i].index !== "undefined") {
                    oTemp.length++;
                    oTemp.options[oTemp.length - 1] = new Option(oRows[iRecNo][config.dataBind[i].index], oRows[iRecNo][config.dataBind[i].index]);
                    oTemp.options.selectedIndex = oTemp.length - 1;
                  }
                  if (config.dataBind[i].disabled) {
                    oTemp.disabled = true;
                  } else {
                    oTemp.disabled = false;
                  }
                } else {
                  sParams += "&" + config.dataBind[i].target + "=";
                  if (sTemp !== "") { sParams += escape(sTemp.substring(0, sTemp.length - 1)); }
                 }
                break;
            }
          }
        } else {
          if (typeof config.dataBind[i].setVal === "function") {
            if (sAction !== "ins" && (config.dataBind[i].index + "") !== "undefined") {
              config.dataBind[i].setVal(oRows[iRecNo][config.dataBind[i].index], sAction);
            } else {
              config.dataBind[i].setVal("", sAction);
            }
          }
        }
      }
    }

    return sParams;
  }

  function updArray(oArray) {
    var oTar, oTemp;
    var sParams = bindData("params");
    var sStop = "button,hidden,reset,submit";

    for (var i = 0; i < config.dataBind.length; i++) {
      oTar = document.getElementsByName(config.dataBind[i].target);
      if (oTar.length > 0) {
        oTemp = oTar[0];
      } else {
        oTar = $(config.dataBind[i].target);
        oTemp = oTar;
      }

      if (oTemp) {
        if (sStop.indexOf(oTemp.type) < 0 && ((typeof config.dataBind[i].index) === "number")) {
          if (typeof config.dataBind[i].getVal === "undefined") {
            oArray[config.dataBind[i].index] = getParamValue(sParams, config.dataBind[i].target);
          } else {
            oArray[config.dataBind[i].index] = config.dataBind[i].getVal(sAction);
          }
        }
      }
    }
  }

  function updGridTr(oTr, iNo) {
    var sTd = "";

    for (var i = 0; i < config.columns.length; i++) {
      if (config.columns[i].data.align) {
        oTr.cells[i].style.cssText = "text-align:" + config.columns[i].data.align;
      }

      if (config.columns[i].data.setVal) {
        switch (typeof config.columns[i].data.setVal) {
          case "string":
            if (config.columns[i].data.setVal === ",") {
              sTd = FormatNumber(oRows[iNo][config.columns[i].data.index]);
            } else {
              sTd = oRows[iNo][config.columns[i].data.index];
            }
            break;
          case "function":
            sTd = config.columns[i].data.setVal(oRows[iNo][config.columns[i].data.index], oRows[iNo], iNo);
            break;
          default :
            sTd = oRows[iNo][config.columns[i].data.index];
        }
      } else {
        sTd = oRows[iNo][config.columns[i].data.index];
      }
      oTr.cells[i].innerHTML = getBlank(config.columns[i].data.align, "left") + sTd + getBlank(config.columns[i].data.align, "right");
    }
  }

  var ID = 0;
  // 畫面解析度
  var iResolution;
  // Grid的尺寸
  var iGridWidth = 0, iGridDataHeight = 0, iGridRealWidth = 0, iGridDataTbHeight = 0;
  // Grid控制寬度之隱藏Tr
  var sHideTr = "<tr style='height:auto;'>";
  // Grid資料之物件
  var oRows = [];
  // 圖片路徑
  var sImagePath = "";
  // 資料筆數
  var iRowsCnt = 0;
  // 頁數大小
  var iPageSize = 0;
  // 目前頁數
  var iPageIdx = 0;
  // 總頁數
  var iPageCnt = 0;
  // 總高度-Data高度
  var iNonDataHeight = 0;
  // 記錄目前在資料中所選定的record number
  var iRecNo = -1;
  // 資料中所選定的Tr背景顏色
  var sBgcRowClicked = "#cedfff";
  // 記錄在Grid中所選定的Tr
  var oGridTr = null;
  // 目前編輯模式：ins,upd,del,qry,ref
  var sAction = "";
  var sOldAction = "";
  // 記錄Ajax跳頁where條件
  var sAjaxWhere = "";
  // Ajax呼叫元件
  var oAjax;

  if (window.XMLHttpRequest) { // If IE7, Mozilla, Safari, and so on
    oAjax = new XMLHttpRequest();
  } else { // for IE6, IE5
    var oIE = ["MSXML2.XMLHTTP.6.0", "MSXML2.XMLHTTP.5.0", "MSXML2.XMLHTTP.4.0", "MSXML2.XMLHTTP.3.0", "MSXML2.XMLHTTP", "Microsoft.XMLHTTP"];

    for (var i = 0; i < oIE.length && !oAjax; i++) {
      try {
        oAjax = new ActiveXObject(oIE[i]);
      } catch (e) {}
    }
  }

  Grid.count++;
  ID = Grid.count;

  if (config.imagePath) {
    if (config.imagePath.substring(config.imagePath.length - 1, config.imagePath.length) === "/") {
      sImagePath = config.imagePath;
    } else {
      sImagePath = config.imagePath + "/";
    }
  }

  if (config.pageSize) {
    iPageSize = Math.abs(config.pageSize);
    if (iPageSize < 5) { iPageSize = 5; }
  } else {
    iPageSize = 5;
  }

  if (screen.width <= 800) {
    iResolution = 800;
    iGridDataHeight = 121;
  } else {
    iResolution = screen.width;
    iGridDataHeight = 116 + (iPageSize - 5) * 22;
  }

  init();

// public
  this.setQueryURL = function(sURL) {
    config.queryURL = sURL;
  };

  this.load = function() {
    var oGrData, iRows;

    oGrData = arguments[0];

    if (typeof oGrData === "object") {
      var bSetGridSize = false;

      oRows = oGrData;

      if (arguments.length === 2) {
        iRows = arguments[1];
        if (iRowsCnt === 0 && iRows > 0 && iPageIdx === 1) { bSetGridSize = true; }
        iRowsCnt = iRows;
      } else {
        if (iRowsCnt === 0 && oRows.length > 0 && iPageIdx === 1) { bSetGridSize = true; }
        iRowsCnt = oRows.length;
      }

      if (iPageIdx === 0) {
        iPageIdx = 1;
        bSetGridSize = true;
      }

      iPageCnt = Math.ceil(iRowsCnt / iPageSize);
      this.setPage(iPageIdx);
      setGoToPage();
      if (iPageIdx === 1 && bSetGridSize) { setGridSize(false); }
    } else {
      iPageIdx = 0;
      if (arguments.length === 0) { this.callAjaxQuery(); }
      else { this.callAjaxQuery(arguments[0]); }
    }
  };

  this.callAjaxQuery = function() {
    var sParams = "hidAction=qry&iPageSize=" + iPageSize;

    if (sAction !== "ref") { sAction = "qry"; }

    if (arguments.length === 0) {
      sParams += "&iPageIdx=" + iPageIdx;
    } else if (arguments.length === 1) {
      if (! isNaN(arguments[0])) {
        sParams += "&iPageIdx=" + arguments[0];
        iPageIdx = parseFloat(arguments[0]);
      } else {
        if (arguments[0].length > 0) {
          var sTemp = "";

          if (arguments[0].charAt(0) !== "&") {  sTemp = "&" + arguments[0]; }
          else { sTemp = arguments[0]; }

          sParams += sTemp;
          if (config.pageAjax) { sAjaxWhere = sTemp; }
        }
      }
    }

    sParams += "&bPageAjax=";

    if (config.pageAjax) {
      sParams += "true";

      if (sAjaxWhere !== "") {
        // Ajax跳頁時，將之前的查詢條件帶入
        if (arguments.length === 0) {
          sParams += sAjaxWhere;
        } else if (arguments.length === 1) {
          if (! isNaN(arguments[0])) {
            sParams += sAjaxWhere;
          }
        }
      }
    } else { sParams += "false"; }

    this.callAjax(config.queryURL, sParams, this);
  };

  this.setPage = function(iGoToPage) {
    var iMin = 0, iMax = 0;
    var sHtml = "<table id='tbGridData" + ID + "' class='GridTable' style='width:" + iGridRealWidth + "px;' border='0' cellspacing='1' cellpadding='1'>" + sHideTr;

    iPageIdx = parseFloat(iGoToPage);

    if (! config.pageAjax) {
      if (iGoToPage > 0) {
        iMin = (iGoToPage - 1) * iPageSize;
      }

      if (config.pageSize <= 0) {
        iMax = iRowsCnt;
      } else {
         if (iGoToPage * iPageSize > iRowsCnt) {
           iMax = iRowsCnt;
        } else {
          iMax = iGoToPage * iPageSize;
        }
      }
    } else {
      iMin = 0;
      iMax = oRows.length;
    }

    for (var i = iMin; i < iMax; i++) {
      sHtml += "<tr class='GridDataTr" + (i % 2) + "' onclick='" + config.name + ".rowOnClick(this);'>";
      for (var j = 0; j < config.columns.length; j++) {
        sHtml += "<td";
        if (config.columns[j].data.align) { sHtml += " align='" + config.columns[j].data.align + "'"; }
        sHtml += ">" + getBlank(config.columns[j].data.align, "left");

        if (config.columns[j].data.setVal) {
          switch (typeof config.columns[j].data.setVal) {
            case "string":
              if (config.columns[j].data.setVal === ",") {
                sHtml += FormatNumber(oRows[i][config.columns[j].data.index]);
              } else {
                sHtml += oRows[i][config.columns[j].data.index];
              }
              break;
            case "function":
              sHtml += config.columns[j].data.setVal(oRows[i][config.columns[j].data.index], oRows[i], i);
              break;
            default :
              sHtml += oRows[i][config.columns[j].data.index];
          }
        } else {
          sHtml += oRows[i][config.columns[j].data.index];
        }
        sHtml += getBlank(config.columns[j].data.align, "right") + "</td>";
      }
      sHtml += "</tr>";
    }

    sHtml += "</table>";
    $("divGridData" + ID).innerHTML = sHtml;
    setPageImage();

    if (config.pageSize > 0) {
      if (iRowsCnt > 0) {
        $("sltGoToPage" + ID).options.selectedIndex = iGoToPage - 1;
      } else {
        $("sltGoToPage" + ID).options.selectedIndex = 0;
      }
    }
    setFooter();

    if (iGridDataTbHeight !== $("tbGridData" + ID).offsetHeight) {
      setGridSize(false);
    }
  };

  this.showPage = function(sGoTo) {
    var bShow = true;

    if (iRowsCnt === 0) { return; }

    switch (sGoTo) {
      case "first":
        if (iPageIdx !== 1) {
          iPageIdx = 1;
        } else {
          bShow = false;
        }
        break;
      case "prev":
        if (iPageIdx > 1) {
          iPageIdx--;
        } else {
          bShow = false;
        }
        break;
      case "next":
        if (iPageIdx !== iPageCnt) {
          iPageIdx++;
        } else {
          bShow = false;
        }
        break;
      case "last":
        if (iPageIdx !== iPageCnt) {
          iPageIdx = iPageCnt;
        } else {
          bShow = false;
        }
        break;
    }

    if (bShow) {
      if (! config.pageAjax) {
        this.setPage(iPageIdx);
      } else {
        this.callAjaxQuery();
      }
    }
  };

  this.setPageSize = function(iSize) {
    iGridDataHeight = iGridDataHeight / iPageSize * iSize;
    $("divGridData" + ID).style.height = iGridDataHeight + "px";
    $("divGrid" + ID).style.height = (iNonDataHeight + iGridDataHeight - 3) + "px";
    iPageSize = iSize;
    iPageIdx = 1;
    adjustGridSize();

    if (! config.pageAjax) {
      iPageCnt = Math.ceil(iRowsCnt / iPageSize);
      this.setPage(iPageIdx);
      setGoToPage();
      setGridSize(false);
    } else {
      iPageIdx = 0; // iPageIdx = 0，才能執行setGridSize()
      this.callAjaxQuery();
    }
  };

  this.rowOnClick = function (oTr) {
    if (config.dataBind) {
      if (sAction !== "ref") {
        sAction = "upd";
        if (config.dataBind.length > 0) {
          var sMode = "修改";

          if (! config.authority.upd) { sMode = "查詢"; }
          $("tdMode" + ID).innerHTML = "模式：" + sMode;
        }
      }

      if (oGridTr) {
        var oStl = getStyle("." + oGridTr.className);
        if (oStl) { oGridTr.style.backgroundColor = oStl.backgroundColor; }
      }

      oTr.style.backgroundColor = sBgcRowClicked;
      oGridTr = oTr;

      if (! config.pageAjax) {
        iRecNo = (iPageIdx - 1) * iPageSize + oTr.rowIndex - 1;
      } else {
        iRecNo = oTr.rowIndex - 1;
      }

      bindData();
    }
  };

  this.rowMoveClicked = function () {
    if (oGridTr) {
      var oStl = getStyle("." + oGridTr.className);
      if (oStl) { oGridTr.style.backgroundColor = oStl.backgroundColor; }
      iRecNo = -1;
      oGridTr = null;
    }
  };

  this.action = function () {
    return sAction;
  };

  this.rowInsMode = function () {
    sAction = "ins";
    this.rowMoveClicked();
    $("tdMode" + ID).innerHTML = "模式：新增";
    bindData();
  };

  this.rowCopyMode = function () {
    if (! oGridTr) {
      alert("尚未點選要複製的資料！");
    } else {
      sAction = "upd";
      bindData("copy");
      sAction = "ins";
      this.rowMoveClicked();
      $("tdMode" + ID).innerHTML = "模式：新增";
    }
  };

  this.rowDelMode = function () {
    if (! oGridTr) {
      alert("尚未點選要刪除的資料！");
    } else {
      if (confirm("是否刪除此筆資料？")) {
        sAction = "del";
        this.submit();
      }
    }
  };

  this.rowReset = function () {
     bindData();
  };

  this.submit = function () {
    var bOk = true;

    if (config.checkForm) {
      if (typeof config.checkForm === "function") {
        var oTar, oFrm;

        if (config.dataBind) {
          for (var i = 0; i < config.dataBind.length; i++) {
            oTar = $(config.dataBind[i].target);
            if (oTar) {
              oFrm = oTar.form;
              break;
            }
          }
        }
        bOk = config.checkForm(oFrm, sAction);
      }
    }

    if (bOk) {
      if (config.maintainURL) {
        this.callAjax(config.maintainURL, bindData("params"), this);
      } else {
        alert("請定義maintainURL參數！");
      }
    }
  };

  this.callAjax = function(sUrl, sParams, oGrid) {
    var sReturn = "";
    var oTar;

    this.waiting("show");
    this.setBindButton(true);
    oAjax.open("POST", sUrl, true);
    oAjax.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    oAjax.setRequestHeader("Content-length", sParams.length);
    oAjax.setRequestHeader("Connection", "close");
    oAjax.onreadystatechange = function() {
      var bOk = false, bRefresh = false;
      var sAlert = "", sMsg = "", sRefresh = "";
      var oGrData = null;
      var iRows = 0;

      if (oAjax.readyState === 4) {
        oGrid.waiting("hide");

        if (oAjax.status === 200) {
          if (! oAjax.responseText.match(/<html>/ig)) {
            eval(oAjax.responseText);

            if (bOk) {
              switch (sAction) {
                case "ins":
                  oGrid.rowIns();
                  break;
                case "upd":
                  oGrid.rowUpd();
                  break;
                case "del":
                  oGrid.rowDel();
                  break;
                case "qry":
                case "ref":
                  if (oGrData) {
                    if (config.pageAjax) { oGrid.load(oGrData, iRows); }
                    else { oGrid.load(oGrData); }
                  }

                  if (sAction === "ref") {
                    if (iRecNo >= 0) {
                      if (sOldAction === "upd") {
                        var oTa = $("tbGridData" + ID);
                        var oTr = oTa.rows[iRecNo + 1];

                        oGrid.rowOnClick(oTr);
                      }
                      sAction = sOldAction;
                    } else {
                      sAction = "qry";
                    }
                  }

                  break;
              }
            }

            if (bRefresh) { oGrid.refresh(sRefresh); }
          } else {
            document.write(oAjax.responseText);
          }
        } else {
          if (config.debug) { document.write(oAjax.responseText); }
          else { alert("Ajax呼叫程式失敗，失敗代碼：" + oAjax.status); }
        }

        if (! bOk || (sAction !== "del" && sAction !== "qry")) { oGrid.setBindButton(false); }
        if (sAlert !== "") {
          setTimeout("alert('" + sAlert + "')", 100);
        } else {
          if (sMsg !== "") { PopupWindow.show(sMsg); }
        }
      }
    };
    oAjax.send(sParams);
  };

  this.waiting = function(sShow) {
    var divWaiting = $("divGridWaiting");

    if (!divWaiting) {
      divWaiting = document.createElement("div");
      divWaiting.id = "divGridWaiting";
      divWaiting.style.position = "absolute";
      divWaiting.style.left = (Math.ceil((iGridWidth - 226) / 2)) + "px";
      divWaiting.style.top = (Math.ceil(($("divGridData" + ID).offsetHeight - 18) / 2)) + "px";
      divWaiting.style.width = "226px";
      divWaiting.style.height = "18px";
      divWaiting.style.zIndex = 999;
      divWaiting.innerHTML = "資料處理中，請稍候<img align='absbottom' src='" + sImagePath + "Waiting.gif'>";
      divWaiting.className = "GridWaiting";
      $("divGrid" + ID).appendChild(divWaiting);
    }

    if (sShow === "show") {
      sShow = "";
    } else {
      sShow = "none";
    }

    divWaiting.style.display = sShow;
  };

  this.setBindButton = function(bDisabled) {
    for (var i = 0; i < config.dataBind.length; i++) {
      oTar = $(config.dataBind[i].target);
      if (oTar) {
        if (oTar.type === "button" || oTar.type === "reset" || oTar.type === "submit") {
          oTar.disabled = bDisabled;
        }
      }
    }
  };

  this.rowIns = function() {
    var oNew = [];

    updArray(oNew);
    oRows.push(oNew);

    if (config.pageSize > 0) {
      iRowsCnt++;
      if (iRowsCnt === 1) { iPageCnt = 1; iPageIdx = 1; }
      if (iPageIdx === iPageCnt || iRowsCnt === 1) { this.setPage(iPageIdx); }
      if (iPageCnt !== Math.ceil(iRowsCnt / iPageSize) || iRowsCnt === 1) {
        iPageCnt = Math.ceil(iRowsCnt / iPageSize);
        setPageImage();
        setGoToPage();
      }
      if (iRowsCnt === iPageSize) { setGridSize(false); }
    } else {
      var oTa = $("tbGridData" + ID);
      var oNewTr = oTa.insertRow(-1);

      oNewTr.className = "GridDataTr" + (iRowsCnt % 2);
      oNewTr.onclick = function() { eval(config.name + ".rowOnClick(this);"); };

      for (var i = 0; i < config.columns.length; i++) {
        oTd = oNewTr.insertCell(i);
      }

      updGridTr(oNewTr, iRowsCnt);
      iRowsCnt++;
      iPageCnt = Math.ceil(iRowsCnt / iPageSize);
    }

    setFooter();
    this.rowInsMode();
  };

  this.rowUpd = function() {
    updArray(oRows[iRecNo]);
    updGridTr(oGridTr, iRecNo);
  };

  this.rowDel = function() {
    var i = 0;

    if (! config.pageAjax) {
      oRows.splice(iRecNo, 1);
      iRowsCnt--;
      iPageCnt = Math.ceil(iRowsCnt / iPageSize);

      if (config.pageSize > 0) {
        if (iPageIdx > iPageCnt || iRowsCnt === 0) {
          iPageIdx = iPageCnt;
          setGoToPage();
        }
        this.setPage(iPageIdx);
      } else {
        var oTa = $("tbGridData" + ID);
        oTa.deleteRow(oGridTr.rowIndex);

        for (i = iRecNo + 1; i <= iRowsCnt; i++) {
          if (oTa.rows(i).className === "GridDataTr0") {
            oTa.rows(i).className = "GridDataTr1";
          } else {
            oTa.rows(i).className = "GridDataTr0";
          }
        }

        setFooter();
      }

      iRecNo = -1;
      oGridTr = null;
      this.rowInsMode();
      sAction = "del";
    } else {
      this.rowInsMode();
      this.callAjaxQuery();
    }

    var oTar;

    for (i = 0; i < config.dataBind.length; i++) {
      oTar = document.getElementsByName(config.dataBind[i].target);
      if (oTar) {
        for (var j = 0; j < oTar.length; j++) {
          oTar[j].disabled = true;
        }
      } else {
        oTar = $(config.dataBind[i].target);
        if (oTar) { oTar.disabled = true; }
      }
    }

    if (config.dataBind.length > 0) {
      $("tdMode" + ID).innerHTML = "模式：&nbsp;&nbsp;&nbsp;&nbsp;";
    }
  };

  this.updRow = function(iNo, iIdx, sData) {
    oRows[iNo][iIdx] = sData;
  };

  this.getRows = function() {
    return oRows;
  };

  this.refresh = function(sRefresh) {
    sOldAction = sAction;
    sAction = "ref";
    if (sRefresh === "") { this.callAjaxQuery(); }
    else { this.callAjaxQuery(sRefresh); }
  };
};

Grid.count = 0;