﻿using System;
using System.Data;
using System.Web;
using Yuan;

public class Grid
{
    public static string GetData(string table, string fields, string orderBy, string where)
    {
        DataProvider dp = DataProvider.GetInstance();
        string sortAry = "", countSql = "", sql = "", ret = "";
        bool pageAjax = false;

        if (!string.IsNullOrWhiteSpace(HttpContext.Current.Request.Form["sortAry"]))
        {
            sortAry = HttpContext.Current.Request.Form["sortAry"].Trim();
        }

        if (sortAry != "")
        {
            string[] fieldsAry = fields.Split(',');
            string[] sortFields = sortAry.Split('|');
            orderBy = "";

            for (int i = 0; i <= sortFields.Length - 1; i++)
            {
                string[] sortField = sortFields[i].Split(',');
                orderBy += fieldsAry[Convert.ToInt32(sortField[0])] + " " + sortField[1] + ",";
            }

            orderBy = " order by " + orderBy.Substring(0, orderBy.Length - 1);
        }
        else
        {
            if (!string.IsNullOrWhiteSpace(orderBy))
            {
                orderBy = " order by " + orderBy;
            }
            else
            {
                orderBy = "";
            }
        }

        if (!string.IsNullOrWhiteSpace(HttpContext.Current.Request.Form["pageAjax"]))
        {
            if (Convert.ToString(HttpContext.Current.Request.Form["pageAjax"]).ToLower() == "true")
            {
                pageAjax = true;
            }
        }

        if (!string.IsNullOrWhiteSpace(where))
        {
            where = " where " + where;
        }
        else
        {
            where = "";
        }

        countSql = "select count(*) from " + table + where;
        ret = "";

        if (pageAjax)
        {
            string pageSql = "";
            int pageIdx = 1, pageSize = 5;
            double recCnt = dp.GetScalar(countSql);

            ret = "rows:" + recCnt.ToString() + ",";
            Int32.TryParse(HttpContext.Current.Request.Form["pageIdx"], out pageIdx);
            Int32.TryParse(HttpContext.Current.Request.Form["pageSize"], out pageSize);

            if (pageSize == 0)
            {
                pageSize = 5;
            }

            if (pageIdx == 0)
            {
                pageIdx = 1;
            }

            switch (dp.Database)
            {
                case DataProvider.DatabaseType.MSSql:
                    pageSql = "select * from (select " + fields + ",row_number() over(" + orderBy + ") as rownum from " + table + where + ") a where a.rownum between {0} and {1}";
                    break;
                case DataProvider.DatabaseType.OleDb:
                    string[] orderAry = orderBy.Replace(" order by ", "").Split(',');
                    string oppoOrderBy = "";

                    foreach (string order in orderAry)
                    {
                        string[] temp = order.Split(' ');

                        if (temp.Length == 1)
                        {
                            oppoOrderBy += temp[0] + " desc,";
                        }
                        else if (temp.Length == 2)
                        {
                            if (temp[1].Trim().ToLower() == "desc")
                            {
                                oppoOrderBy += temp[0] + ",";
                            }
                            else
                            {
                                oppoOrderBy += temp[0] + " desc,";
                            }
                        }
                    }

                    oppoOrderBy = " order by " + oppoOrderBy.Substring(0, oppoOrderBy.Length - 1);
                    pageSql = "select * from (select top {0} * from (select top {1} " + fields + " from " + table + where + orderBy + ") " + oppoOrderBy + ") " + orderBy;
                    break;
                case DataProvider.DatabaseType.Oracle:
                    pageSql = "select x.* from (select y.*,rownum serno from(select " + fields + " from " + table + where + orderBy + ") y where rownum<={1}) x where x.serno>={0}";
                    break;
            }

            switch (dp.Database)
            {
                case DataProvider.DatabaseType.MSSql:
                case DataProvider.DatabaseType.Oracle:
                    sql = string.Format(pageSql, (pageIdx - 1) * pageSize + 1, pageIdx * pageSize);
                    break;
                case DataProvider.DatabaseType.OleDb:
                    int pageCnt = pageSize;

                    if (Math.Ceiling(recCnt / pageSize) == pageIdx)
                    {
                        pageCnt = (int)recCnt % pageSize;
                        if (pageCnt == 0)
                        {
                            pageCnt = pageSize;
                        }
                    }

                    sql = string.Format(pageSql, pageCnt, pageIdx * pageSize);
                    break;
            }
        }
        else
        {
            sql = "select " + fields + " from " + table + where + orderBy;
        }

        ret += GetRows(sql, dp);
        return ret;
    }

    public static string GetData(string table, string fields, string orderBy)
    {
        return GetData(table, fields, orderBy, "");
    }

    public static string GetData(string sql)
    {
        DataProvider dp = DataProvider.GetInstance();

        return GetRows(sql, dp);
    }

    public static string GetRows(string sql, DataProvider dp)
    {
        string tmp = "", ret = "";
        System.Text.StringBuilder sbData = new System.Text.StringBuilder();
        System.Data.Common.DbDataReader dr = (System.Data.Common.DbDataReader)dp.GetReader(sql);
        sbData.Append("grData:[");

        while (dr.Read()) {
            tmp = "[";

            for (int i = 0; i <= dr.FieldCount - 1; i++)
            {
                if (dr.IsDBNull(i))
                {
                    tmp += "\"\",";
                }
                else
                {
                    if (dr.GetFieldType(i) != typeof(string))
                    {
                        tmp += "\"" + dr[i].ToString() + "\",";
                    }
                    else
                    {
                        tmp += "\"" + dr[i].ToString().Replace("\\", "\\\\").Replace(Environment.NewLine, "\\n").Replace("\"", "\\\"").Replace("'", "\\'") + "\",";
                    }
                }
            }

            sbData.Append(tmp.Substring(0, tmp.Length - 1) + "],");
        }

        ret = sbData.ToString();

        if (dr.HasRows)
        {
            ret = ret.Substring(0, ret.Length - 1);
        }

        dr.Close();
        return ret + "]";
    }

    public static string GetTotal(string table, string fields, string where, string total)
    {
        DataProvider dp = DataProvider.GetInstance();
        string sql = "", ret = "";
        System.Text.StringBuilder sbTmp = new System.Text.StringBuilder();
        string[] fieldsArt = fields.Split(',');
        string[] totalFields = total.Split('|');

        for (int i = 0; i <= totalFields.Length - 1; i++)
        {
            string[] totalField = totalFields[i].Split(',');

            if (totalField[1].Trim() == "distinctCount")
            {
                sql += "count(distinct " + fieldsArt[Convert.ToInt32(totalField[0])] + "),";
            }
            else
            {
                sql += totalField[1] + "(" + fieldsArt[Convert.ToInt32(totalField[0])] + "),";
            }
        }

        sql = "select " + sql.Substring(0, sql.Length - 1) + " from " + table;

        if (!string.IsNullOrWhiteSpace(where))
        {
            sql += " where " + where;
        }

        System.Data.Common.DbDataReader dr = (System.Data.Common.DbDataReader)dp.GetReader(sql);
        dr.Read();
        sbTmp.Append("sql:\"" + sql + "\",");
        sbTmp.Append("totData:[");

        for (int i = 0; i <= dr.FieldCount - 1; i++)
        {
            sbTmp.Append("\"" + dr[i].ToString() + "\",");
        }

        ret = sbTmp.ToString();
        return ret.Substring(0, ret.Length - 1) + "]";
    }
}