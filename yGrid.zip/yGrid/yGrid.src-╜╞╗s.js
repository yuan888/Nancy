﻿var yGrInit = false;

var PopupWindow = function (msg) {
  this.message = msg;
};

PopupWindow.popSCnt = 0;
PopupWindow.popHCnt = 0;
PopupWindow.popTimeId = new Array(12);

PopupWindow.show = function (msg) {
  PopupWindow.popSCnt++;
  var cnt = PopupWindow.popSCnt, divPop = document.getElementById("divPop" + cnt);

  if (! divPop) {
    divPop = document.createElement("div");
    divPop.id = "divPop" + cnt;
    divPop.style.position = "absolute";
    divPop.style.width = "200px";
    divPop.style.height = "82px";
    divPop.style.right = "30px";
    divPop.style.overflow = "hidden";
    divPop.style.filter = "alpha(opacity=100)";
    divPop.style.zIndex = 99 - cnt;
    divPop.innerHTML = "<table class='yPopBorder' border='0' cellpadding='0' cellspacing='0'>" +
      "<tr><td width='10' class='yPopHead1'>&nbsp;</td>" +
      "<td width='185' height='22' align='center' valign='bottom' class='yPopHead1' onmouseover=\"this.className='yPopHead2';\" onmouseout=\"this.className='yPopHead1';\">&nbsp;系統訊息</td>" +
      "<td class='yPopHead1' align='left'>" +
      "<span class='yPopX1' onclick='PopupWindow.close(" + cnt + ");' onmouseover=\"this.className='yPopX2';\" onmouseout=\"this.className='yPopX1';\">X</span> " +
      "</td></tr><tr>" +
      "<td width='10' class='yPopText'>&nbsp;</td>" +
      "<td id='tdPopupMsg" + cnt + "' height='58' colspan='2' valign='middle' class='yPopText'></td>" +
      "</tr></table>";
    document.body.appendChild(divPop);
  }

  document.getElementById("tdPopupMsg" + cnt).innerHTML = msg;
  divPop.style.bottom = ((cnt - 1) * parseFloat(divPop.style.height.replace("px", ""))) + "px";

  if (window.ActiveXObject) {
    divPop.filters.alpha.opacity = 100;
  } else {
    divPop.style.opacity = 1;
  }

  divPop.style.display = "";
  PopupWindow.popTimeId[cnt - 1] = setInterval("PopupWindow.move(" + cnt + ")", 10);
};

PopupWindow.move = function (cnt) {
  var divPop = document.getElementById("divPop" + cnt);

  if (divPop.style.display === "") {
    var popH = parseFloat(divPop.style.bottom.replace("px", "")) + 1;
    divPop.style.bottom = popH + "px";

    if (popH >= (cnt * parseFloat(divPop.style.height.replace("px", "")) - 30)) {
      clearInterval(PopupWindow.popTimeId[cnt - 1]);
      PopupWindow.popTimeId[cnt - 1] = setInterval("PopupWindow.hide1(" + cnt + ")", 4000);
    }
  } else {
    clearInterval(PopupWindow.popTimeId[cnt - 1]);
  }
};

PopupWindow.hide1 = function (cnt) {
  var divPop = document.getElementById("divPop" + cnt);
  clearInterval(PopupWindow.popTimeId[cnt - 1]);

  if (divPop.style.display === "") {
    PopupWindow.popTimeId[cnt - 1] = setInterval("PopupWindow.hide2(" + cnt + ")", 100);
  }
};

PopupWindow.hide2 = function (cnt) {
  var divPop = document.getElementById("divPop" + cnt);

  if (divPop.style.display === "") {
    var popOpa;

    if (window.ActiveXObject) {
      popOpa = parseFloat(divPop.filters.alpha.opacity);
      divPop.filters.alpha.opacity = popOpa - 4;
    } else {
      popOpa = parseFloat(divPop.style.opacity);
      divPop.style.opacity = popOpa - 0.04;
    }

    if (popOpa <= 0.04) {
      clearInterval(PopupWindow.popTimeId[cnt - 1]);
      divPop.style.display = "none";
      PopupWindow.popHCnt++;

      if (PopupWindow.popSCnt === PopupWindow.popHCnt) {
        PopupWindow.popSCnt = 0;
        PopupWindow.popHCnt = 0;
      }
    }
  } else {
    clearInterval(PopupWindow.popTimeId[cnt - 1]);
  }
};

PopupWindow.close = function (cnt) {
  var divPop = document.getElementById("divPop" + cnt);
  divPop.style.display = "none";
  PopupWindow.popHCnt++;

  if (PopupWindow.popSCnt === PopupWindow.popHCnt) {
    PopupWindow.popSCnt = 0;
    PopupWindow.popHCnt = 0;
  }
};

var yGrid = function (config) {
// private
  function $(id) {
    var obj = document.getElementById(id);

    if (! obj) {
      var tmp = document.getElementsByName(id);
      if (tmp) {
        obj = tmp[0];
      }
    }

    return obj;
  }

  function log(msg) {
    if (config.debug) {
      if (window.console && window.console.log) {
        window.console.log("yGrid: " + msg);
      }
    }
  }

  function runJS(js) {
    var script = document.createElement("SCRIPT");

    document.body.appendChild(script);
    script.text = js;
    document.body.removeChild(script);
  }

  function round(num, dec) {
    if (num >= 0) {
      return Math.floor(num * Math.pow(10, dec) + 0.5) / Math.pow(10, dec);
    } else {
      return Math.ceil(num * Math.pow(10, dec) - 0.5) / Math.pow(10, dec);
    }
  }

  function floatMul(v1, v2) {
    var m = 0, s1 = v1.toString(), s2 = v2.toString();

    try { m += s1.split(".")[1].length; } catch (e) { }
    try { m += s2.split(".")[1].length; } catch (e) { }
    return Number(s1.replace(".", "")) * Number(s2.replace(".", "")) / Math.pow(10, m);
  }

  function formatNumber() {
    var val, ifMinus = false, num = "", l = "", r = "", ret = "", d = 0, p = 0, i = 0, j = 0;

    val = parseFloat(arguments[0]);

    if (arguments.length === 2) {
      d = parseInt(arguments[1], 10);
      val = round(val, d);
    }

    if (val < 0) {
      ifMinus = true;
      num = (- val).toString();
    } else {
      num = val.toString();
    }

    p = num.indexOf(".");
    if (p > 0) {
      l = num.substring(0, p);
      r = num.substring(p + 1);
    } else {
      l = num;
      r = "";
    }

    for (i = l.length - 1; i >= 0; i--) {
      ret = l.charAt(i) + ret;
      if (i && (++j % 3 === 0)) { ret = "," + ret; }
    }

    if (arguments.length === 2 && r.length < d) {
      p = 1;
      for (i = r.length + 1; i <= d; i++) {
        r += "0";
      }
    }

    if (ifMinus) { ret = "-" + ret; }
    if (p > 0) { ret = ret + "." + r; }

    return ret;
  }

  function formatDate(dt, fmt) {
    var sec = dt.getSeconds(), min = dt.getMinutes(), hr = dt.getHours(), d = dt.getDate(), m = dt.getMonth(), y = dt.getFullYear(), f = [];
    var re = /(.*)(\W|^)(H|HH|m|mm|s|ss|d|dd|M|MM|y|yy|yyy|yyyy|Md|Mdd|yMMdd|yyMMdd|yyyMMdd|yyyyMMdd)(\W|$)(.*)/;

    f["s"] = sec;
    f["ss"] = (sec < 10) ? ("0" + sec) : sec;
    f["m"] = min;
    f["mm"] = (min < 10) ? ("0" + min) : min;
    f["H"] = hr;
    f["HH"] = (hr < 10) ? ("0" + hr) : hr;
    f["d"] = d;
    f["dd"] = (d < 10) ? ("0" + d) : d;
    f["M"] = 1 + m;
    f["MM"] = (m < 9) ? ("0" + (1 + m)) : (1 + m);
    f["y"] = y;
    f["yy"] = new String(y).substr(2, 2);
    f["yyy"] = y - 1911;
    f["yyyy"] = y;
    f["yMMdd"] = f["y"] + "" + f["MM"] + f["dd"];
    f["yyMMdd"] = f["yy"] + "" + f["MM"] + f["dd"];
    f["yyyMMdd"] = f["yyy"] + "" + f["MM"] + f["dd"];
    f["yyyyMMdd"] = f["y"] + "" + f["MM"] + f["dd"];

    fmt = fmt.replace("HHmmss", f["HH"] + "" + f["mm"] + f["ss"]);
    fmt = fmt.replace("HHmm", f["HH"] + "" + f["mm"]);

    while (re.exec(fmt) !== null) {
      fmt = RegExp.$1 + RegExp.$2 + f[RegExp.$3] + RegExp.$4 + RegExp.$5;
    }

    return fmt;
  }

  function getAbsolutePos(t) {
    var p = { x: t.offsetLeft, y: t.offsetTop };
    if (t.offsetParent) {
      var obj = getAbsolutePos(t.offsetParent);
      p.x += obj.x;
      p.y += obj.y;
    }
    return p;
  }

  function appendStyle(styles) {
    var css = document.createElement("style");

    css.type = "text/css";

    if (css.styleSheet) css.styleSheet.cssText = styles;
    else css.appendChild(document.createTextNode(styles));

    document.getElementsByTagName("head")[0].appendChild(css);
  }

  function getParamValue(pars, tag) {
    var ary = pars.split("&"), i;

    for (i = 0 ; i < ary.length ; i++) {
      if (ary[i].indexOf("=") > 0 && tag === ary[i].substring(0, ary[i].indexOf("="))) {
        return unescape(ary[i].substring(ary[i].indexOf("=") + 1, ary[i].length));
      }
    }

    return "";
  }

  function convertData(val, format) {
    var ret = val, ary, tmp, s = "", d = "", p = "", dtf = "", reg = /{0(:[NPdgGstT]\d{0,}|)}/;

    ary = format.match(reg);

    if (ary) {
      if (ary[1] === "") {
        ret = format.replace("{0}", val);
      } else if (! isNaN(val) && val.replace(/ /g, "") !== "") {
        s = ary[1].substring(1, 2);

        if (s === "N" || s === "P") {
          if (ary[1].length > 2) {
            d = ary[1].replace(":" + s, "");
          }

          if (s === "P") {
            val = floatMul(parseFloat(val), 100);
            p = "%";
          }

          if (d === "") {
            ret = formatNumber(val);
          } else {
            ret = formatNumber(val, parseInt(d, 10));
          }

          ret += p;
          ret = format.replace("{0:" + s + d + "}", ret);
        }
      } else {
        switch (ary[1].substring(1, 2)) {
          case "d":
            dtf = "MM/dd/yyyy";
            break;
          case "g":
            dtf = "MM/dd/yyyy HH:mm";
            break;
          case "G":
            dtf = "MM/dd/yyyy HH:mm:ss";
            break;
          case "s":
            dtf = "yyyy-MM-dd HH:mm:ss";
            break;
          case "t":
            dtf = "HH:mm";
            break;
          case "T":
            dtf = "HH:mm:ss";
            break;
        }
      }
    } else {
      reg = /{0:([yMdHms:\-\/ ]{1,})}/;
      ary = format.match(reg);
      if (ary && ary[1].replace(/ /g, "").length > 1) { dtf = ary[1]; }
    }

    if (dtf !== "") {
      tmp = convertDateTime(val);

      if (tmp === 0) { tmp = convertTime(val); }
      if (tmp !== 0) { ret = format.replace(ary[0], formatDate(new Date(tmp), dtf)); }
    }

    return ret;
  }

  function adjustGridSize() {
    // 預先塞入pageSize大小的筆數，以得到Grid高度。
    var i, html = "<table id='tbGridData" + ID + "' class='yGrTable' style='width:" + dataTbW + "px;' border='0' cellspacing='1' cellpadding='1'>" + hideTr, divGD = $("divGridData" + ID);

    for (i = 0; i < pageSize; i++) {
      html += "<tr class='yGrDataTr" + (i % 2) + "'><td colspan='" + config.columns.length + "'>　&nbsp;</td></tr>";
    }

    divGD.innerHTML = html + "</table>";

    if (totalSize === 1) {
      pageSizeTbH = $("tbGridData" + ID).offsetHeight;
      html += "<tr class='yGrDataTr" + (i % 2) + "'><td colspan='" + config.columns.length + "'>　&nbsp;</td></tr>";
      divGD.innerHTML = html + "</table>";
    }

    setGridSize(true);
    divGD.innerHTML = "";
  }

  function init() {
    var tmp = "", header = "", fzHeader = "", html = "", fzHtml = "", hide = "", headCols = 0, ifFzHd = false, i = 0, w = 0;

    if (typeof config.imagePath === "string") {
      if (config.imagePath.substring(config.imagePath.length - 1, config.imagePath.length) === "/") {
        imgPath = config.imagePath;
      } else {
        imgPath = config.imagePath + "/";
      }
    }

    if (! yGrInit) {
      var styles = ".yGrTitleSort{background:url(" + imgPath + "ySort.gif) no-repeat right center;background-color:#def;cursor: pointer;}" +
        ".yGrTitleSortA{background-image:url(" + imgPath + "yAsc.gif);}" +
        ".yGrTitleSortD{background-image:url(" + imgPath + "yDesc.gif);}" +
        ".yGrToolbar table{table-layout:fixed;background-image:url(" + imgPath + "yFooterBG.gif);background-position:0 0;}" +
        ".yGrImg{background-image:url(" + imgPath + "yGrid.gif);height:19px;}" +
        "a.yGrButton:hover {background: url(" + imgPath + "yButtonBG.gif) no-repeat center center;}";

      appendStyle(styles);
    }

    if (typeof config.pageSize === "number") {
      pageSize = Math.abs(config.pageSize);
      if (pageSize < 5) { pageSize = 5; }

      if (config.pageSize <= 0) {
        config.pageAjax = false;
        config.pageSizeList = null;
      }
    } else {
      pageSize = 5;
      config.pageSize = pageSize;
    }

    if (typeof config.gridWidth !== "number") {
      config.gridWidth = 0;
    }

    if (config.gridWidth !== 0) {
      gridW = config.gridWidth;

      if (typeof config.freezeCols === "number") {
        if (config.freezeCols > config.columns.length) {
          config.freezeCols = 0;
        }
      } else {
        config.freezeCols = 0;
      }
    } else { // auto
      config.freezeCols = 0;
    }

    if (typeof config.gridHeight !== "number") {
      config.gridHeight = 0;
    }

    if (typeof config.hideToolbar !== "boolean" || config.pageSize > 0) {
      config.hideToolbar = false;
    }

    // 組Grid Title
    hideTr = "<tr style='height:auto;'>";
    fzHideTr = hideTr;
    html = "<tr class='yGrTitle' style='line-height:20px;'>";
    fzHtml = html;

    for (i = 0; i < config.columns.length; i++) {
      w = config.columns[i].width;

      config.columns[i].width = w;
      dataTbW += w + 1;
      tmp = "<th";

      if (config.columns[i].sort) {
        sortCnt++;
        tmp += " class='yGrTitleSort' onclick='" + config.name + ".sortOnClick(this," + config.columns[i].data.index + ");'";
      }

      if (config.columns[i].title.align) { tmp += " align='" + config.columns[i].title.align + "'"; }

      if (i >= config.freezeCols) {
        hideTr += "<th style='height:0px;width:" + w + "px;' />";
        html += tmp + ">" + config.columns[i].title.word + getBlank(config.columns[i].title.align, "right", config.columns[i].sort) + "</th>";
      } else {
        fzHideTr += "<th style='height:0px;width:" + w + "px;' />";
        fzHtml += tmp + ">" + config.columns[i].title.word + getBlank(config.columns[i].title.align, "right", config.columns[i].sort) + "</th>";
      }

      if (config.columns[i].total) { totalSize = 1; }
    }

    hideTr += "</tr>";
    fzHideTr += "</tr>";
    html += "</tr>";
    fzHtml += "</tr>";

    if (config.header) {
      header = "<tr class='yGrTitle' style='line-height:20px;'>";
      fzHeader = header;

      for (i = 0; i < config.header.length; i++) {
        headCols += config.header[i].title.colsapn;
        tmp = "<th colspan='" + config.header[i].title.colsapn + "'";
        if (config.header[i].title.align) { tmp += " align='" + config.header[i].title.align + "'"; }
        tmp += ">" + config.header[i].title.word + "</th>";

        if (headCols > config.freezeCols) {
          header += tmp;
        } else {
          fzHeader += tmp;
        }

        if (config.freezeCols > 0 && headCols === config.freezeCols) {
          ifFzHd = true;
        }
      }

      header += "</tr>";

      if (headCols !== config.columns.length || (config.freezeCols > 0 && ! ifFzHd)) {
        header = "";
        fzHeader = "";
      }
    }

    dataDivH = 116 + (pageSize + totalSize - 5) * 22;

    if (gridW === 0) gridW = dataTbW;

    html = "<div id='divGrid" + ID + "' class='yGrContainer yGrDivRel' style='top:0px;width:" + (gridW + scrollW) + "px;'>" +
      "<div id='divGridHead" + ID + "' class='yGrDivRel' style='top:0px;width:" + gridW + "px;z-index:2'>" +
      "<table id='tbGridHead" + ID + "' class='yGrTable' style='margin-top:-4px;width:" + dataTbW + "px;' border='0' cellspacing='1' cellpadding='1'>" +
      hideTr + header + html + "</table></div>" +
      "<div id='divGridData" + ID + "' class='yGrDivRel' style='overflow:scroll;top:" + (opera ? -2 : -4) + "px;width:" + (gridW + scrollW) + "px;height:" + dataDivH + "px;z-index:1' onscroll='" + config.name + ".gridOnScroll(this)'></div>" +
      "<div id='divGridFooter" + ID + "' class='yGrToolbar yGrDivRel' style='top:0px;width:" + (gridW + scrollW) + "px;z-index:9'>" +
      "<table class='yGrTable' border='0' width='100%' cellspacing='1' cellpadding='1'><tr height='25'><td valign='top'>";

    // 導入Footer列內容
    var hasBlock = false, splitHtm = "<img class='yGrImg yGrSplit' src='" + imgPath + "yImgTrans.gif' align='absmiddle'>";

    if (config.pageSize > 0) {
      var func = "setPage";

      if (config.pageAjax) { func = "callAjaxQuery"; }
      html += "<a id='aGridFirst" + ID + "' class='yGrButtonDis' hideFocus href='javascript:" + config.name + ".showPage(\"first\");' title='第一頁'><img id='imgGridFirst" + ID + "' class='yGrImg yGrFirstDis' src='" + imgPath + "yImgTrans.gif'></a>" +
        "<a id='aGridPrev" + ID + "' class='yGrButtonDis' hideFocus href='javascript:" + config.name + ".showPage(\"prev\");' title='上一頁'><img id='imgGridPrev" + ID + "' class='yGrImg yGrPrevDis' src='" + imgPath + "yImgTrans.gif'></a>" +
        "<a id='aGridNext" + ID + "' class='yGrButtonDis' hideFocus href='javascript:" + config.name + ".showPage(\"next\");' title='下一頁'><img id='imgGridNext" + ID + "' class='yGrImg yGrNextDis' src='" + imgPath + "yImgTrans.gif'></a>" +
        "<a id='aGridLast" + ID + "' class='yGrButtonDis' hideFocus href='javascript:" + config.name + ".showPage(\"last\");' title='末頁'><img id='imgGridLast" + ID + "' class='yGrImg yGrLastDis' src='" + imgPath + "yImgTrans.gif'></a>" +
        splitHtm + "第 <select id='sltGoToPage" + ID + "' onchange='" + config.name + "." + func + "(this.value)'></select> 頁";
      hasBlock = true;
    } else {
      config.pageAjax = false;
    }

    if (config.pageSizeList) {
      var tmp = "", slted = "", ifSlted = false;

      if (config.pageSize > 0) {
        tmp = "每頁";
      } else {
        tmp = "顯示";
      }

      if (hasBlock) { html += splitHtm; }
      html += tmp + " <select onchange='" + config.name + ".setPageSize(this.value)'>";

      for (i = 0; i < config.pageSizeList.length; i++) {
        if (config.pageSizeList[i] === pageSize) {
          slted = " selected";
          ifSlted = true;
        } else {
          slted = "";
        }
        if (! ifSlted && pageSize < config.pageSizeList[i]) {
          html += "<option value='" + pageSize + "' selected>" + pageSize + "</option>";
          ifSlted = true;
        }
        html += "<option value='" + config.pageSizeList[i] + "'" + slted + ">" + config.pageSizeList[i] + "</option>";
      }

      html += "</select> 筆";
      hasBlock = true;
    }

    var mode = "模式:新增", modeW = 82, stl = null;

    if ((config.dataBind  && config.dataBind.length >= 0) && config.authority && (config.authority.ins || config.authority.upd || config.authority.del)) {
      if (hasBlock && (config.authority.ins || config.authority.del)) { html += splitHtm; }

      if (config.authority.ins) {
        html += "<a class='yGrButton' hideFocus href='javascript:" + config.name + ".rowInsMode();' title='新增'><img class='yGrImg yGrRowAdd' src='" + imgPath + "yImgTrans.gif'></a>" +
          "<a class='yGrButton' hideFocus href='javascript:" + config.name + ".rowCopyMode();' title='複製'><img class='yGrImg yGrRowCopy' src='" + imgPath + "yImgTrans.gif'></a>";
      } else {
        mode = "模式:查詢";
        action = "qry";
      }
      if (config.authority.del) {
        html += "<a class='yGrButton' hideFocus href='javascript:" + config.name + ".rowDelMode();' title='刪除'><img class='yGrImg yGrRowDel' src='" + imgPath + "yImgTrans.gif'></a>";
      }
      if (config.authority.ins || config.authority.del) {
        hasBlock = true;
        config.hideToolbar = false;
      }
    } else {
      mode = "";
      modeW = 1;
      action = "";
      aftQryAddMode = false;
    }

    if (sortCnt > 1) {
      if (hasBlock) { html += splitHtm; }
      hasBlock = true;
      html += "<a class='yGrButton' hideFocus href='javascript:" + config.name + ".sortConfig();' title='排序'><img class='yGrImg yGrOrder' src='" + imgPath + "yImgTrans.gif'></a>";
    }

    if (hasBlock) { html += splitHtm; }
    html += "<span id='spPagerInfo" + ID + "' /></td><td id='tdMode" + ID + "' valign='top' width='" + modeW + "'>" + mode + "</td>" +
      "</tr></table></div></div>";

    $(config.target).innerHTML = html;
    adjustGridSize();

    if (config.checkForm) {
      if (typeof config.checkForm === "function") {
        var tar, frm;

        if (config.dataBind) {
          for (i = 0; i < config.dataBind.length; i++) {
            tar = $(config.dataBind[i].target);
            if (tar) {
              frm = tar.form;
              break;
            }
          }
        }

        if (frm) {
          frm.onsubmit = function() {
            runJS(config.name + ".submit()");
            return false;
          };
        }
      }
    }

    if (config.freezeCols > 0) {
      var divGH = $("divGridHead" + ID), tbGH = $("tbGridHead" + ID), divGD = $("divGridData" + ID);
      var divGr = $("divGrid" + ID), divFH = document.createElement("div"), divFD = document.createElement("div");

      fzHtml = "<table id='tbGridFH" + ID + "' class='yGrTable' style='margin-top:-4px;height:" +
        tbGH.offsetHeight + "px' border='0' cellspacing='1' cellpadding='1'>" + fzHideTr + fzHeader + fzHtml + "</table>";
      divFH.id = "divGridFH" + ID;
      divFH.className = "yGrDivAbs";
      divFH.style.height = divGH.offsetHeight + "px";
      divFH.style.zIndex = 6;
      divFH.style.top = "0px";
      divFH.innerHTML = fzHtml;
      divGr.appendChild(divFH);
      fzW = $("tbGridFH" + ID).offsetWidth;
      divFH.style.width = fzW + "px";
      divFD.id = "divGridFD" + ID;
      divFD.className = "yGrDivAbs";
      divFD.style.width = fzW + "px";
      divFD.style.height = (divGD.offsetHeight - scrollW - (opera ? 2 : 0)) + "px";
      divFD.style.zIndex = 5;
      divFD.style.top = (divGH.offsetHeight - (opera ? 2 : 4)) + "px";
      divGr.appendChild(divFD);
      divGH.style.left = (fzW - 2) + "px";
      divGD.style.left = (fzW - 2) + "px";
      dataTbW = tbGH.offsetWidth - fzW + 2;
      tbGH.style.width = dataTbW + "px";
      divGH.style.width = (divGH.offsetWidth - fzW + 2) + "px";
      divGD.style.width = (divGD.offsetWidth - fzW + 2) + "px";
    }

    if (totalSize === 1) {
      var divGr = $("divGrid" + ID), divGH = $("divGridHead" + ID), divGD = $("divGridData" + ID), divGrTt = document.createElement("div");

      divGrTt.id = "divGridTt" + ID;
      divGrTt.className = "yGrDivAbs";
      divGrTt.style.width = (divGD.offsetWidth - scrollW) + "px";
      divGrTt.style.zIndex = 7;
      divGrTt.style.top = (divGH.offsetHeight + pageSizeTbH - 5) + "px";
      divGr.appendChild(divGrTt);

      if (config.freezeCols > 0) {
        var divFT = document.createElement("div");

        divFT.id = "divGridFT" + ID;
        divFT.className = "yGrDivAbs";
        divFT.style.width = fzW + "px";
        divFT.style.zIndex = 8;
        divFT.style.top = divGrTt.style.top;
        divGr.appendChild(divFT);
        divGrTt.style.left = (fzW - 2) + "px";
      }
    }

    if (config.pageSize !== 0) {
      hideToolbar();
    }

    if (action === "ins") {
      bindData(); //使編輯欄位為Add Mode
    }
  }

  function hideToolbar() {
    var divGF = $("divGridFooter" + ID);

    if (config.hideToolbar && divGF.style.display !== "none") {
      divGF.style.display = "none";
      $("divGrid" + ID).style.height = ($("divGrid" + ID).offsetHeight - 6) + "px";
    }
  }

  function getBlank(align, dir, sorted) {
    var ret = "";

    if (align) {
      if (align.toLowerCase() === dir && sorted) {
        ret = "&nbsp;&nbsp;";
      }
    }

    return ret;
  }

  function setPageImage() {
    if (pageIdx === 1 || pageIdx === 2 || pageIdx === (pageCnt - 1) || pageIdx === pageCnt) {
      if (config.pageSize > 0) {
        var first = "", last = "";

        if (pageIdx === 1 || rowsCnt === 0) { first = "Dis"; }
        if (pageIdx === pageCnt || rowsCnt === 0) { last = "Dis"; }

        $("aGridFirst" + ID).className = "yGrButton" + first;
        $("aGridPrev" + ID).className = "yGrButton" + first;
        $("aGridNext" + ID).className = "yGrButton" + last;
        $("aGridLast" + ID).className = "yGrButton" + last;
        $("imgGridFirst" + ID).className = "yGrImg yGrFirst" + first;
        $("imgGridPrev" + ID).className = "yGrImg yGrPrev" + first;
        $("imgGridNext" + ID).className = "yGrImg yGrNext" + last;
        $("imgGridLast" + ID).className = "yGrImg yGrLast" + last;
      }
    }
  }

  function setGoToPage() {
    if (config.pageSize > 0) {
      var pages = pageCnt, i;

      if (pages === 0) { pages = 1; }
      $("sltGoToPage" + ID).length = 0;
      for (i = 1; i <= pages; i++) {
        $("sltGoToPage" + ID).options[i - 1] = new Option(i, i);
      }
      if (rowsCnt > 0) {
        $("sltGoToPage" + ID).options.selectedIndex = pageIdx - 1;
      } else {
        $("sltGoToPage" + ID).options.selectedIndex = 0;
      }
    }
  }

  function setFooter() {
    var no1 = 0, no2 = 0;

    if (rowsCnt > 0) {
      no1 = (pageIdx - 1) * pageSize + 1;
      no2 = pageIdx * pageSize;
      if (no2 > rowsCnt) { no2 = rowsCnt; }
    }

    if (config.pageSize > 0) {
      $("spPagerInfo" + ID).innerHTML = "第" + no1 + "~" + no2 + "筆,共" + pageCnt + "頁" + rowsCnt + "筆資料";
    } else {
      $("spPagerInfo" + ID).innerHTML = "共" + rowsCnt + "筆資料";
    }
  }

  function setGridSize(adjHeight) {
    var divGr = $("divGrid" + ID), divGD = $("divGridData" + ID), tbGD = $("tbGridData" + ID), divFD;

    if (config.gridWidth === 0) { // 微調Grid寬度，避免scroll bar出現
      var divGH = $("divGridHead" + ID), tbGH = $("tbGridHead" + ID);

      dataTbW = tbGD.offsetWidth;
      divGH.style.width = dataTbW + "px";
      tbGH.style.width =  dataTbW + "px";
      divGD.style.width = (dataTbW + scrollW) + "px";

      if (pageIdx !== 0 || ! ie678) { //IE678在init()執行到divGD.scrollLeft=1會有錯
        do {
          divGD.scrollLeft = 1;
          if (divGD.scrollLeft > 0) {
            divGD.style.width = (divGD.offsetWidth + 1) + "px";
          }
        } while (divGD.scrollLeft > 0);
      }

      gridW = divGD.offsetWidth - scrollW;
      divGr.style.width = divGD.style.width;
      divGH.style.width = (divGD.offsetWidth - scrollW) + "px";
      $("divGridFooter" + ID).style.width = divGD.style.width;
    }

    // 記住塞滿Page Size資料後之Data Table Height
    dataTbH = tbGD.offsetHeight;

    if (config.gridHeight === 0) { // 微調Grid高度，避免scroll bar出現
      // 最後一頁如果資料數不滿一頁不做
      if ((rowsCnt >= pageIdx * pageSize && config.pageSize > 0) || adjHeight) {
        dataDivH = dataTbH + scrollW;
        divGD.style.height = dataDivH + "px";

        if (pageIdx !== 0 || ! ie678) { //IE678在init()執行到divGD.scrollTop=1會有錯
          do {
            dataDivH--;
            divGD.style.height = dataDivH + "px";
            divGD.scrollTop = 1;
          } while (divGD.scrollTop === 0);

          while (divGD.scrollTop > 0) {
            dataDivH++;
            divGD.style.height = dataDivH + "px";
            divGD.scrollTop = 1;
          }
        }

        scrollW = divGD.offsetHeight - dataTbH;
        divFD = $("divGridFD" + ID);
        if (divFD) { divFD.style.height = (dataTbH - (opera ? 2 : 0)) + "px"; }
      }
    } else { // fixed
      dataDivH = config.gridHeight - nonDataH;
    }

    if (nonDataH === 0) { nonDataH = divGr.offsetHeight - dataDivH; }
  }

  function setDisabled(o, c, cnt) {
    if (c !== "params") {
      if (c === "disabled" || config.dataBind[cnt].disabled || (c === "" && action === "upd"  && ! config.authority.upd)) {
        o.disabled = true;
      } else {
        o.disabled = false;
      }
    }
  }

  function bindData() {
    // cmd = ""，連結Grid資料到html物件。
    // cmd = "copy"，連結Grid資料到html物件，物件為disabled其值清空。
    // cmd = "params"，將html物件的值轉為資料維護參數字串。
    // cmd = "disabled"，將html物件設為disabled，並且清空其值。
    var params = "hidAction=" + action, cmd = "", tar, obj, i;

    if (config.dataBind) {

      if (arguments.length === 1) { cmd = arguments[0]; }

      for (i = 0; i < config.dataBind.length; i++) {
        if (! config.dataBind[i].setVal || (config.dataBind[i].setVal && cmd === "params") || cmd === "disabled") {
          tar = document.getElementsByName(config.dataBind[i].target);
          if (tar) {
            obj = tar[0];
          } else {
            tar = $(config.dataBind[i].target);
            obj = tar;
          }

          if (obj) {
            var t = "", j = 0;

            switch (obj.type) {
              case "button":
              case "reset":
              case "submit":
                setDisabled(obj, cmd, i);
                break;
              case "checkbox":
              case "radio":
                t = "";

                if (tar.length) {
                  for (j = 0; j < tar.length; j++) {
                    if (cmd !== "params") {
                      tar[j].checked = false;

                      if (action !== "ins" && cmd !== "disabled") {
                        if (typeof config.dataBind[i].index !== "undefined") {
                          if  (tar[j].value === rowsAry[recNo][config.dataBind[i].index]) {
                            if (! (cmd === "copy" && config.dataBind[i].disabled)) {
                              tar[j].checked = true;
                            }
                          }
                        }
                      }

                      setDisabled(tar[j], cmd, i);
                    } else {
                      if (tar[j].checked) { t += escape(tar[j].value) + ","; }
                    }
                  }

                  if (cmd === "params") {
                    params += "&" + config.dataBind[i].target + "=";
                    if (t !== "") {
                      params += escape(t.substring(0, t.length - 1));
                    } else {
                      params += escape(t);
                    }
                  }
                } else {
                  if (cmd !== "params") {
                    obj.checked = false;

                    if (action !== "ins" && cmd !== "disabled") {
                      if (obj.value === rowsAry[recNo][config.dataBind[i].index]) {
                        if (! (cmd === "copy" && config.dataBind[i].disabled) && cmd !== "disabled") {
                          obj.checked = true;
                        }
                      }
                    }

                    setDisabled(obj, cmd, i);
                  } else {
                    params += "&" + config.dataBind[i].target + "=";
                    if (obj.checked) { params += escape(obj.value); }
                  }
                }
                break;
              case "text":
              case "textarea":
              case "hidden":
              case "password":
                if (cmd !== "params") {
                  obj.value = "";

                  if (action !== "ins" && cmd !== "disabled") {
                    if (typeof config.dataBind[i].index !== "undefined") {
                      if (! (cmd === "copy" && config.dataBind[i].disabled) && cmd !== "disabled") {
                        obj.value = rowsAry[recNo][config.dataBind[i].index];
                      }
                    }
                  }

                  if (obj.type !== "hidden") {
                    setDisabled(obj, cmd, i);
                  }
                } else {
                  params += "&" + config.dataBind[i].target + "=" + escape(obj.value);
                }
                break;
              case "select-one":
              case "select-multiple":
                var ifSlted = false;

                t = "";

                for (j = 0; j < obj.options.length; j++) {
                  if (cmd !== "params") {
                    obj.options[j].selected = false;

                    if (action !== "ins" && cmd !== "disabled") {
                      if (typeof config.dataBind[i].index !== "undefined") {
                        if (rowsAry[recNo][config.dataBind[i].index].indexOf(obj.options[j].value) >= 0) {
                          if (! (cmd === "copy" && config.dataBind[i].disabled) && cmd !== "disabled") {
                            obj.options[j].selected = true;
                          }
                          ifSlted = true;
                        }
                      }
                    }
                  } else {
                    if (obj.options[j].selected) { t += obj.options[j].value + ","; }
                  }
                }

                if (cmd !== "params") {
                  if (cmd !== "disabled" && action !== "ins" && ! ifSlted && typeof config.dataBind[i].index !== "undefined") {
                    obj.length++;
                    obj.options[obj.length - 1] = new Option(rowsAry[recNo][config.dataBind[i].index], rowsAry[recNo][config.dataBind[i].index]);
                    obj.options.selectedIndex = obj.length - 1;
                  }

                  setDisabled(obj, cmd, i);
                } else {
                  params += "&" + config.dataBind[i].target + "=";
                  if (t !== "") { params += escape(t.substring(0, t.length - 1)); }
                }
                break;
            }
          }
        } else {
          if (typeof config.dataBind[i].setVal === "function") {
            if (action !== "ins" && (config.dataBind[i].index + "") !== "undefined") {
              config.dataBind[i].setVal(rowsAry[recNo][config.dataBind[i].index], action);
            } else {
              config.dataBind[i].setVal("", action);
            }
          }
        }
      }
    }

    if (cmd === "disabled" && config.dataBind && config.dataBind.length > 0) {
      $("tdMode" + ID).innerHTML = "模式:&nbsp;&nbsp;&nbsp;&nbsp;";
    }

    return params;
  }

  function updArray(ary) {
    var i, tar, obj, params = bindData("params"), stop = "button,reset,submit";

    for (i = 0; i < config.dataBind.length; i++) {
      tar = document.getElementsByName(config.dataBind[i].target);
      if (tar.length > 0) {
        obj = tar[0];
      } else {
        tar = $(config.dataBind[i].target);
        obj = tar;
      }

      if (obj) {
        if (stop.indexOf(obj.type) < 0 && ((typeof config.dataBind[i].index) === "number")) {
          if (typeof config.dataBind[i].getVal === "undefined") {
            ary[config.dataBind[i].index] = getParamValue(params, config.dataBind[i].target);
          } else {
            ary[config.dataBind[i].index] = config.dataBind[i].getVal(action);
          }
        }
      }
    }
  }

  function updGridTr(tr, no, fzTr) {
    var i, val, td = "";

    for (i = 0; i < config.columns.length; i++) {

      if (config.columns[i].data.align) {
        if (i >= config.freezeCols) {
          tr.cells[i - config.freezeCols].style.cssText = "text-align:" + config.columns[i].data.align;
        } else {
          fzTr.cells[i].style.cssText = "text-align:" + config.columns[i].data.align;
        }
      }

      val = rowsAry[no][config.columns[i].data.index];

      if (typeof config.columns[i].data.setVal === "function") {
        td = config.columns[i].data.setVal(val, rowsAry[no]);
      } else {
        if (typeof config.columns[i].data.format === "string") {
          td = convertData(val, config.columns[i].data.format);
        } else {
          td = val;
        }
      }

      if (i >= config.freezeCols) {
        tr.cells[i - config.freezeCols].innerHTML = td;
      } else {
        fzTr.cells[i].innerHTML = td;
      }
    }
  }

  function convertFloat(f) {
    var t = parseFloat(f.replace(/[+,%]/g, ""));
    return (isNaN(t)) ? 0 : t;
  }

  function convertDate(d) {
    var t = d.replace(/-/g, "/"), r;

    r = new Date(t);
    return (isNaN(r)) ? 0 : r.getTime();
  }

  function convertDateTime(dt) {
    var t = dt.replace(/-/g, "/"), r;

    if (t.indexOf(" 上午") >= 0) {
      t = t.replace(/上午 /g, '') + " AM";
    } else if (t.indexOf(" 下午") >= 0) {
      t = t.replace(/下午 /g, '') + " PM";
    }

    r = new Date(t);
    return (isNaN(r)) ? 0 : r.getTime();
  }

  function convertTime(ti) {
    var t = ti, r;

    if (t.indexOf("上午") >= 0) {
      t = t.replace(/上午/g, '') + " AM";
    } else if (t.indexOf("下午 ") >= 0) {
      t = t.replace(/下午/g, '') + " PM";
    }

    r = new Date("1970/1/1 " + t);
    return (isNaN(r)) ? 0 : r.getTime();
  }

  function getCompareFunc(s, a) {
    var func;

    if (s.type) {
      switch (s.type) {
        case "number":
        case "percent":
          if (a) {
            func = sortNumber;
          } else {
            func = sortNumberD;
          }
          break;
        case "date":
          if (a) {
            func = sortDate;
          } else {
            func = sortDateD;
          }
          break;
        case "dateTime":
          if (a) {
            func = sortDateTime;
          } else {
            func = sortDateTimeD;
          }
          break;
        case "time":
          if (a) {
            func = sortTime;
          } else {
            func = sortTimeD;
          }
          break;
        case "text":
        default:
          if (a) {
            func = sortText;
          } else {
            func = sortTextD;
          }
          break;
      }
    } else {
      if (typeof s.parser === "function") {
        custFunc = s.parser;
        if (a) {
          func = custParser;
        } else {
          func = custParserD;
        }
      } else {
        if (a) {
          func = sortText;
        } else {
          func = sortTextD;
        }
      }
    }

    return func;
  }

  var ID = 0;
  var gridW = 0, dataDivH = 0, dataTbW = 0, dataTbH = 0; // Grid的尺寸
  var scrollW = 17; // 設定Scroll Width
  var hideTr = ""; // Grid控制寬度之隱藏Tr
  var rowsAry = []; // Grid資料之物件
  var imgPath = ""; // 圖片路徑
  var rowsCnt = 0; // 資料筆數
  var pageSize = 0; // 頁數大小
  var pageIdx = 0; // 目前頁數
  var pageCnt = 0; // 總頁數
  var nonDataH = 0; // 總高度-Data高度
  var recNo = -1; // 記錄目前在資料中所選定的record number
  var gridTr = null; // 記錄在Grid中所選定的Tr
  var action = "ins"; // 目前編輯模式:ins,upd,del,qry,ref
  var aftQryAddMode = true; //設定呼叫ajax程式後，畫面預設為add mode
  var ajaxWhere = ""; // 記錄Ajax跳頁where條件
  var ajax; // Ajax呼叫元件
  var clickedTr; // 新增Tr點選時的本身
  var sortAry = []; // 排序array
  var sortIdx = 0; // 排序indexe
  var sortCnt = 0; // 可排序的欄位數量
  var custFunc; // 自訂排序的function
  var fzW = 0; // 凍結寬度
  var fzHideTr = ""; // 凍結控制寬度之隱藏Tr
  var totalSize = 0; // 有total row為1
  var pageSizeTbH = 0; // pageSize rows的Table高度，使用在有total row
  var ie678 = !-[1,]; // 判斷是否為IE678
  //var ie67 = ie678 && !document.querySelector; // 判斷是否為IE67
  var opera = window.opr != undefined;  // 判斷是否為Opera

  var sortDate = function(a, b) {
    custFunc = convertDate;

    return custParser(a, b);
  };

  var sortDateD = function(a, b) {
    return -1 * sortDate(a, b);
  };

  var sortDateTime = function(a, b) {
    custFunc = convertDateTime;

    return custParser(a, b);
  };

  var sortDateTimeD = function(a, b) {
    return -1 * sortDateTime(a, b);
  };

  var sortTime = function(a, b) {
    custFunc = convertTime;

    return custParser(a, b);
  };

  var sortTimeD = function(a, b) {
    return -1 * sortTime(a, b);
  };

  var sortNumber = function(a, b) {
    custFunc = convertFloat;

    return custParser(a, b);
  };

  var sortNumberD = function(a, b) {
    return -1 * sortNumber(a, b);
  };

  var sortText = function(a, b) {
    var f = config.columns[sortIdx].data.setVal;

    if (typeof f === "function") {
      return f(a[sortIdx], a).localeCompare(f(b[sortIdx], b));
    } else {
      return a[sortIdx].localeCompare(b[sortIdx]);
    }
  };

  var sortTextD = function(a, b) {
    return -1 * sortText(a, b);
  };

  var custParser = function(a, b) {
    var cA, cB, f = config.columns[sortIdx].data.setVal;

    if (typeof f === "function") {
      cA = custFunc(f(a[sortIdx], a));
      cB = custFunc(f(b[sortIdx], b));
    } else {
      cA = custFunc(a[sortIdx]);
      cB = custFunc(b[sortIdx]);
    }

    return (cA < cB) ? -1 : (cA > cB) ? 1 : 0;
  };

  var custParserD = function(a, b) {
    return -1 * custParser(a, b);
  };

  var multiSort = function(a, b) {
    var i = 0, r = 0, func;

    for (i = 0; i < sortAry.length; i++) {
      sortIdx = sortAry[i][0];
      func = getCompareFunc(config.columns[sortIdx].sort, sortAry[i][1] === "");
      r = func(a, b);

      if (r !== 0) {
        break;
      }
    }

    return r;
  };

  if (window.XMLHttpRequest) { // If IE7, Mozilla, Safari, and so on
    ajax = new XMLHttpRequest();
  } else { // for IE6, IE5
    var i, xh = ["MSXML2.XMLHTTP.6.0", "MSXML2.XMLHTTP.5.0", "MSXML2.XMLHTTP.4.0", "MSXML2.XMLHTTP.3.0", "MSXML2.XMLHTTP", "Microsoft.XMLHTTP"];

    for (i = 0; i < xh.length && !ajax; i++) {
      try {
        ajax = new ActiveXObject(xh[i]);
      } catch (e) {}
    }
  }

  yGrid.count++;
  ID = yGrid.count;

  init();

// public
  this.gridOnScroll = function (div) {
    var divGridTt = $("divGridTt" + ID);

    $("divGridHead" + ID).scrollLeft = div.scrollLeft;

    if (divGridTt) {
      divGridTt.scrollLeft = div.scrollLeft;
    }

    if (config.freezeCols > 0) {
      $("divGridFD" + ID).scrollTop = div.scrollTop;
    }
  };

  this.setQueryURL = function (url) {
    config.queryURL = url;
  };

  this.load = function () {
    var rows, ifSetGridSize = false, autoH = false, totData;

    if (typeof arguments[0] === "object") {
      rowsAry = arguments[0];

      if (arguments.length >= 2 && typeof arguments[1] === "number") {
        rows = arguments[1];
        if (rowsCnt === 0 && rows > 0 && pageIdx === 1) { ifSetGridSize = true; }
        rowsCnt = rows;
      } else {
        if (rowsCnt === 0 && rowsAry.length > 0 && pageIdx === 1) { ifSetGridSize = true; }
        rowsCnt = rowsAry.length;
        config.pageAjax = false;
      }

      if (config.pageSize === 0) {
        pageSize = rowsCnt;
        pageIdx = 0;
        autoH = true;
      }

      if (pageIdx === 0) {
        pageIdx = 1;
        ifSetGridSize = true;
      }

      pageCnt = Math.ceil(rowsCnt / pageSize);
      this.setPage(pageIdx);
      setGoToPage();
      if (pageIdx === 1 && ifSetGridSize) {
        setGridSize(autoH);
        if (config.pageSize === 0) { hideToolbar(); }
      }

      if (totalSize === 1) {
        if (arguments.length === 2 && typeof arguments[1] === "object") {
          totData = arguments[1];
        } else if (arguments.length === 3 && typeof arguments[2] === "object") {
          totData = arguments[2];
        }

        this.loadTotal(totData);
      }

      if (typeof config.callback === "function") { config.callback(this); }
    } else {
      pageIdx = 0;
      if (arguments.length === 0) { this.callAjaxQuery(); }
      else { this.callAjaxQuery(arguments[0]); }
    }
  };

  this.loadTotal = function (totData) {
    var i = 0, j = 0, td = "", html = "", fzHtml = "", tmp = "", divGrTt, tbGridTt, tot, pos, val;

    if (! totData && ! config.pageAjax) { //calculate total
      tot = [];
      pos = [];

      for (i = 0; i < config.columns.length; i++) {
        if (config.columns[i].total && typeof config.columns[i].total.type === "string") {
          if (config.columns[i].total.type !== "string" && config.columns[i].total.type !== "count") {
            switch (config.columns[i].total.type) {
              case "avg":
              case "sum":
                tot.push(0);
                break;
              case "distinctCount":
                tot.push("");
                break;
              case "max":
              case "min":
                if (rowsCnt > 0) {
                  if (typeof config.columns[i].data.setVal === "function") {
                    tot.push(config.columns[i].data.setVal(rowsAry[0][config.columns[i].data.index], rowsAry[0]));
                  } else {
                    tot.push(rowsAry[0][config.columns[i].data.index]);
                  }
                }
                else { tot.push(""); }
                break;
            }
            pos.push(i);
          }
        }
      }

      for (i = 0; i < rowsCnt; i++) {
        for (j = 0; j < pos.length; j++) {
          if (typeof config.columns[pos[j]].data.setVal === "function") {
            val = config.columns[pos[j]].data.setVal(rowsAry[i][config.columns[pos[j]].data.index], rowsAry[i]);
          } else {
            val = rowsAry[i][config.columns[pos[j]].data.index];
          }

          switch (config.columns[pos[j]].total.type) {
            case "avg":
            case "sum":
              tot[j] += parseFloat(val);
              break;
            case "distinctCount":
              if (val === "") { val = "EmP ty"; }
              if (tot[j].indexOf(val + "|\t") < 0) {
                tot[j] += val + "|\t";
              }
              break;
            case "max":
              if (val > tot[j]) { tot[j] = val; }
              break;
            case "min":
              if (val < tot[j]) { tot[j] = val; }
              break;
          }
        }
      }

      totData = [];
      j = 0;

      for (i = 0; i < config.columns.length; i++) {
        if (config.columns[i].total && typeof config.columns[i].total.type === "string") {
          if (config.columns[i].total.type !== "string") {
            if (config.columns[i].total.type === "count") {
              totData.push(rowsCnt);
            } else {
              switch (config.columns[i].total.type) {
                case "avg":
                  tot[j] = tot[j] / rowsCnt;
                  break;
                case "distinctCount":
                  if (rowsCnt > 0) {
                    tot[j] = tot[j].split("|\t").length - 1;
                  } else {
                    tot[j] = "";
                  }
                  break;
              }
              totData.push(tot[j]);
              j++;
            }
          }
        }
      }
    }

    for (i = 0, j = 0; i < config.columns.length; i++) {
      td = "<td style='width:" + config.columns[i].width + "px'";
      tmp = "　&nbsp;";

      if (config.columns[i].total && typeof config.columns[i].total.type === "string") {
        if (config.columns[i].title.align) { td += " align='" + config.columns[i].data.align + "'"; }
        if (config.columns[i].total.type !== "string" && totData.length > j) {
          if (typeof config.columns[i].total.format === "string") {
            tmp = convertData(totData[j].toString(), config.columns[i].total.format);
          } else {
            tmp = formatNumber(totData[j]).toString();
          }
          j++;
        } else {
          if (typeof config.columns[i].total.format === "string") {
            tmp = config.columns[i].total.format;
          }
        }
      }

      td += ">" + tmp + "</td>";

      if (i < config.freezeCols) {
        fzHtml += td;
      } else {
        html += td;
      }
    }

    if (totalSize === 1) {
      divGrTt = $("divGridTt" + ID);
      divGrTt.innerHTML = "<table id='tbGridTt" + ID + "' class='yGrTable' style='width:" + dataTbW + "px;' border='0' cellspacing='1' cellpadding='1'><tr class='yGrTotal'>" + html + "</tr></table>";
      tbGridTt = $("tbGridTt" + ID);
      divGrTt.style.height = tbGridTt.offsetHeight + "px";
      tbGridTt.style.width = $("tbGridData" + ID).offsetWidth + "px";

      if (config.freezeCols > 0) {
        var divGrFT = $("divGridFT" + ID);

        divGrFT.innerHTML = "<table id='tbGridFT" + ID + "' class='yGrTable' border='0' cellspacing='1' cellpadding='1'><tr class='yGrTotal'>" + fzHtml + "</tr></table>";
        $("tbGridFT" + ID).style.height = tbGridTt.offsetHeight + "px";
        divGrFT.style.height = divGrTt.style.height;
      }
    }
  };

  this.getTotalParams = function () {
    var i, ret = "", ary = [];

    if (totalSize === 1) {
      for (i = 0; i < config.columns.length; i++) {
        if (config.columns[i].total && config.columns[i].total.type !== "string") {
          ary.push(config.columns[i].data.index + "," + config.columns[i].total.type);
        }
      }
      ret = "&total=" + ary.join("|");
    }

    return ret;
  };

  this.getQueryParams = function () {
    var params = "&pageSize=" + pageSize, t = "";

    if (arguments.length === 0) {
      params += "&pageIdx=" + pageIdx;
    } else if (arguments.length === 1) {
      if (! isNaN(arguments[0])) {
        params += "&pageIdx=" + arguments[0];
        pageIdx = parseFloat(arguments[0]);
      } else {
        if (arguments[0].length > 0) {
          if (arguments[0].charAt(0) !== "&") {  t = "&" + arguments[0]; }
          else { t = arguments[0]; }
          params += t;
          if (config.pageAjax) { ajaxWhere = t; }
        }
      }
    }

    params += "&pageAjax=";

    if (config.pageAjax) {
      params += "true";

      if (ajaxWhere !== "") {
        // Ajax跳頁時，將之前的查詢條件帶入
        if (arguments.length === 0) {
          params += ajaxWhere;
        } else if (arguments.length === 1) {
          if (! isNaN(arguments[0])) {
            params += ajaxWhere;
          }
        }
      }
    } else { params += "false"; }

    if (sortAry.length > 0) {
      params += "&sortAry=" + sortAry.join("|");
    }

    params += this.getTotalParams();
    return params;
  };

  this.callAjaxQuery = function () {
    var params = "hidAction=qry";

    if (action !== "rfr") { action = "qry"; }

    if (arguments.length === 0) {
      params += this.getQueryParams();
    } else if (arguments.length === 1) {
      params += this.getQueryParams(arguments[0]);
    }

    this.callAjax(config.queryURL, params, this);
  };

  this.setPage = function (goToPage) {
    var i, j, w, min = 0, max = 0, html = "<table id='tbGridData" + ID + "' class='yGrTable' style='width:" + dataTbW + "px;' border='0' cellspacing='1' cellpadding='1'>" + hideTr;
    var val, tmp, divGH, divGD, divGrFT, divGrTt, tbGD, stl, div, tr, fzTr, td, fzTd, fzHtml = "<table id='tbGridFD" + ID + "' class='yGrTable' border='0' cellspacing='1' cellpadding='1'>" + fzHideTr;

    divGD = $("divGridData" + ID);
    pageIdx = parseFloat(goToPage);

    if (typeof config.rowBound === "function") {
      div = document.createElement("div");
      div.style.display = "none";
      divGD.appendChild(div);
    }

    if (! config.pageAjax) {
      if (goToPage > 0) {
        min = (goToPage - 1) * pageSize;
      }

      if (config.pageSize <= 0) {
        max = rowsCnt;
      } else {
         if (goToPage * pageSize > rowsCnt) {
           max = rowsCnt;
        } else {
          max = goToPage * pageSize;
        }
      }
    } else {
      min = 0;
      max = rowsAry.length;
    }

    for (i = min; i < max; i++) {
      td = "";
      fzTd = "";

      for (j = 0; j < config.columns.length; j++) {
        tmp = "<td";
        if (config.columns[j].data.align) { tmp += " align='" + config.columns[j].data.align + "'"; }
        tmp += ">";
        val = rowsAry[i][config.columns[j].data.index];

        if (typeof config.columns[j].data.setVal === "function") {
          tmp += config.columns[j].data.setVal(val, rowsAry[i], i);
        } else {
          if (typeof config.columns[j].data.format === "string") {
            tmp += convertData(val, config.columns[j].data.format);
          } else {
            tmp += val;
          }
        }

        tmp += "</td>";

        if (j >= config.freezeCols) {
          td += tmp;
        } else {
          fzTd += tmp;
        }
      }

      tmp = "<tr class='yGrDataTr" + (i % 2) + "' onclick='" + config.name + ".rowOnClick(this);'>";

      if (typeof config.rowBound === "function") {
        div.innerHTML = "<table id='tbTmp" + ID + "'>" + tmp + fzTd + td + "</tr></table>";
        tr = config.rowBound($("tbTmp" + ID).rows[0]);

        if (config.freezeCols > 0) {
          fzTr = tr.cloneNode(true);
          for (j = config.columns.length - 1; j >= config.freezeCols; j--) {
            fzTr.deleteCell(j);
          }
          fzHtml += fzTr.outerHTML;
        }

        for (j = 0; j < config.freezeCols; j++) {
          tr.deleteCell(0);
        }
        html += tr.outerHTML;
      } else {
        html += tmp + td + "</tr>";
        if (config.freezeCols > 0) { fzHtml += tmp + fzTd + "</tr>"; }
      }
    }

    html += "</table>";
    divGD.innerHTML = html;
    tbGD = $("tbGridData" + ID);

    if (! yGrInit && config.freezeCols > 0)
    {
      if (tbGD.rows.length >= 1) w = tbGD.childNodes[0].rows[1].offsetHeight;
      else w = 18;

      appendStyle(".yGrDataTr0{height:" + w + "px;}.yGrDataTr1{height:" + w + "px;}");
    }

    yGrInit = true;

    if (totalSize === 1) {
      var newTr, td;

      pageSizeTbH = tbGD.offsetHeight;

      if (config.pageSize === 0 || pageIdx === 1) {
        divGrTt = $("divGridTt" + ID);
        divGH = $("divGridHead" + ID);
        divGrFT = $("divGridFT" + ID);
        divGrTt.style.top = (divGH.offsetHeight + pageSizeTbH - 5) + "px";
        if (config.freezeCols > 0) { divGrFT.style.top = divGrTt.style.top; }
      }

      newTr = tbGD.insertRow(-1);
      td = newTr.insertCell(0);
      td.setAttribute("colSpan", config.columns.length - config.freezeCols);
      td.innerHTML = "　&nbsp;";
      dataTbH = tbGD.offsetHeight;
    }

    if (config.freezeCols > 0) {
      if (totalSize === 1) {
        fzHtml += "<tr><td colspan='" + config.freezeCols + "'>　&nbsp;</td></tr>";
      }

      fzHtml += "</table>";
      $("divGridFD" + ID).innerHTML = fzHtml;

      tbGD.style.width = (tbGD.offsetWidth - fzW + 2 > 0 ? tbGD.offsetWidth - fzW + 2 : 10) + "px";

      var tbFD = $("tbGridFD" + ID);

      //只有Chrome或Opera會發生底下情況，
      //Opera：二邊offsetHeight數字相同（數字到整數位），實際Table高度不同（數字到小數位），故Opera一定要執行，
      //凍結的欄之Table高度與沒有凍結欄之Table高度不一致。
      if (tbGD.offsetHeight !== tbFD.offsetHeight || opera)
      {
        //以兩邊Tr最大的高度為準，將凍結的欄之高度與沒有凍結之欄高度一致，如此，凍結欄Table高度=沒有凍結欄Table高度。
        for (i = 0; i < tbGD.rows.length; i++) {
          if (tbGD.childNodes[0].rows[i].offsetHeight >= tbFD.childNodes[0].rows[i].offsetHeight)
            tbFD.childNodes[0].rows[i].style.height = tbGD.childNodes[0].rows[i].offsetHeight + "px";
          else
            tbGD.childNodes[0].rows[i].style.height = tbFD.childNodes[0].rows[i].offsetHeight + "px";
        }
      }
    }

    setPageImage();

    if (config.pageSize > 0) {
      if (rowsCnt > 0) {
        $("sltGoToPage" + ID).options.selectedIndex = goToPage - 1;
      } else {
        $("sltGoToPage" + ID).options.selectedIndex = 0;
      }
    }

    setFooter();

    if (dataTbH !== $("tbGridData" + ID).offsetHeight) {
      setGridSize(true);
    }
  };

  this.showPage = function (goTo) {
    var ifShow = true;

    if (rowsCnt === 0) { return; }

    switch (goTo) {
      case "first":
        if (pageIdx !== 1) {
          pageIdx = 1;
        } else {
          ifShow = false;
        }
        break;
      case "prev":
        if (pageIdx > 1) {
          pageIdx--;
        } else {
          ifShow = false;
        }
        break;
      case "next":
        if (pageIdx !== pageCnt) {
          pageIdx++;
        } else {
          ifShow = false;
        }
        break;
      case "last":
        if (pageIdx !== pageCnt) {
          pageIdx = pageCnt;
        } else {
          ifShow = false;
        }
        break;
    }

    if (ifShow) {
      if (! config.pageAjax) {
        this.setPage(pageIdx);
        this.rowInsMode();
      } else {
        this.callAjaxQuery();
        action = "qry";
        aftQryAddMode = true;
      }
    }
  };

  this.setPageSize = function (s) {
    var divGrTt, divGD = $("divGridData" + ID), size = parseFloat(s);

    dataDivH = dataDivH / (pageSize + totalSize) * (size + totalSize);
    divGD.style.height = dataDivH + "px";
    pageSize = size;
    pageIdx = 1;
    adjustGridSize();

    if (totalSize === 1) {
      divGrTt = $("divGridTt" + ID);
      divGrTt.style.top = ($("divGridHead" + ID).offsetHeight + pageSizeTbH - 5) + "px";
      if (config.freezeCols > 0) { $("divGridFT" + ID).style.top = divGrTt.style.top; }
    }

    if (config.freezeCols > 0) {
      $("divGridFD" + ID).style.height = (divGD.offsetHeight - scrollW) + "px";
    }

    if (! config.pageAjax) {
      pageCnt = Math.ceil(rowsCnt / pageSize);
      this.setPage(pageIdx);
      setGoToPage();
      if (rowsCnt >= pageSize) setGridSize(true);
    } else {
      pageIdx = 0; // pageIdx = 0，才能執行setGridSize()
      this.callAjaxQuery();
    }
  };

  this.sortDefault = function () { //將有排序的head圖示恢復初始值
    var tbGH, tr, i;

    tbGH = $("tbGridHead" + ID)

    if (tbGH.childNodes[0].rows.length === 2) {
      tr = tbGH.childNodes[0].rows[1];
    } else {
      tr = tbGH.childNodes[0].rows[2];
    }

    for (i = 0; i < tr.cells.length; i++) {
      if (tr.cells[i].className !== "") { tr.cells[i].className = "yGrTitleSort"; }
    }

    if (config.freezeCols > 0) {

      if (tbGH.childNodes[0].rows.length === 2) {
        tr = $("tbGridFH" + ID).childNodes[0].rows[1];
      } else {
        tr = $("tbGridFH" + ID).childNodes[0].rows[2];
      }

      for (i = 0; i < tr.cells.length; i++) {
        if (tr.cells[i].className !== "") { tr.cells[i].className = "yGrTitleSort"; }
      }
    }
  };

  this.sortOnClick = function (th, idx) {
    var i = 0, asc = false, classNm = "";

    sortAry = [];
    sortIdx = idx;

    if (th.className.indexOf("yGrTitleSortA") < 0) {
      classNm = "yGrTitleSort yGrTitleSortA";
      asc = true;
      sortAry.push([idx, ""]);
    } else {
      classNm = "yGrTitleSort yGrTitleSortD";
      sortAry.push([idx, "desc"]);
    }

    this.sortDefault();
    th.className = classNm;

    if (! config.pageAjax) {
      rowsAry.sort(getCompareFunc(config.columns[idx].sort, asc));
      this.setPage(pageIdx);
      this.rowInsMode();
    } else {
      this.callAjaxQuery();
      action = "qry";
      aftQryAddMode = true;
    }
  };

  this.sortConfig = function () {
    var divOrder = $("divGridOrder"), p = getAbsolutePos($("divGridData" + ID)), i = 0, j = 0, html = "", opts1 = "", opts2 = "", w = 0, obj;

    if (!divOrder) {
      divOrder = document.createElement("div");
      divOrder.id = "divGridOrder";
      divOrder.style.position = "absolute";
      divOrder.style.width = "226px";
      divOrder.style.height = ((sortCnt + 1) * 34) + "px";
      divOrder.style.zIndex = 999;
      divOrder.style.textAlign = "center";
      divOrder.className = "yGrSort";
      document.body.appendChild(divOrder);
    }

    for (i = 0; i < config.columns.length; i++) {
      if (config.columns[i].sort) {
        opts1 += "<option value='" + i + "," + config.columns[i].data.index + "'>" + config.columns[i].title.word + "</option>";
      }
    }

    opts1 = "<option value=''></option>" + opts1;
    opts2 = "<option value=''>由小到大</option><option value='desc'>由大到小</option>";
    html = "<table id='tbGridSort' border='0' cellspacing='2' cellpadding='2' align='center'>" +
      "<tr align='center'><th>欄</th><th>順序</th></tr>";

    for (i = 1; i <= sortCnt; i++) {
      html += "<tr><td><select id='sltGridSortI" + i + "'>" + opts1 + "</select></td>" +
        "<td><select id='sltGridSortD" + i + "'>" + opts2 + "</select></td></tr>";
    }

    html += "<tr align='center'><td colspan='2'><input type='button' value='確定' hideFocus onclick='" + config.name + ".sortConfigOk();' />&nbsp;&nbsp;" +
      "<input type='button' value='取消' hideFocus onclick=\"document.getElementById('divGridOrder').style.display='none';\" /></td></tr></table>";
    divOrder.innerHTML = html;
    divOrder.style.left = (p.x - fzW + (Math.ceil((gridW - 226) / 2))) + "px";
    divOrder.style.top = (p.y + 3) + "px";
    divOrder.style.display = "";
    obj = $("tbGridSort");
    w = obj.offsetWidth + 18;
    divOrder.style.left = (p.x - fzW + (Math.ceil((gridW - w) / 2))) + "px";
    divOrder.style.width = w + "px";
    divOrder.style.height = obj.offsetHeight + "px";

    for (i = 0; i < sortAry.length; i++) {
      j = 0;
      for (w = 0; w < config.columns.length; w++) {
        if (config.columns[w].sort) {
          j++;
          if (sortAry[i][0] === config.columns[w].data.index) {
            obj = $("sltGridSortI" + (i + 1));
            obj.options.selectedIndex = j;
            obj = $("sltGridSortD" + (i + 1));
            if (sortAry[i][1] === "") {
              obj.options.selectedIndex = 0;
            } else {
              obj.options.selectedIndex = 1;
            }
            break;
          }
        }
      }
    }
  };

  this.sortConfigOk = function () {
    var i = 0, val = "", tbGH, d, ary, tmp1, tmp2, tmp3;

    sortAry = [];
    d = [];
    tbGH = $("tbGridHead" + ID);

    for (i = 0; i < sortCnt; i++) {
      tmp1 = $("sltGridSortI" + (i + 1));

      if (tmp1.value !== "") {
        if (val.indexOf(tmp1.value + "|") === -1) {
          val += tmp1.value + "|";
          ary = tmp1.value.split(",");
          tmp2 = $("sltGridSortD" + (i + 1));
          sortAry.push([parseFloat(ary[1]), tmp2.value]);
          d.push([parseFloat(ary[0]), tmp2.value]);
        } else {
          sortAry = [];
          tmp1.focus();
          alert("排序欄位重複！");
          break;
        }
      }
    }

    if (sortAry.length > 0) {
      $("divGridOrder").style.display = "none";
      this.sortDefault();

      if (tbGH.childNodes[0].rows.length === 2) {
        tmp1 = tbGH.childNodes[0].rows[1];
      } else {
        tmp1 = tbGH.childNodes[0].rows[2];
      }

      if (config.freezeCols > 0) {
        if (tbGH.childNodes[0].rows.length === 2) {
          tmp2 = $("tbGridFH" + ID).childNodes[0].rows[1];
        } else {
          tmp2 = $("tbGridFH" + ID).childNodes[0].rows[2];
        }
      }

      for (i = 0; i < d.length; i++) {
        if (d[i][0] + 1 > config.freezeCols) {
          tmp3 = tmp1.cells[d[i][0] - config.freezeCols];
        } else {
          tmp3 = tmp2.cells[d[i][0]];
        }

        if (d[i][1] === "") {
          tmp3.className = "yGrTitleSort yGrTitleSortA";
        } else {
          tmp3.className = "yGrTitleSort yGrTitleSortD";
        }
      }

      if (! config.pageAjax) {
        rowsAry.sort(multiSort);
        this.setPage(pageIdx);
        this.rowInsMode();
      } else {
        this.callAjaxQuery();
        action = "qry";
        aftQryAddMode = true;
      }
    }
  };

  this.getDataTbody = function (tbId) {
    var tbody;

    if (config.freezeCols > 0) {
      if (tbId.indexOf("tbGridData") >= 0) {
        tbody = $("tbGridFD" + ID).childNodes[0];
      } else {
        tbody = $("tbGridData" + ID).childNodes[0];
      }
    }

     return tbody;
  };

  this.rowOnClick = function () {
    var tr, tbody, i, mode = "修改";

    if (arguments.length === 1) {
      tr = arguments[0];
    } else {
      tr = clickedTr;
    }

    if (gridTr) {
      gridTr.className = gridTr.className.replace(" yGrDataTrS", "");
      tbody = this.getDataTbody(gridTr.parentNode.parentNode.id); //凍結的tbody
      if (tbody) { tbody.rows[gridTr.rowIndex].className = tbody.rows[gridTr.rowIndex].className.replace(" yGrDataTrS", ""); }
    }

    tr.className = tr.className + " yGrDataTrS";
    gridTr = tr;
    tbody = this.getDataTbody(tr.parentNode.parentNode.id); //被點選tr的另一個tbody

    if (tbody) {
      tbody.rows[tr.rowIndex].className = tbody.rows[tr.rowIndex].className + " yGrDataTrS";
      if (tbody.parentNode.id.indexOf("tbGridData") >= 0) { gridTr = tbody.rows[tr.rowIndex]; }
    }

    if (config.dataBind && action !== "") {
      action = "upd";
      if (config.dataBind.length > 0) {
        if (! config.authority.upd) { mode = "查詢"; }
        $("tdMode" + ID).innerHTML = "模式:" + mode;
      }

      recNo = (config.pageAjax) ? tr.rowIndex - 1 : (pageIdx - 1) * pageSize + tr.rowIndex - 1;
      bindData();
    }
  };

  this.rowClearClicked = function () {
    if (gridTr) {
      if (gridTr.parentNode && gridTr.parentNode.parentNode) {
        var tbody = this.getDataTbody(gridTr.parentNode.parentNode.id);

        gridTr.className = gridTr.className.replace(" yGrDataTrS", "");
        if (tbody) { tbody.rows[gridTr.rowIndex].className = tbody.rows[gridTr.rowIndex].className.replace(" yGrDataTrS", ""); }
      }

      recNo = -1;
      gridTr = null;
    }
  };

  this.rowInsMode = function () {
    action = "ins";
    this.rowClearClicked();
    $("tdMode" + ID).innerHTML = "模式:新增";
    bindData();
  };

  this.rowCopyMode = function () {
    if (! gridTr) {
      alert("尚未點選要複製的資料！");
    } else {
      action = "upd";
      bindData("copy");
      action = "ins";
      this.rowClearClicked();
      $("tdMode" + ID).innerHTML = "模式:新增";
    }
  };

  this.rowDelMode = function () {
    if (! gridTr) {
      alert("尚未點選要刪除的資料！");
    } else {
      if (confirm("是否刪除此筆資料？")) {
        action = "del";
        this.submit();
      }
    }
  };

  this.rowReset = function () {
     bindData();
  };

  this.submit = function () {
    var ifOk = true, tar, frm, i, params = "";

    if (config.checkForm) {
      if (typeof config.checkForm === "function") {

        if (config.dataBind) {
          for (i = 0; i < config.dataBind.length; i++) {
            tar = $(config.dataBind[i].target);
            if (tar) {
              frm = tar.form;
              break;
            }
          }
        }

        ifOk = config.checkForm(frm, action);
      }
    }

    if (ifOk) {
      if (config.maintainURL) {
        params = bindData("params");
        if (action === "del") {
          params += this.getQueryParams();
        } else {
          params += this.getTotalParams();
        }
        this.callAjax(config.maintainURL, params, this);
      } else {
        alert("請定義maintainURL參數！");
      }
    }
  };

  this.callAjax = function (url, params, grid) {
    var ret = "", tar;

    this.waiting("show");
    this.setBindButton(true);
    ajax.open("POST", url, true);
    ajax.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    ajax.setRequestHeader("Content-length", params.length);
    ajax.setRequestHeader("Connection", "close");
    ajax.onreadystatechange = function() {
      var resp, totData, ok = false, ifRefresh = false, refresh = "", rows = 0;

      if (ajax.readyState === 4) {
        grid.waiting("hide");

        if (ajax.status === 200) {
          resp = (new Function("return " + ajax.responseText))();
          if (resp.runJS) { runJS(resp.runJS); }
          ok = resp.ok;

          if (ok) {
            switch (action) {
              case "ins":
                grid.rowIns();
                break;
              case "upd":
                grid.rowUpd();
                break;
              case "del":
                grid.rowDel();
              case "qry":
              case "rfr":
                if (resp.grData) {
                  if (resp.rows) { rows = resp.rows; }
                  if (config.pageAjax) { grid.load(resp.grData, rows); }
                  else { grid.load(resp.grData); }
                }

                if (action === "rfr") { action = "qry"; }
                break;
            }

            if (resp.totData || ! config.pageAjax) { grid.loadTotal(resp.totData); }

            if (aftQryAddMode) {
              if (config.authority.ins) {
                grid.rowInsMode();
              } else {
                bindData("disabled");
              }
              aftQryAddMode = false;
            }
          }

          if (resp.ifRefresh) { ifRefresh = resp.ifRefresh; }
          if (ifRefresh) {
            if (resp.refresh) { refresh = resp.refresh; }
            grid.refresh(refresh);
          }

          if (resp.alert) {
            alert(resp.alert);
          } else {
            if (resp.msg) { PopupWindow.show(resp.msg); }
          }
        } else {
          if (config.debug) { document.write(ajax.responseText); }
          else { alert("Ajax呼叫程式失敗，失敗代碼：" + ajax.status); }
        }

        if (! ok || (action !== "del" && action !== "qry")) { grid.setBindButton(false); }
      }
    };
    ajax.send(params);
  };

  this.waiting = function (show) {
    var divWaiting = $("divGridWaiting");

    if (!divWaiting) {
      divWaiting = document.createElement("div");
      divWaiting.id = "divGridWaiting";
      divWaiting.style.position = "absolute";
      divWaiting.style.left = (Math.ceil((gridW - 226) / 2)) + "px";
      divWaiting.style.top = (Math.ceil(($("divGridData" + ID).offsetHeight - 18) / 2)) + "px";
      divWaiting.style.width = "226px";
      divWaiting.style.height = "18px";
      divWaiting.style.zIndex = 999;
      divWaiting.innerHTML = "資料處理中，請稍候<img align='absbottom' src='" + imgPath + "yWaiting.gif'>";
      divWaiting.className = "yGrWaiting";
      $("divGrid" + ID).appendChild(divWaiting);
    }

    if (show === "show") {
      show = "";
    } else {
      show = "none";
    }

    divWaiting.style.display = show;
  };

  this.setBindButton = function (dis) {
    var i, tar;

    if (config.dataBind) {
      for (i = 0; i < config.dataBind.length; i++) {
        tar = $(config.dataBind[i].target);
        if (tar) {
          if (tar.type === "button" || tar.type === "reset" || tar.type === "submit") {
            tar.disabled = dis;
          }
        }
      }
    }
  };

  this.rowIns = function () {
    var row = [];

    updArray(row);
    rowsAry.push(row);

    if (config.pageSize > 0) {
      rowsCnt++;
      if (rowsCnt === 1) { pageCnt = 1; pageIdx = 1; }
      if (pageIdx === pageCnt || rowsCnt === 1) { this.setPage(pageIdx); }
      if (pageCnt !== Math.ceil(rowsCnt / pageSize) || rowsCnt === 1) {
        pageCnt = Math.ceil(rowsCnt / pageSize);
        setPageImage();
        setGoToPage();
      }
      if (rowsCnt === pageSize) { setGridSize(true); }
    } else {
      var i, td, fzTr, newTr = $("tbGridData" + ID).insertRow(-1);

      newTr.className = "yGrDataTr" + (rowsCnt % 2);
      newTr.onclick = function() {
        clickedTr = this;
        runJS(config.name + ".rowOnClick();");
      };

      for (i = 0; i < config.columns.length - config.freezeCols; i++) {
        td = newTr.insertCell(i);
      }

      if (config.freezeCols > 0) {
        fzTr = $("tbGridFD" + ID).insertRow(-1);
        fzTr.className = "yGrDataTr" + (rowsCnt % 2);
        fzTr.onclick = function() {
          clickedTr = this;
          runJS(config.name + ".rowOnClick();");
        };

        for (i = 0; i < config.freezeCols; i++) {
          td = fzTr.insertCell(i);
        }
      }

      updGridTr(newTr, rowsCnt, fzTr);
      rowsCnt++;
      pageCnt = Math.ceil(rowsCnt / pageSize);
    }

    setFooter();
    this.rowInsMode();
  };

  this.rowUpd = function () {
    var fzTr;

    updArray(rowsAry[recNo]);
    if (config.freezeCols > 0) { fzTr = this.getDataTbody(gridTr.parentNode.parentNode.id).rows[gridTr.rowIndex]; }
    updGridTr(gridTr, recNo, fzTr);
  };

  this.rowDel = function () {
    var i = 0;

    if (! config.pageAjax) {
      rowsAry.splice(recNo, 1);
      rowsCnt--;
      pageCnt = Math.ceil(rowsCnt / pageSize);

      if (config.pageSize > 0) {
        if (pageIdx > pageCnt || rowsCnt === 0) {
          pageIdx = pageCnt;
          setGoToPage();
        }
        this.setPage(pageIdx);
      } else {
        var tb = $("tbGridData" + ID), anotherTb = $("tbGridFD" + ID), idx = gridTr.rowIndex;

        tb.deleteRow(idx);
        if (anotherTb) { anotherTb.deleteRow(idx); }

        for (i = recNo + 1; i <= rowsCnt; i++) {
          if (tb.childNodes[0].rows[i].className === "yGrDataTr0") {
            tb.childNodes[0].rows[i].className = "yGrDataTr1";
            if (anotherTb) { anotherTb.childNodes[0].rows[i].className = "yGrDataTr1"; }
          } else {
            tb.childNodes[0].rows[i].className = "yGrDataTr0";
            if (anotherTb) { anotherTb.childNodes[0].rows[i].className = "yGrDataTr0"; }
          }
        }

        setFooter();
      }
    }

    bindData("disabled");
    recNo = -1;
    gridTr = null;
  };

  this.updColumn = function (recIdx, colIdx, dt) {
    rowsAry[recIdx][colIdx] = dt;
  };

  this.getRows = function () {
    return rowsAry;
  };

  this.getID = function () {
    return ID;
  };

  this.refresh = function (refresh) {
    action = "rfr";
    if (arguments.length === 0) { refresh = "" };
    if (refresh === "") { this.callAjaxQuery(); }
    else { this.callAjaxQuery(refresh); }
    bindData("disabled");
  };
};

yGrid.count = 0;