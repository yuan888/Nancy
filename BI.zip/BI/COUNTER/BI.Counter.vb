Imports System
Imports Yuan

Namespace Yuan

Public Class COUNT021R

  Public Sub GetCounter(ByRef strTotal As String, ByRef strFirst As String, _
                        ByRef strAmount As String, ByRef strMax As String, _
                        ByRef strDay As String, ByRef strMonth As String)
    Dim strSQL, strFirstDay, strToday As String
    Dim strAryWeek() = {"�C", "�@", "�G", "�T", "�|", "��", "��"}
    Dim objTools As Tools = Tools.GetInstance()
    Dim cn, dr As Object

    strSQL = "select sum(amount) from bi_counter"
    strTotal = objTools.GetScalar(strSQL).ToString("#,##0")

    strSQL = "select min(c_date) from bi_counter"
    cn = objTools.GetConn()
    dr = objTools.GetReader(strSQL, cn)
    dr.Read()
    strFirstDay = dr.Item(0).ToString()
    dr.Close()
    strFirst = strFirstDay.Substring(0, 4) & "�~" & _
      CInt(strFirstDay.Substring(4, 2)) & "��" & _
      CInt(strFirstDay.Substring(6, 2)) & "��"

    strToday = DateTime.Now.ToString("yyyyMMdd")
    strSQL = "select amount from bi_counter where c_date=" & strToday
    strAmount = objTools.GetScalar(strSQL).ToString("#,##0")

    strSQL = "select max(amount) from bi_counter"
    strMax = objTools.GetScalar(strSQL).ToString("#,##0")

    Dim strPreDay, strCDate, strTd As String
    Dim intMax As Integer
    Dim dtThisDate As DateTime
    Dim sbTd1 As New Text.StringBuilder
    Dim sbTd2 As New Text.StringBuilder
    Dim sbEmpty As New Text.StringBuilder

    strPreDay = DateTime.Now.AddDays(-29).ToString("yyyyMMdd")
    strSQL = "select max(amount) from bi_counter where c_date between " & _
             strPreDay & " and " & strToday
    intMax = objTools.GetScalar(strSQL)

    sbTd1.Append("<tr bgcolor='#E0E0FF' align='center'>")
    sbTd2.Append("<tr bgcolor='#E0E0FF' align='center'>")
    strTd = "<td width='{0}' valign='bottom' class='text11'>{1}</td>"
    dtThisDate = DateTime.Parse(strPreDay.Substring(0 ,4) & "/" & _
      strPreDay.Substring(4, 2) & "/" & strPreDay.Substring(6, 2))

    If strPreDay < strFirstDay Then

       Do While dtThisDate.ToString("yyyyMMdd") < strFirstDay
          sbEmpty.Append(String.Format(strTd, "20", "&nbsp;"))
          dtThisDate = dtThisDate.AddDays(1)
       Loop

    End If

    strSQL = "select c_date,amount from bi_counter where c_date between " & _
             strPreDay & " and " & strToday & " order by c_date"
    dr = objTools.GetReader(strSQL, cn)

    Do While dr.Read()
       strCDate = dr.Item(0).ToString()

       If strCDate <> dtThisDate.ToString("yyyyMMdd") Then

          Do While dtThisDate.ToString("yyyyMMdd") < strCDate
             sbTd1.Append(String.Format(strTd, "20", "0"))
             sbTd2.Append(String.Format(strTd, "20", "<b>" & _
               CInt(dtThisDate.ToString("MM")) & "<br>��<br>" & _
               CInt(dtThisDate.ToString("dd")) & "<br>��<br>" & _
               strAryWeek(dtThisDate.DayOfWeek) & "</b>"))
             dtThisDate = dtThisDate.AddDays(1)
          Loop

       End If

       sbTd1.Append(String.Format(strTd, "20", CInt(dr.Item(1)).ToString() & _
         "<br><img src='../images/b1.gif' width='16' height='" & _
         97 * CInt(dr.Item(1)) / intMax & "'></td>"))
       sbTd2.Append(String.Format(strTd, "20", "<b>" & _
         CInt(strCDate.Substring(4 ,2)) & "<br>��<br>" & _
         CInt(strCDate.Substring(6 ,2)) & "<br>��<br>" & _
         strAryWeek(DateTime.Parse(strCDate.Substring(0 ,4) & "/" & _
         strCDate.Substring(4 ,2) & "/" & _
         strCDate.Substring(6 ,2)).DayOfWeek) & "</b></td>"))
       dtThisDate = dtThisDate.AddDays(1)
    Loop

    dr.Close()

    Do While dtThisDate.ToString("yyyyMMdd") <= strToday
       sbTd1.Append(String.Format(strTd, "20", "0"))
       sbTd2.Append(String.Format(strTd, "20", "<b>" & _
         CInt(dtThisDate.ToString("MM")) & "<br>��<br>" & _
         CInt(dtThisDate.ToString("dd")) & "<br>��<br>" & _
         strAryWeek(dtThisDate.DayOfWeek) & "</b></td>"))
       dtThisDate = dtThisDate.AddDays(1)
    Loop

    sbTd1.Append(sbEmpty.ToString() & "</tr>")
    sbTd2.Append(sbEmpty.ToString() & "</tr>")
    strDay = sbTd1.ToString() & sbTd2.ToString()
    sbTd1.Remove(0, sbTd1.Length)
    sbTd2.Remove(0, sbTd2.Length)
    sbEmpty.Remove(0, sbEmpty.Length)

    Dim strMM, strPreMM, strCYYMM As String

    sbTd1.Append("<tr bgcolor='#E0E0FF' align='center'>")
    sbTd2.Append("<tr bgcolor='#E0E0FF' align='center'>")
    strMM = strToday.Substring(0, 6)
    dtThisDate = dtThisDate.AddDays(-1)
    dtThisDate = dtThisDate.AddMonths(-11)
    strPreMM = dtThisDate.ToString("yyyyMM")

    If strPreMM < strFirstDay.Substring(0, 6) Then

       Do While dtThisDate.ToString("yyyyMM") < strFirstDay.Substring(0, 6)
          sbEmpty.Append(String.Format(strTd, "50", "&nbsp;"))
          dtThisDate = dtThisDate.AddMonths(1)
       Loop

    End If

    strSQL = "select max(a.amt) from (select c_yymm,sum(amount) as amt from bi_counter where c_yymm between " & _
             strPreMM & " and " & strMM & " group by c_yymm) a"
    intMax = objTools.GetScalar(strSQL)

    strSQL = "select c_yymm,sum(amount) as amt from bi_counter where c_yymm between " & _
             strPreMM & " and " & strMM & " group by c_yymm"
    dr = objTools.GetReader(strSQL, cn)

    Do While dr.Read()
       strCYYMM = dr.Item(0).ToString()

       If strCYYMM <> dtThisDate.ToString("yyyyMM") Then

          Do While dtThisDate.ToString("yyyyMM") < strCYYMM
             sbTd1.Append(String.Format(strTd, "50", "0"))
             sbTd2.Append(String.Format(strTd, "50", "<b>" & _
               dtThisDate.ToString("yyyy") & "<br>�~<br>" & _
               CInt(dtThisDate.ToString("MM")) & "<br>��</b></td>"))
             dtThisDate = dtThisDate.AddMonths(1)
          Loop

       End If

       sbTd1.Append(String.Format(strTd, "50", CInt(dr.Item(1)).ToString() & _
         "<br><img src='../images/b2.gif' width='16' height='" & _
         97 * CInt(dr.Item(1)) / intMax & "'></td>"))
       sbTd2.Append(String.Format(strTd, "50", "<b>" & _
         strCYYMM.Substring(0 ,4) & "<br>�~<br>" & _
         CInt(strCYYMM.Substring(4 ,2)) & "<br>��</b></td>"))
       dtThisDate = dtThisDate.AddMonths(1)
    Loop

    dr.Close()
    cn.Close()

    Do While dtThisDate.ToString("yyyyMM") <= strMM
       sbTd1.Append(String.Format(strTd, "50", "0"))
       sbTd2.Append(String.Format(strTd, "50", "<b>" & _
         dtThisDate.ToString("yyyy") & "<br>�~<br>" & _
        CInt(dtThisDate.ToString("MM")) & "<br>��</b></td>"))
       dtThisDate = dtThisDate.AddMonths(1)
    Loop

    sbTd1.Append(sbEmpty.ToString() & "</tr>")
    sbTd2.Append(sbEmpty.ToString() & "</tr>")
    strMonth = sbTd1.ToString() & sbTd2.ToString()
    sbTd1.Remove(0, sbTd1.Length)
    sbTd2.Remove(0, sbTd2.Length)
  End Sub

End Class
End Namespace