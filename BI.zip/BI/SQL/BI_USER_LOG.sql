-- Create table
create table BI_USER_LOG
(
  USER_ID     VARCHAR2(12) not null,
  LOGON_DATE  DATE default SYSDATE not null,
  LOGOFF_DATE DATE,
  SPEND_TIMES NUMBER(7,2) default 0,
  IP          VARCHAR2(16)
)
tablespace USERDATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
-- Create/Recreate primary, unique and foreign key constraints
alter table BI_USER_LOG
  add constraint BI_USER_LOG_FK1 foreign key (USER_ID)
  references BI_USER (USER_ID) on delete cascade;
-- Create/Recreate indexes
create index BI_USER_LOG_IX1 on BI_USER_LOG (LOGON_DATE,USER_ID)
  tablespace USERINDEX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
