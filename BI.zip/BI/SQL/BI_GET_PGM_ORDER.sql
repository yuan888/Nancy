CREATE FUNCTION bi_get_pgm_order (@group_id varchar(12),@order tinyint)
RETURNS varchar(36)
AS
BEGIN
  DECLARE @parent varchar(12)
  DECLARE @order_no tinyint
  DECLARE @retrun varchar(36)

  SET @parent=@group_id
  SET @retrun=SUBSTRING(CONVERT(char(3),@order+100),2,2)

  WHILE (@parent<>'ROOT')
  BEGIN
    select @parent = parent,@order_no = order_no
    from bi_pgm_group
    where group_id=@parent

    SET @retrun=SUBSTRING(CONVERT(char(3),@order_no+100),2,2)+@retrun
  END

  RETURN(@retrun)
END

create or replace function bi_get_pgm_order(v_group_id varchar,v_order number) return varchar2 is
  v_parent varchar2(12);
  v_order_no number;
  v_retrun varchar2(36);

begin
  v_parent:=v_group_id;
  v_retrun:=substr(to_char(v_order+100),2,2);

  while v_parent<>'ROOT' loop
    select parent,order_no
    into v_parent,v_order_no
    from bi_pgm_group
    where group_id=v_parent;

    v_retrun:=substr(to_char(v_order_no+100),2,2) || v_retrun;
  end loop;

  return v_retrun;

end;