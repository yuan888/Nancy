-- Create table
create table BI_PGM_LOG
(
  PGM_ID       VARCHAR2(12) not null,
  USER_ID      VARCHAR2(12) not null,
  EXECUTE_DATE DATE default SYSDATE not null,
  SPEND_TIMES  NUMBER(7,2) default 0
)
tablespace USERDATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
-- Create/Recreate primary, unique and foreign key constraints
alter table BI_PGM_LOG
  add constraint BI_PGM_LOG_PK primary key (PGM_ID,EXECUTE_DATE,USER_ID)
  using index
  tablespace USERINDEX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table BI_PGM_LOG
  add constraint BI_PGM_LOG_FK1 foreign key (PGM_ID)
  references BI_PGM (PGM_ID) on delete cascade;
alter table BI_PGM_LOG
  add constraint BI_PGM_LOG_FK2 foreign key (USER_ID)
  references BI_USER (USER_ID) on delete cascade;
-- Create/Recreate indexes
create index BI_PGM_LOG_IX1 on BI_PGM_LOG (USER_ID,EXECUTE_DATE)
  tablespace USERINDEX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
create index BI_PGM_LOG_IX2 on BI_PGM_LOG (EXECUTE_DATE)
  tablespace USERINDEX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
