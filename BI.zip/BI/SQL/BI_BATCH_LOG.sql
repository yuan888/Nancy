-- Create table
create table BI_BATCH_LOG
(
  SERNO       NUMBER(10) not null,
  PGM_ID      VARCHAR2(12) not null,
  PROGRESS    NUMBER(3) default 0 not null,
  REPORT_PATH VARCHAR2(50),
  BGN_DATE    DATE not null,
  END_DATE    DATE,
  SPEND_TIMES NUMBER(7,2) default 0 not null,
  UPD_USER    VARCHAR2(12)
)
tablespace USERDATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
-- Create/Recreate primary, unique and foreign key constraints
alter table BI_BATCH_LOG
  add constraint BI_BATCH_LOG_PK primary key (SERNO)
  using index
  tablespace USERINDEX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
-- Create/Recreate indexes
create index BI_BATCH_LOG_IX1 on BI_BATCH_LOG (BGN_DATE)
  tablespace USERINDEX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
create index BI_BATCH_LOG_IX2 on BI_BATCH_LOG (UPD_USER)
  tablespace USERINDEX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
