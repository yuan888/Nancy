-- Create table
create table BI_PGM_PARAM
(
  PARAM_TYPE  VARCHAR2(1) not null,
  PARAM_VALUE VARCHAR2(24) not null,
  PARAM_TEXT  VARCHAR2(24),
  COMM1       VARCHAR2(255),
  COMM2       VARCHAR2(255),
  UPD_USER    VARCHAR2(12),
  UPD_DATE    DATE default SYSDATE not null
)
tablespace USERDATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 128K
    minextents 1
    maxextents unlimited
  );
-- Create/Recreate primary, unique and foreign key constraints
alter table BI_PGM_PARAM
  add constraint BI_PGM_PARAM_PK primary key (PARAM_TYPE,PARAM_VALUE)
  using index
  tablespace USERINDEX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
