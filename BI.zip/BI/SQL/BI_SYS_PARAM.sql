-- Create table
create table BI_SYS_PARAM
(
  SYS_NAME     VARCHAR2(32) not null,
  WEBSITE_URL  VARCHAR2(32),
  OPEN_WINDOW  NUMBER(1) default 1 not null,
  SMTP_SERVER  VARCHAR2(32),
  SENDER_NAME  VARCHAR2(24),
  SENDER_EMAIL VARCHAR2(36),
  SENDER_ID    VARCHAR2(24),
  SENDER_PSW   VARCHAR2(16),
  MAIL_OBJECT  NUMBER(1) default 1 not null,
  BATCH_KEEP   NUMBER(3) default 0 not null,
  PAGE_SIZE    NUMBER(3) default 5 not null,
  TIME_OUT     NUMBER(3) default 10 not null,
  LOGON_CHECK  NUMBER(1) default 1 not null,
  DOMAIN_NAME  VARCHAR2(24),
  PSW_CHG_DAYS NUMBER(3) default 0 not null,
  PSW_CHG_DIFF NUMBER(1) default 0 not null,
  RELOGON      NUMBER(1) default 0 not null,
  USER_LOG     NUMBER(1) default 0 not null,
  PGM_LOG      NUMBER(1) default 0 not null,
  UPD_USER     VARCHAR2(12),
  UPD_DATE     DATE default SYSDATE not null
)
tablespace USERDATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 32K
    minextents 1
    maxextents unlimited
  );
