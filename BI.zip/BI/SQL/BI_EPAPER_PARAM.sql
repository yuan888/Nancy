-- Create table
create table BI_EPAPER_PARAM
(
  FAIL_CANCEL  NUMBER(3) default 0 not null,
  TRACE_CANCEL NUMBER(3) default 0 not null,
  EPAPER_KEEP  NUMBER(3) default 0 not null,
  FAIL_KEEP    NUMBER(3) default 0 not null,
  TRACE_KEEP   NUMBER(3) default 0 not null,
  REPLACE_NAME VARCHAR2(36),
  UPD_USER     VARCHAR2(12),
  UPD_DATE     DATE not null
)
tablespace USERDATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
