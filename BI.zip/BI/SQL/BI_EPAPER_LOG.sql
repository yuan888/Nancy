-- Create table
create table BI_EPAPER_LOG
(
  SERNO          NUMBER(10) not null,
  PRIORITY       VARCHAR2(8) not null,
  SUBJECT        VARCHAR2(80) not null,
  CONTENT        VARCHAR2(3000) not null,
  ATTACHMENT     VARCHAR2(80),
  REPLACE        CHAR(2) not null,
  CONTENT_ATTACH CHAR(2) not null,
  TRACE          CHAR(2) not null,
  BATCH          CHAR(2) not null,
  FINISH         CHAR(2) default '�_' not null,
  SUCCESS        NUMBER(7) default 0 not null,
  FAIL           NUMBER(7) default 0 not null,
  RECEIVE        NUMBER(7) default 0 not null,
  SEND_USER      VARCHAR2(12),
  SEND_DATE      DATE default sysdate not null,
  FINISH_DATE    DATE,
  SPEND_TIMES    NUMBER(7,2) default 0 not null
)
tablespace USERDATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
-- Create/Recreate primary, unique and foreign key constraints
alter table BI_EPAPER_LOG
  add constraint BI_EPAPER_LOG_PK primary key (SERNO)
  using index
  tablespace USERINDEX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
-- Create/Recreate indexes
create index BI_EPAPER_LOG_IX1 on BI_EPAPER_LOG (SEND_DATE)
  tablespace USERDATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
