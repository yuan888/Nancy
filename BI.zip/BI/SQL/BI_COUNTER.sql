-- Create table
create table BI_COUNTER
(
  C_DATE VARCHAR2(8) not null,
  C_YYMM VARCHAR2(6) not null,
  AMOUNT NUMBER(7) default 1 not null
)
tablespace USERDATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
-- Create/Recreate primary, unique and foreign key constraints
alter table BI_COUNTER
  add constraint BI_COUNTER_PK primary key (C_DATE)
  using index
  tablespace USERINDEX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
-- Create/Recreate indexes
create index BI_COUNTER_IX1 on BI_COUNTER (C_YYMM)
  tablespace USERINDEX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
create index BI_COUNTER_IX2 on BI_COUNTER (AMOUNT)
  tablespace USERINDEX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
