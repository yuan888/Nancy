-- Create table
create table BI_EPAPER_TRACE
(
  EPAPER      NUMBER(10) not null,
  SERNO       NUMBER(10) not null,
  EMAIL       VARCHAR2(36) not null,
  NAME        VARCHAR2(36),
  WATCH       NUMBER(3) default 0 not null,
  SEND_DATE   DATE default sysdate not null,
  RECEIVE_DATE DATE
)
tablespace USERDATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
-- Create/Recreate primary, unique and foreign key constraints
alter table BI_EPAPER_TRACE
  add constraint BI_EPAPER_TRACE_FK1 foreign key (EPAPER)
  references BI_EPAPER_LOG (SERNO) on delete cascade;
-- Create/Recreate indexes
create index BI_EPAPER_TRACE_IX1 on BI_EPAPER_TRACE (EPAPER,EMAIL)
  tablespace USERDATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
create index BI_EPAPER_TRACE_IX2 on BI_EPAPER_TRACE (EPAPER,RECEIVE_DATE)
  tablespace USERDATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
