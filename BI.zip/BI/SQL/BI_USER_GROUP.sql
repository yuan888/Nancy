-- Create table
create table BI_USER_GROUP
(
  GROUP_NAME VARCHAR2(24) not null,
  COMM       VARCHAR2(255),
  UPD_USER   VARCHAR2(12),
  UPD_DATE   DATE default SYSDATE not null
)
tablespace USERDATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 128K
    minextents 1
    maxextents unlimited
  );
-- Create/Recreate primary, unique and foreign key constraints
alter table BI_USER_GROUP
  add constraint BI_USER_GROUP_PK primary key (GROUP_NAME)
  using index
  tablespace USERINDEX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
