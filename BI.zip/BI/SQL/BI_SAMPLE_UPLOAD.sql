-- Create table
create table BI_SAMPLE_UPLOAD
(
  FILE_SERNO  NUMBER(1) not null,
  FILE_DESC   VARCHAR2(50) not null,
  FILE_TYPE   VARCHAR2(26) not null,
  FILE_OBJECT BLOB
)
tablespace USERDATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
