-- Create table
create table BI_USER
(
  USER_ID        VARCHAR2(12) not null,
  USER_NAME      VARCHAR2(16),
  PSW            VARCHAR2(40),
  EMAIL          VARCHAR2(36),
  USER_GROUP     VARCHAR2(254),
  USER_GROUP_KEY VARCHAR2(40),
  EFF_END_DATE   VARCHAR2(8),
  STOP           CHAR(1) default 'F' not null,
  ERR_NUMBER     NUMBER(2) default 0 not null,
  PSW_CHG_DAYS   NUMBER(3) default 0 not null,
  LAST_DATE      DATE,
  LAST_IP        VARCHAR2(16),
  PSW_CHG_DATE   DATE,
  UPD_USER       VARCHAR2(12),
  UPD_DATE       DATE default SYSDATE not null
)
tablespace USERDATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 128K
    minextents 1
    maxextents unlimited
  );
-- Create/Recreate primary, unique and foreign key constraints
alter table BI_USER
  add constraint BI_USER_PK primary key (USER_ID)
  using index
  tablespace USERINDEX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
