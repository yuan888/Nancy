-- Drop table
drop table BI_USER_AUTH cascade constraints;
-- Create table
create table BI_USER_AUTH
(
  ACCOUNT  VARCHAR2(12) not null,
  PGM_ID   VARCHAR2(12) not null,
  QRY      NUMBER(1) default 0 not null,
  INS      NUMBER(1) default 0 not null,
  UPD      NUMBER(1) default 0 not null,
  DEL      NUMBER(1) default 0 not null,
  SPE      VARCHAR2(100),
  AUTH_KEY VARCHAR2(40),
  UPD_USER VARCHAR2(12),
  UPD_DATE DATE default SYSDATE not null
)
tablespace USERDATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 128K
    minextents 1
    maxextents unlimited
  );
-- Create/Recreate primary, unique and foreign key constraints
alter table BI_USER_AUTH
  add constraint BI_USER_AUTH_PK primary key (ACCOUNT, PGM_ID)
  using index
  tablespace USERINDEX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table BI_USER_AUTH
  add constraint BI_USER_AUTH_FK1 foreign key (PGM_ID)
  references BI_PGM (PGM_ID) on delete cascade;
-- Create/Recreate indexes
create index BI_USER_AUTH_IX1 on BI_USER_AUTH (PGM_ID)
  tablespace USERINDEX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
