-- Create table
create table BI_EPAPER_SUBS
(
  EMAIL      VARCHAR2(36) not null,
  NAME       VARCHAR2(36),
  SEND_FAIL  NUMBER(5) default 0 not null,
  TRACE_FAIL NUMBER(5) default 0 not null,
  UPD_DATE   DATE default sysdate not null
)
tablespace USERDATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
-- Create/Recreate primary, unique and foreign key constraints
alter table BI_EPAPER_SUBS
  add constraint BI_EPAPER_SUBS_PK primary key (EMAIL)
  using index
  tablespace USERDATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
-- Create/Recreate indexes
create index BI_EPAPER_SUBS_IX1 on BI_EPAPER_SUBS (SEND_FAIL)
  tablespace USERDATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
create index BI_EPAPER_SUBS_IX2 on BI_EPAPER_SUBS (TRACE_FAIL)
  tablespace USERDATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
