-- Create table
create table BI_PGM
(
  PGM_ID    VARCHAR2(12) not null,
  PGM_NAME  VARCHAR2(24) not null,
  LINK_PATH VARCHAR2(48) not null,
  PGM_TYPE  VARCHAR2(24) not null,
  AUTHOR    VARCHAR2(16),
  GROUP_ID  VARCHAR2(12) not null,
  ORDER_NO  NUMBER(3) default 0 not null,
  COMM      VARCHAR2(255),
  UPD_USER  VARCHAR2(12),
  UPD_DATE  DATE default SYSDATE not null
)
tablespace USERDATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 128K
    minextents 1
    maxextents unlimited
  );
-- Create/Recreate primary, unique and foreign key constraints
alter table BI_PGM
  add constraint BI_PGM_PK primary key (PGM_ID)
  using index
  tablespace USERINDEX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table BI_PGM
  add constraint BI_PGM_FK1 foreign key (GROUP_ID)
  references BI_PGM_GROUP (GROUP_ID) on delete cascade;
-- Create/Recreate indexes
create index BI_PGM_IX1 on BI_PGM (GROUP_ID)
  tablespace USERINDEX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
