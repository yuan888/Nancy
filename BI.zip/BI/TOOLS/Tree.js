// Methods common to both objects (pseudo-inheritance)
// ********************************************************
function display() {
  this.navObj.style.display = "block";
}

function createEntryIndex() {
  this.id = nEntries;
  indexOfEntries[nEntries] = this;
  nEntries++;
}

// Events
// *********************************************************
function clickOnNode(folderId) {
  var clickedFolder = 0;
  var state = 0;

  clickedFolder = indexOfEntries[folderId];
  state = clickedFolder.isOpen;

  clickedFolder.setState(!state); //open<->close
}

function clickOnFolder(folderId) {
  clickOnNode(folderId);
}
// ********************************************************

function propagateChangesInState(folder) {
  var i = 0;

  if (folder.isOpen) {
    if (folder.nodeImg) {
      if (folder.isLastNode) {
        folder.nodeImg.src = "images/mmlastnode.gif";
      } else {
	      folder.nodeImg.src = "images/mmnode.gif";
	    }
	  }

    folder.iconImg.src = "images/mfolderopen.gif";
    for (i = 0; i < folder.nChildren; i++) {
      folder.children[i].display();
    }
  } else {
    if (folder.nodeImg) {
      if (folder.isLastNode) {
        folder.nodeImg.src = "images/mplastnode.gif";
      } else {
	      folder.nodeImg.src = "images/mpnode.gif";
	    }
	  }
    folder.iconImg.src = "images/mfolderclosed.gif";
    for (i = 0; i < folder.nChildren; i++) {
      folder.children[i].hide();
    }
  }
}

function setStateFolder(isOpen) {
  var subEntries;
  var fIt = 0;
  var i = 0;

  if (isOpen == this.isOpen) {
    return;
  }

  this.isOpen = isOpen;
  propagateChangesInState(this);
}

function hideFolder() {
  if (this.navObj.style.display == "none") {return;}
  this.navObj.style.display = "none";
  this.setState(0);
}

function initializeFolder(level, lastNode, leftSide) {
  var j = 0;
  var i = 0;
  var numberOfFolders;
  var numberOfDocs;
  var nc;

  nc = this.nChildren;
  this.createIndex();

  var auxEv = "";

  auxEv = "<a hidefocus=true href='javascript:clickOnNode(" + this.id + ")'>";

  if (level > 0) {
    if (lastNode) //the last 'brother' in the children array
    {
      this.renderOb(leftSide + auxEv + "<img id='nodeIcon" + this.id + "' src='images/mmlastnode.gif' width=16 height=22 border=0></a>");
      leftSide = leftSide + "<img src='images/mblank.gif' width=16 height=22>";
      this.isLastNode = 1;
    } else {
      this.renderOb(leftSide + auxEv + "<img id='nodeIcon" + this.id + "' src='images/mmnode.gif' width=16 height=22 border=0></a>");
      leftSide = leftSide + "<img src='images/mvertline.gif' width=16 height=22>";
      this.isLastNode = 0;
    }
   } else {
    if (this.desc !== "") { this.renderOb(""); }
   }

  if (nc > 0) {
    level = level + 1;
    for (i = 0 ; i < this.nChildren; i++) {
      if (i == this.nChildren-1) {
        this.children[i].initialize(level, 1, leftSide);
      } else {
        this.children[i].initialize(level, 0, leftSide);
      }
    }
  }
}

function drawFolder(leftSide) {
  doc.write("<table ");
  doc.write(" id='folder" + this.id + "' style='position:block;' ");
  doc.write(" border=0 cellspacing=0 cellpadding=0>");
  doc.write("<tr><td>");
  doc.write(leftSide);
  this.outputLink("folder");
  doc.write("<img id='folderIcon" + this.id + "' ");
  doc.write("src='" + this.iconSrc + "' border=0></a>");
  doc.write("</td><td valign=middle nowrap>");

  if (USETEXTLINKS) {
    this.outputLink("text");
    doc.write(this.desc + "</a>");
  } else {
    doc.write(this.desc);
  }

  doc.write("</td>");
  doc.write("</table>");

  this.navObj = doc.getElementById("folder" + this.id);
  this.iconImg = doc.getElementById("folderIcon" + this.id);
  this.nodeImg = doc.getElementById("nodeIcon" + this.id);
}

function outputFolderLink(linkObj) {
  if (this.hreference) {
    doc.write("<a hidefocus=true href='" + this.hreference + "' ");
    if (this.target) { doc.write("target='" + this.target + "' "); }
    doc.write(">");
  } else if ((linkObj == "folder" && this.fldLink == "1") || this.fldLink == "2") {
    doc.write("<a hidefocus=true href='javascript:clickOnFolder(" + this.id + ")'");
    doc.write(">");
  } else {
    doc.write("<a>");
  }
}

function addChild(childNode) {
  this.children[this.nChildren] = childNode;
  this.nChildren++;
  return childNode;
}

function folderSubEntries() {
  var i = 0;
  var se = this.nChildren;

  for (i = 0; i < this.nChildren; i++) {
    if (this.children[i].children) { //is a folder
      se = se + this.children[i].subEntries();
    }
  }

  return se;
}

function Folder(folderDescription, folderLink, hreference, target) { //constructor
  //constant data
  this.desc = folderDescription;
  this.fldLink = folderLink;
  this.hreference = hreference;
  this.target = target;
  this.id = -1;
  this.navObj = 0;
  this.iconImg = 0;
  this.nodeImg = 0;
  this.isLastNode = 0;

  //dynamic data
  this.isOpen = true;
  this.iconSrc = "images/mfolderopen.gif";
  this.children = new Array();
  this.nChildren = 0;

  //methods
  this.initialize = initializeFolder;
  this.setState = setStateFolder;
  this.addChild = addChild;
  this.createIndex = createEntryIndex;
  this.hide = hideFolder;
  this.display = display;
  this.renderOb = drawFolder;
  this.subEntries = folderSubEntries;
  this.outputLink = outputFolderLink;
}

// Definition of class Item (a document or link inside a Folder)
// *************************************************************
function hideItem() {
  if (this.navObj.style.display == "none") {
    return;
  }
  this.navObj.style.display = "none";
}

function initializeItem(level, lastNode, leftSide) {
  this.createIndex();

  if (level > 0) {
    if (lastNode) { //the last 'brother' in the children array
      this.renderOb(leftSide + "<img src='images/mlastnode.gif' width=16 height=22>");
      leftSide = leftSide + "<img src='images/mblank.gif' width=16 height=22>";
    } else {
      this.renderOb(leftSide + "<img src='images/mnode.gif' width=16 height=22>");
      leftSide = leftSide + "<img src='images/mvertline.gif' width=16 height=22>";
    }
  } else {
    this.renderOb("");
  }
}

function drawItem(leftSide) {
  doc.write("<table ");
  doc.write(" id='item" + this.id + "' style='position:block;' ");
  doc.write(" border=0 cellspacing=0 cellpadding=0>");
  doc.write("<tr><td>");
  doc.write(leftSide);
  doc.write("<a hidefocus=true href=" + this.link + ">");
  doc.write("<img id='itemIcon" + this.id + "' ");
  doc.write("src='" + this.iconSrc + "' border=0>");
  doc.write("</a>");
  doc.write("</td><td valign=middle nowrap>");
  if (USETEXTLINKS) {
    doc.write("<a hidefocus=true href=" + this.link + ">" + this.desc + "</a>");
  } else {
    doc.write(this.desc);
  }
  doc.write("</table>");

  this.navObj = doc.getElementById("item" + this.id);
  this.iconImg = doc.getElementById("itemIcon" + this.id);
}

function Item(itemDescription, itemLink, pgmType) { // Constructor
  // constant data
  this.desc = itemDescription;
  this.link = itemLink;
  this.id = -1; //initialized in initalize()
  this.navObj = 0; //initialized in render()
  this.iconImg = 0; //initialized in render()

  switch (pgmType) {
    case "M" :
      this.iconSrc = "images/mmaintain.gif";
      break;
    case "P" :
      this.iconSrc = "images/mprocess.gif";
      break;
    case "R" :
      this.iconSrc = "images/mreport.gif";
      break;
    default :
      this.iconSrc = "images/mdoc.gif";
  }

  // methods
  this.initialize = initializeItem;
  this.createIndex = createEntryIndex;
  this.hide = hideItem;
  this.display = display;
  this.renderOb = drawItem;
}

function initializeDocument(fld) {
  fld.initialize(0, 1, "");

  if (fld.desc !== "") {
    fld.display();
  }

  // close the whole tree
  for (i = 0; i < fld.nChildren; i++) {
    if (fld.children[i].iconSrc.indexOf("mfolderopen") > 0) {
      clickOnNode(fld.children[i].id);
    }
  }

  doc.write("<div top=" + indexOfEntries[nEntries - 1].navObj.top + ">&nbsp;</div>");
}

// Auxiliary Functions for Folder-Treee backward compatibility
// *********************************************************
function gFld(description, fldLink, hreference, target) {
  description = description;
  folder = new Folder(description, fldLink, hreference, target);
  return folder;
}

function gLnk(target, description, linkData, pgmType) {
  description = description;
  fullLink = "";

  if (target === 0) {
    fullLink = "'" + linkData + "' target=_top";
  } else if (target == 1) {
    fullLink = "'" + linkData + "' target=_blank";
  } else if (target == 2) {
    fullLink = "'" + linkData + "' target=fraMain";
  } else {
    fullLink = "'" + linkData + "'";
  }

  linkItem = new Item(description, fullLink, pgmType);
  return linkItem;
}

function insFld(parentFolder, childFolder) {
  return parentFolder.addChild(childFolder);
}

function insDoc(parentFolder, document) {
  parentFolder.addChild(document);
}

// Global variables
// ****************
USETEXTLINKS = 1;
indexOfEntries = new Array();
nEntries = 0;
doc = document;