// �u���@��
var blnOnce = true;
// �e���ѪR��
var intResolution;
// Grid���ؤo
var intGridWidth = 0;
var intGridHeight = 0;
// GridTitle���e�ץ[�j��
var intTitleAdd;
// GridData��Class
var strDataClass;

if (screen.width <= 800) {
	 intResolution = 800;
	 intGridHeight = 135;
	 intTitleAdd = 0;
	 strDataClass = "Text14";
}
else {
	 intResolution = screen.width;
	 intGridHeight = 145;
	 intTitleAdd = 17;
	 strDataClass = "Text16";
}

// �e���r���j�p
var strFontType

// ��ư����v��
var blnIns
var blnUpd
var blnDel

// ��Ƶ���
var intRow = 0;
// �������
var intCol = 0;
// ����
var intPage = 1;
// ���Ƥj�p
var intPageSize = 1;
// �s���ƪ��}�C
var strAryData

// Title���I���C��
var strTrTitBgC = "#00008b";
// Title����r�C��
var strTrTitFtC = "#ffffff";
// ��ƪ��I���C��
var strTrDatBgC = "lemonchiffon";
// ��ƪ���r�C��
var strTrDatFtC = "black";
// ���div���I���C��
var strDivBgC = "#cccccc";
// ���Tr�Q�諸�I���C��
var strTrSelBgC = "LightSalmon";
// �O���ثe�b��Ƥ��ҿ�w��record number
var intRecNo = 0;
// �O���W���b��Ƥ��ҿ�w��Tr
var objOldTr

// ���ѼƬO���FGRID2�ҳ]�G�O���������R�O
var strChgPageCmd = "";

// ���J��ƳB�z���T��
function LoadWait() {
	if (! document.getElementById("divLoadWait"))
     document.write("<div id='divLoadWait'><table class='Text20' width='100%' height='95%' align='center' valign='middle' style='cursor:wait'><tr><td width='100%' height='100%' align='center' valign='middle'><b><font color='blue' face='�з���'>��ƳB�z���A�еy�ԡD�D�D</font></b></td></tr></table></div>");
  else {
     divLoadWait.style.display = "";
     divAll.style.display = "none";
  }
}

// �M����ƳB�z���T��
function ClearLoadWait() {
  if (document.getElementById("divAll")) {
     divLoadWait.style.display = "none";
     divAll.style.display = "";
  }
}

// ���Y�@ row ��,���� row �I���C��αN��Ʊa�J�浧���@�e���åB�]�w���@���s�����A
function trDataRow_onClick(objTr) {
  var blnDisabled = false;

  intRecNo = objTr.value;
  if (objOldTr) objOldTr.bgColor = strTrDatBgC;
  objTr.bgColor = strTrSelBgC;
  objOldTr = objTr;

  Load_Data();
  document.frmMain.hidAction.value = "UPD";
  DisableFrmMainText(false);

  if (blnUpd) blnDisabled = false;
  else blnDisabled = true;

  if (document.frmMain.btnSubmit)
     document.frmMain.btnSubmit.disabled = blnDisabled;
  if (document.frmMain.btnReset)
     document.frmMain.btnReset.disabled = blnDisabled;

  if (blnDel) blnDisabled = false;
  else blnDisabled = true;

  if (document.frmMain.btnDel)
     document.frmMain.btnDel.disabled = blnDisabled;
}

// ���U�s�W���s
function btnIns_onClick() {
  if (objOldTr) objOldTr.bgColor = strTrDatBgC;
  document.frmMain.reset();
  document.frmMain.hidAction.value = "INS";
  DisableFrmMainText(false);
  document.frmMain.btnSubmit.disabled = false;
  document.frmMain.btnDel.disabled = true;
  document.frmMain.btnReset.disabled = false;
}

// ���U�������s
function btnChgPage_onClick(strAction, strQryPgm) {
  var strQPK1 = "";
  var strQPK2 = "";
  var strPPK1 = "";
  var strPPK2 = "";

  strChgPageCmd = strAction;
  DisablePageBtn();

  switch (strAction) {
    case "First" :
      intPage = 1;
      break;
    case "Previous" :
      intPage--;
      strPPK1 = strAryData[0][0];
      if (document.frmMain)
         if (document.frmMain.hidPK2) strPPK2 = strAryData[0][1];
      break;
    case "Next" :
      if (intRow >= intPage * intPageSize) intNO = intPageSize - 1;
      else intNO = (intRow - 1) % intPageSize;
      intPage++;
      strPPK1 = strAryData[intNO][0];
      if (document.frmMain)
         if (document.frmMain.hidPK2 != null) strPPK2 = strAryData[intNO][1];
      break;
    case "Last" :
      intPage = Math.ceil(intRow / intPageSize);
      break;
    case "Refresh" :
      strPPK1 = strAryData[0][0];
      if (document.frmMain)
         if (document.frmMain.hidPK2) strPPK2 = strAryData[0][1];
      break;
  }

// GRID1
  if (strQryPgm == null) {
     strChgPageCmd = "";
     SetTable(intPage);
// GRID2
  } else {
     if (document.frmQuery.strQPK1 != null) strQPK1 = document.frmQuery.strQPK1.value;
     if (document.frmQuery.strQPK2 != null) strQPK2 = document.frmQuery.strQPK2.value;
     strURL = strQryPgm + ".aspx?strAction=" + strAction +
              "&intPageSize=" + intPageSize +
              "&strQPK1=" + strQPK1 + "&strQPK2=" + strQPK2 +
              "&strPPK1=" + strPPK1 + "&strPPK2=" + strPPK2;
     parent.fraHide.document.location.href = strURL;
  }
}

// Disable�������s���A
function DisablePageBtn() {
  if (document.frmPage.btnIns) document.frmPage.btnIns.disabled = true;
  document.frmPage.btnFirst.disabled = true;
  document.frmPage.btnPrevious.disabled = true;
  document.frmPage.btnNext.disabled = true;
  document.frmPage.btnLast.disabled = true;
}

// ��s�������s���A
function ResetPageBtn() {
  if (document.frmPage.btnIns)
     if (blnIns) document.frmPage.btnIns.disabled = false;
     else document.frmPage.btnIns.disabled = true;

  if (strChgPageCmd == "") {
     if (intPage > 1) {
        document.frmPage.btnFirst.disabled = false;
        document.frmPage.btnPrevious.disabled = false;
     } else {
        document.frmPage.btnFirst.disabled = true;
        document.frmPage.btnPrevious.disabled = true;
     }

     if (intPage < Math.ceil(intRow / intPageSize)) {
        document.frmPage.btnNext.disabled = false;
        document.frmPage.btnLast.disabled = false;
     } else {
        document.frmPage.btnNext.disabled = true;
        document.frmPage.btnLast.disabled = true;
     }

  } else {
     if (strChgPageCmd == "Refresh") strChgPageCmd = "Next";

     switch (strChgPageCmd) {
       case "First" :
         if (intRow > intPageSize) {
            document.frmPage.btnNext.disabled = false;
            document.frmPage.btnLast.disabled = false;
         }
         break;
       case "Previous" :
         document.frmPage.btnNext.disabled = false;
         document.frmPage.btnLast.disabled = false;
         if (intRow > intPageSize) {
            document.frmPage.btnFirst.disabled = false;
            document.frmPage.btnPrevious.disabled = false;
         }
         break;
      case "Next" :
         document.frmPage.btnFirst.disabled = false;
         document.frmPage.btnPrevious.disabled = false;
         if (intRow > intPageSize) {
            document.frmPage.btnNext.disabled = false;
            document.frmPage.btnLast.disabled = false;
         }
         break;
       case "Last" :
         document.frmPage.btnFirst.disabled = false;
         document.frmPage.btnPrevious.disabled = false;
         break;
     }
  }
}

// ���U�R�����s
function btnDel_onClick() {
  if (confirm("�O�_�R���o���O���H")) {
     document.frmMain.hidAction.value = "DEL";
     DisableAllBtn();
     document.frmMain.submit();
  }
}

// ���U���]���s
function btnReset_onClick() {
  if (document.frmMain.hidAction.value == "UPD")
     Load_Data();
  else {
     document.frmMain.reset();
     document.frmMain.hidAction.value = "INS";
  }
}

function DisableAllBtn() {
  if (document.frmMain.btnSubmit) document.frmMain.btnSubmit.disabled = true;
  if (document.frmMain.btnDel) document.frmMain.btnDel.disabled = true;
  if (document.frmMain.btnReset) document.frmMain.btnReset.disabled = true;
  DisablePageBtn();
}

function ResetAllBtn() {
  if (blnUpd)
     if (document.frmMain.hidAction.value == "UPD") {
        if (document.frmMain.btnSubmit) document.frmMain.btnSubmit.disabled = false;
        if (document.frmMain.btnReset) document.frmMain.btnReset.disabled = false;
        if (document.frmMain.btnDel)
           if (blnDel) document.frmMain.btnDel.disabled = false;
     }

  ResetPageBtn();
}

// �s�W�}�C�������
function Ins_Data() {
  intRow++;

  if (intRow == 1 && strAryData == null) {
     strAryData = new Array(intRow);
     strAryData[0] = new Array(intCol);
  } else {
     strAryData.length = intRow;
     strAryData[intRow - 1] = new Array(intCol);
  }

  SetDataAry(intRow - 1);
  SetTable(intPage);
  document.frmMain.reset();
  document.frmMain.hidAction.value = "";
  DisableFrmMainText(true);
}

// ��s�}�C�������
function Upd_Data() {
  SetDataAry(intRecNo - 1);
  SetTable(intPage);
  objTr = document.getElementById("trDataRow" + (intRecNo - 1));

  if (objTr) {
     if (objOldTr) objOldTr.bgColor = strTrDatBgC;
     objTr.bgColor = strTrSelBgC;
     objOldTr = objTr;
  }
}

// �R���}�C�������
function Del_Data() {
  for (intI = intRecNo - 1; intI < intRow - 1; intI++)
      strAryData[intI] = strAryData[intI + 1];

  intRow--;
  strAryData.length = intRow;

  if (intPage > Math.ceil(intRow / intPageSize))
     intPage = Math.ceil(intRow / intPageSize);

  if (intPage == 0) intPage = 1;

  SetTable(intPage);
  document.frmMain.reset();
  document.frmMain.hidAction.value = "";
  DisableFrmMainText(true);
}

function SetGridSize() {
// Query�BTitle�θ��div���e�סA���div������
  var objDivQ = document.all["divQuery"];

  if (intResolution != 800 || intGridWidth == 0)
     if (trHead.offsetWidth > intGridWidth) intGridWidth = trHead.offsetWidth;

  if (objDivQ) divQuery.style.width = intGridWidth + 21;

  if (strFontType == "G") divData.style.width = intGridWidth + 17;
  else divData.style.width = intGridWidth + 21;

  divHead.style.width = intGridWidth;

  if (blnOnce) {
  	 blnOnce = false;
  	 if (intPageSize > 5) intGridHeight = intGridHeight + (intPageSize - 5) * 20;
  }

  if (divData.offsetHeight < intGridHeight) {
  	 if (divData.offsetHeight > intGridHeight - 15) {
  	 	   intGridHeight = divData.offsetHeight;
  	 } else
  	 	   if (divData.offsetHeight != 0) divData.style.height = intGridHeight;
  	     else if (intRow < intPageSize) divData.style.height = intGridHeight;
  } else {
  	intGridHeight = divData.offsetHeight;
  }
}