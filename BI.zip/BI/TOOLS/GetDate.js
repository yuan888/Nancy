// ������
// �ǤJ�Gtype ���ˬd�������A1���ǥX������~�A
//                          2���ǥX���褸�~�A
//                          4���ǥX�榡��YYMMDD or YYYMMDD or YYYYMMDD�A
//                          8���ǥX�榡��YY/MM/DD or YYY/MM/DD or YYYY/MM/DD�A
//       days ���ҭn�W��Ѽ�
//       �ǤJ�Ȧ�5,6,9,10
function GetDate(type, days) {
  var OD = new Date();
  var chkdd = new Array(13);

  chkdd[1] = 31;
  chkdd[2] = 28;
  chkdd[3] = 31;
  chkdd[4] = 30;
  chkdd[5] = 31;
  chkdd[6] = 30;
  chkdd[7] = 31;
  chkdd[8] = 31;
  chkdd[9] = 30;
  chkdd[10] = 31;
  chkdd[11] = 30;
  chkdd[12] = 31;

  if (! days) days = 0;

  yyyy = OD.getYear();
  mm = OD.getMonth() + 1;
  dd = OD.getDate();
  dd = parseFloat(dd) + parseFloat(days);
  chkdd[2] = GetFebDays(yyyy);

  if (dd > 0)

     while (dd > chkdd[mm]) {
     	dd -= chkdd[mm];
     	mm += 1;

     	if (mm > 12) {
     	   mm = 1;
     	   yyyy += 1;
     	   chkdd[2] = GetFebDays(yyyy);
     	}

     }

  else

     while (dd <= 0) {
       mm -= 1;

       if (mm == 0) {
          mm = 12;
          yyyy -= 1;
          chkdd[2] = GetFebDays(yyyy);
       }

       dd += chkdd[mm];
     }

  dd = dd + 100;
  dd = dd + " ";
  dd = dd.substring(1, 3);
  mm = mm + 100;
  mm = mm + " ";
  mm = mm.substring(1, 3);

  if (type == 5 || type == 9) yyyy -= 1911;

  if (type == 5 || type == 6) return (yyyy + "" + mm + "" + dd);
  else return (yyyy + "/" + parseFloat(mm) + "/" + parseFloat(dd));
}

function GetFebDays(yyyy) {
  var FebDays = 28;

  if (yyyy % 4 == 0) {
     if (yyyy % 100 != 0)
        FebDays = 29;
     else
        if (yyyy % 400 == 0) FebDays = 29;
  }

  return FebDays;
}