if (parent.fraMenu) strFontType = parent.fraMenu.strFontType;
else if (parent.parent.fraMenu) strFontType = parent.parent.fraMenu.strFontType;
else strFontType = "G";

// �b�e���W���UEnter���,�첾�U�@�ӱ��
function window.document.onkeydown() {
  if (window.event.srcElement.type != "text" &&
      window.event.srcElement.type != "password" &&
      window.event.srcElement.type != "radio" &&
      window.event.srcElement.type != "checkbox" &&
      window.event.srcElement.type != "select-one") return true;
  if (window.event.keyCode == 13) window.event.keyCode = 9;
}

function Hide_Focus() {

  if (document.all) {
     var tags = document.all.tags("input");
     for (var i = 0; i < tags.length; i++)
         tags(i).outerHTML = tags(i).outerHTML.replace(">", " hidefocus=true>");

     tags = document.all.tags("label");
     for (var i = 0; i < tags.length; i++)
         tags(i).outerHTML = tags(i).outerHTML.replace(">", " hidefocus=true>");

     var blnIE;

     if (navigator.userAgent.indexOf("MSIE") > 0) blnIE = true;
     else blnIE = false;

     if (screen.width > 800) {
        tags = document.all.tags("tr");
        var re = /Text14/g;
        for (var i = 0; i < tags.length; i++)
           if (blnIE) tags(i).setAttribute("className", "Text16");
           else tags(i).setAttribute("class", "Text16");

        tags = document.all.tags("span");
        var re = /Text14/g;
        for (var i = 0; i < tags.length; i++)
           if (blnIE) tags(i).setAttribute("className", "Text16");
           else tags(i).setAttribute("class", "Text16");
     }
  }
}