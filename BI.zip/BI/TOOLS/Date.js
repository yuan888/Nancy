// �����J���
// �ǤJ�Gchkyy���~�� text ����Achkmm���몺 text ����Achkdd���骺 text ����
// �ǥX�G
// ���ܡG�骺 text���󪺿�ܭ�
function ChangeSelectDate(chkyy, chkmm, chkdd)
{
  var index = 0;
  var OD = new Date();
  now_chkyy = OD.getYear();

  if ( now_chkyy >= "2000") now_chkyy -= 1911;
  else now_chkyy -= 11;

  errcode = CheckNumber(chkyy, 3, 1, now_chkyy);

  if (errcode != 0) {

     switch(errcode)
     {
       case 1:
         alert("�п�J�ͤ�~���I");
         break;
       case 2:
         alert("�ͤ�~���п�J�Ʀr�I");
         break;
       case 3:
         alert("�X�ͦ~����J���~�I");
     }

     chkyy.focus();
     return false;
  }

  var chkchkyy = chkyy.value * 10 / 10 + 1911;
  var chkchkdd = chkdd.options[chkdd.options.selectedIndex].value * 10 / 10;
  chkad = new Array(13);
  chkad[1] = 31;
  chkad[2] = 28;
  chkad[3] = 31;
  chkad[4] = 30;
  chkad[5] = 31;
  chkad[6] = 30;
  chkad[7] = 31;
  chkad[8] = 31;
  chkad[9] = 30;
  chkad[10] = 31;
  chkad[11] = 30;
  chkad[12] = 31;

  if (chkmm.options[chkmm.options.selectedIndex].value == "02")
     if (chkchkyy % 4 == 0)
     {
        if (chkchkyy % 100 != 0)
           chkad[2] = 29;
        else
           if (chkchkyy % 400 == 0) chkad[2] = 29;
     }
  chkdd.length = chkad[chkmm.options[chkmm.options.selectedIndex].value * 10 / 10];
  for (i =1 ; i <= chkad[chkmm.options[chkmm.options.selectedIndex].value * 10 / 10]; i++)
  {
       temp = i+100;
       temp = temp + ""
       chkdd.options[index].value = temp.substring(1, 3);
       chkdd.options[index].text = temp.substring(1, 3);
       index++;
  }
}