// ����ˬd���
// �ǤJ�Gtype ���ˬd�������A1����J������~�A
//                          2����J���褸�~�A
//                          4����J�榡��YYMMDD or YYYMMDD or YYYYMMDD�A
//                          8����J�榡��YY/MM/DD or YYY/MM/DD or YYYY/MM/DD�A
//       �ǤJ�Ȧ�5,6,9,10
// �ǥX�Gerrcode �] 0�G���T�A1�G�ťաA2�G������׿��~�A3�G����榡���~�^
//                  4�G�~��餣�O�����Ʀr�A5�G�����J�Ȥ��X�k�^
function CheckDate(chkdate, type) {
  errcode = 0;

  if (type == "") type = 5;

  if (chkdate.value.length == 0) {
     errcode = 1;
     return errcode;
  }

  if (chkdate.value.length < 6) {
     errcode = 2;
     return errcode;
  }

  switch(type) {
    case 5 :
      if (chkdate.value.length == 6) {
         yy = chkdate.value.substring(0, 2);
         mm = chkdate.value.substring(2, 4);
         dd = chkdate.value.substring(4, 6);
      } else {
         yy = chkdate.value.substring(0, 3);
         mm = chkdate.value.substring(3, 5);
         dd = chkdate.value.substring(5, 7);
      }

      yy = parseFloat(yy) + 1911;
      break;
    case 6 :
      yy = chkdate.value.substring(0, 4);
      mm = chkdate.value.substring(4, 6);
      dd = chkdate.value.substring(6, 8);
      break;
    default :
      index1 = chkdate.value.indexOf("/");
      index2 = chkdate.value.lastIndexOf("/");

      if (index1 < 0 || index1 == index2) {
         errcode = 3;
         return errcode;
      } else {
         yy = chkdate.value.substring(0, index1);
         mm = chkdate.value.substring(index1+1, index2);
         dd = chkdate.value.substring(index2+1, chkdate.value.length);
      }

      if (type == 9) yy = parseFloat(yy) + 1911;
  }

  if (yy == "" || mm == "" || dd == "" ) {
     errcode = 3;
     return errcode;
  }

  ymd1 = yy + mm + dd;
  ymd2 = parseFloat(ymd1);

  if (ymd1 != "" + ymd2) {
     errcode = 4;
     return errcode;
  }

  mm = parseFloat(mm);

  if (mm > 12 || mm < 1) {
     errcode = 5;
     return errcode;
  }

  chkdd = new Array(13);
  chkdd[1] = 31;
  chkdd[2] = 28;
  chkdd[3] = 31;
  chkdd[4] = 30;
  chkdd[5] = 31;
  chkdd[6] = 30;
  chkdd[7] = 31;
  chkdd[8] = 31;
  chkdd[9] = 30;
  chkdd[10] = 31;
  chkdd[11] = 30;
  chkdd[12] = 31;

  if (mm == 2)
     if (yy % 4 == 0)
        if (yy % 100 != 0) chkdd[2] = 29;
        else if (yy % 400 == 0) chkdd[2] = 29;

  dd = parseFloat(dd);

  if (dd > chkdd[mm]) {
     errcode = 5;
     return errcode;
  }

  return errcode;
}