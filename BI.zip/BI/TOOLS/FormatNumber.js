// �Ʀr�榡�ƨ��
// �ǤJ�G�Ʀr
// �ǥX�G�榡�ƫ᪺�Ʀr�r��A�� 12345.12 -> 12,345.12
function FormatNumber(intNum) {
  var strReturn = "";
  var blnMinus = false;
  var intI = 0;
  var intJ = 0;
  var intPos = 0;
  var strNum = "";
  var strLeft = ""
  var strRight = "";

  if (intNum < 0) {
     blnMinus = true;
     strNum = "" + ( - intNum);
  } else
     strNum = "" + intNum;

  intPos = strNum.indexOf(".")
  if (intPos > 0) {
     strLeft = strNum.substring(0, intPos);
     strRight = strNum.substring(intPos + 1);
  } else {
     strLeft = strNum;
     strRight = "";
  }

  for (intI = strLeft.length - 1; intI >= 0; intI--) {
      strReturn = strLeft.charAt(intI) + strReturn;
      if (intI && (++intJ % 3 == 0)) strReturn = "," + strReturn;
  }

  if (blnMinus) strReturn = "-" + strReturn;
  if (intPos > 0) strReturn = strReturn + "." + strRight;

  return strReturn;
}