var strAryItem
var strItemName = "";
var strDiff = "";
var intItemIndex = 0;

function Load_Item_Data() {
  strHTML = "<form name='frmItem'>" +
            "<table onBlur=btn_onBlur('divOrderNo') border='0' cellpadding='0' cellspacing='4'>" +
            "<tr><th><select name='selItem' size='9' disabled='true'></th>" +
            "<th align='center' valign='middle'>" +
            "<input type='button' name='btnUp' value='  ��  ' hidefocus='true'" +
            " onClick='btnUp_onClick(document.frmItem.selItem)' onBlur=btn_onBlur('divOrderNo')><br>" +
            "<input type='button' name='btnDown' value='  ��  ' hidefocus='true'" +
            " onClick='btnDown_onClick(document.frmItem.selItem)' onBlur=btn_onBlur('divOrderNo')><br>" +
            " <input type='button' name='btnItemOK' value='�T�w'" +
            " onClick='btnItemOK_onClick()'>" +
            "</th></tr></table></form>"
  divOrderNo.innerHTML = strHTML;

  var intJ = 0;
  var objItem = document.frmItem.selItem;
  objItem.length = strAryItem.length;

  for (intI = 0; intI < strAryItem.length; intI++) {

      if (intItemIndex == intJ) {
         objItem.options[intJ].value = strItemName;
         objItem.options[intJ].text = strDiff + " | " + strItemName;
         intJ++;
      }

      if (strAryItem[intI][0] != strDiff || strAryItem[intI][1] != strItemName) {
         objItem.options[intJ].value = strAryItem[intI][1];
         objItem.options[intJ].text = strAryItem[intI][0] + " | " + strAryItem[intI][1];
         intJ++;
      }

  }

  objItem.options.selectedIndex = intItemIndex;
  divOrderNo.style.display = "";
}

function btnUp_onClick(objItem) {
  DisableItemBtn(true);

  if (objItem.options.selectedIndex > 0) {
     strValue = objItem.options[intItemIndex].value;
     strText = objItem.options[intItemIndex].text;
     objItem.options[intItemIndex].value = objItem.options[intItemIndex - 1].value;
     objItem.options[intItemIndex].text = objItem.options[intItemIndex - 1].text;
     objItem.options[intItemIndex - 1].value = strValue;
     objItem.options[intItemIndex - 1].text = strText;
     intItemIndex--;
     objItem.options.selectedIndex = intItemIndex;
  }

  DisableItemBtn(false);
  document.frmItem.btnUp.focus();
}

function btnDown_onClick(objItem) {
  DisableItemBtn(true);

  if (objItem.options.selectedIndex < strAryItem.length - 1) {
      strValue = objItem.options[intItemIndex].value;
      strText = objItem.options[intItemIndex].text;
      objItem.options[intItemIndex].value = objItem.options[intItemIndex + 1].value;
      objItem.options[intItemIndex].text = objItem.options[intItemIndex + 1].text;
      objItem.options[intItemIndex + 1].value = strValue;
      objItem.options[intItemIndex + 1].text = strText;
      intItemIndex++;
      objItem.options.selectedIndex = intItemIndex;
   }

   DisableItemBtn(false);
   document.frmItem.btnDown.focus();
}

function btnItemOK_onClick() {
  document.frmMain.txtOrderNo.value = intItemIndex + 1;
  divOrderNo.style.display = "none";
}

function DisableItemBtn(blnDisable) {
  document.frmItem.btnUp.disabled = blnDisable;
  document.frmItem.btnDown.disabled = blnDisable;
  document.frmItem.btnItemOK.disabled = blnDisable;
}