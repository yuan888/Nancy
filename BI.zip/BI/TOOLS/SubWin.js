var strOldBtnName, objTxtSubWin;

function btnSubWin_onClick(strNotEq) {
  objBtnSubWin = document.elementFromPoint(window.event.clientX, window.event.clientY);
  strBtnName = objBtnSubWin.name;

  if (strOldBtnName != strBtnName || divSubWin.style.display == "none") {
  	 strOldBtnName = strBtnName;
  	 objTxtSubWin = document.getElementById("txt" + strBtnName.substring(3));

     if (parent.frs2) {
        intIndex = parent.frs2.cols.indexOf(",");
        intCol = parseFloat(parent.frs2.cols.substring(0, intIndex));
     } else intCol = 0;

     if (intCol + event.clientX + 200 < screen.availwidth)
        divSubWin.style.pixelLeft = event.clientX - GetAbsoluteLeft(strBtnName) +
        GetAbsoluteLeft(objTxtSubWin.name) - event.offsetX - 3;
     else
        divSubWin.style.pixelLeft = event.clientX - GetAbsoluteLeft(strBtnName) +
        GetAbsoluteLeft(objTxtSubWin.name) - event.offsetX - 116;

     if (screen.width <= 800) {
     	  intHeight = 600;
     	  intResolution = 800;
     } else {
     	  intHeight = 768;
     	  intResolution = screen.width;
     }

     if (event.clientY + 254 < intHeight)
        divSubWin.style.pixelTop = GetAbsoluteTop(strBtnName) + 24;
     else divSubWin.style.pixelTop = GetAbsoluteTop(strBtnName) - 140;

     parent.fraHide.document.location.href = "../tools/suwin011s.aspx?intResolution=" + intResolution +
       "&strFontType=" + strFontType + "&strDiv=" + strBtnName.substring(3) +
       "&strEq=" + objTxtSubWin.value + "&strNotEq=" + strNotEq;
 } else divSubWin.style.display = "none";
}

function trSubWin_onClick(objTr) {
  if (objTxtSubWin) objTxtSubWin.value = objTr.value;
  divSubWin.style.display = "none";
}

function btn_onBlur(strDiv) {

  var objEvent = window.event;

  if (strDiv == null || strDiv == "") strDiv = "divSubWin";

  if ((objEvent.clientX > 0) && (objEvent.clientY > 0) &&
      (objEvent.clientX < document.body.clientWidth) &&
      (objEvent.clientY < document.body.clientHeight)) {
      var objTmp = document.elementFromPoint(objEvent.clientX, objEvent.clientY);

      while ((objTmp.tagName != "BODY") && (objTmp.id != strDiv))
	    objTmp = objTmp.offsetParent;

      if (objTmp.id == strDiv) return;
  }

  document.getElementById(strDiv).style.display = "none";
}