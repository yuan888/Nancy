function GetAbsoluteTop(strIdName) {
  var intTop = 0;
  var objItem = document.getElementById(strIdName);

  while (objItem != null) {
    intTop += objItem.offsetTop;
    objItem = objItem.offsetParent;
  }

  return intTop;
}

function GetAbsoluteLeft(strIdName) {
  var intLeft = 0;
  var objItem = document.getElementById(strIdName);

  while (objItem != null) {
    intLeft += objItem.offsetLeft;
    objItem = objItem.offsetParent;
  }

  return intLeft;
}