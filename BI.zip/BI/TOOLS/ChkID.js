// �����Ҧr���βΤ@�s���ˬd���
// �ǤJ�Gidno���ˬd���X�� text ����
// �ǥX�Gerrcode �] 0�G���T�A1�G�ťաA2�G��J�����A3�G�Ĥ@�X���~�A
//                  4�G�ĤG�X���~�A5�G��K�X���~�^
function CheckID(idno) {
  idno.value = idno.value.toUpperCase();
  errcode = 0;

  if (idno.value == "") {
     errcode = 1;
     return errcode;
  }

  if (idno.value.length != 10 && idno.value.length != 8) {
     errcode = 2;
     return errcode;
  }

  if (idno.value.length == 10) {
     if ( (idno.value.charAt(0) == "A" && idno.value.charAt(1) == "A") || (idno.value.charAt(0) == "A" && idno.value.charAt(1) == "Z") ) {
        return errcode;
     }
     if (idno.value.charAt(0) < "A" || idno.value.charAt(0) > "Z") {
        errcode=3;
        return errcode;
     }
     if (idno.value.charAt(1) != 1 && idno.value.charAt(1) != 2) {
        errcode=4;
        return errcode;
     }

     id1 = idno.value.charAt(0)

     switch(id1) {
       case "A" :
         id0 = 1;
         break;
       case "B" :
         id0 = 10;
         break;
       case "C" :
         id0 = 19;
         break;
       case "D" :
         id0 = 28;
         break;
       case "E" :
         id0 = 37;
         break;
       case "F" :
         id0 = 46;
         break;
       case "G" :
         id0 = 55;
         break;
       case "H" :
         id0 = 64;
         break;
       case "I" :
         id0 = 39;
         break;
       case "J" :
         id0 = 73;
         break;
       case "K" :
         id0 = 82;
         break;
       case "L" :
         id0 = 2;
         break;
       case "M" :
         id0 = 11;
         break;
       case "N" :
         id0 = 20;
         break;
       case "O" :
         id0 = 48;
         break;
       case "P" :
         id0 = 29;
         break;
       case "Q" :
         id0 = 38;
         break;
       case "R" :
         id0 = 47;
         break;
       case "S" :
         id0 = 56;
         break;
       case "T" :
         id0 = 65;
         break;
       case "U" :
         id0 = 74;
         break;
       case "V" :
         id0 = 83;
         break;
       case "W" :
         id0 = 21;
         break;
       case "X" :
         id0 = 3;
         break;
       case "Y" :
         id0 = 12;
         break;
       case "Z" :
         id0 = 30;
     }

     id2 = id0 + idno.value.charAt(1) * 8 + idno.value.charAt(2) * 7 + idno.value.charAt(3) * 6 +
           idno.value.charAt(4) * 5 + idno.value.charAt(5) * 4 + idno.value.charAt(6) * 3 +
           idno.value.charAt(7) * 2 + idno.value.charAt(8) * 1 + idno.value.charAt(9) * 1;

     if (id2 % 10 != 0) errcode = 5;
     return errcode;

  } else {
     var wPattern = /^[0-9]{8}/;

     if ( ! wPattern.test(idno.value)) {
        errcode=5;
        return errcode;
     } else {
       var wD = new Array();
       var wA = new Array();
       var wX = new Array();
       var wZ1 = 0, wZ2 = 0;

       for (i = 1; i <= 8; i++)
           wD[i] = idno.value.charAt(i - 1);

       wA[1] = wD[1] * 1;
       wA[2] = wD[2] * 2;
       wA[3] = wD[3] * 1;
       wA[4] = wD[4] * 2;
       wA[5] = wD[5] * 1;
       wA[6] = wD[6] * 2;
       wA[7] = wD[7] * 4;
       wA[8] = wD[8] * 1;

       wX[1] = wA[1];
       wX[2] = parseInt(wA[2] / 10) + wA[2] % 10;
       wX[3] = wA[3];
       wX[4] = parseInt(wA[4] / 10) + wA[4] % 10;
       wX[5] = wA[5];
       wX[6] = parseInt(wA[6] / 10) + wA[6] % 10;
       wX[7] = parseInt(wA[7] / 10) + wA[7] % 10 ;
       wX[8] = wA[8];

       for (i = 1; i <= 8; i++)
           wZ2 += wX[i] % 10;

       if (wD[7] == 7)
          wZ1 = wZ2 + 1;
       else
          wZ1 = wZ2;

       if (wZ1 % 10 == 0 || wZ2 % 10 == 0)
          return errcode;
       else {
          errcode=5;
          return errcode;
       }
     }
  }
}