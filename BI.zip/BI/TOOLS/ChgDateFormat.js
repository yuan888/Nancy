// ����榡�ഫ���
// intType = 1
// �ǤJ�GYY/MM/DD or YYY/MM/DD or YYYY/MM/DD
// �ǥX�GYYYMMDD or YYYYMMDD
// intType = 2
// �ǤJ�GYYMMDD or YYYMMDD or YYYYMMDD
// �ǥX�GYY/MM/DD or YYY/MM/DD or YYYY/MM/DD
function ChangeDateFormat(strDate, intType) {
	if (! intType) intType = 1;

  if (intType == 1) {
     index1 = strDate.indexOf("/");
     index2 = strDate.lastIndexOf("/");

     if (index1 < 0 || index1 == index2) {
        if (strDate.length == 6) strDate = "0" + strDate;
        return strDate;
     } else {
        strYY = strDate.substring(0, index1);
        if (strYY.length == 2) strYY = "0" + strYY;
        strMM = strDate.substring(index1 + 1, index2);
        if (strMM.length == 1) strMM = "0" + strMM;
        strDD = strDate.substring(index2 + 1, strDate.length);
        if (strDD.length == 1) strDD = "0" + strDD;
        return (strYY + strMM + strDD);
      }
   } else {
     if (strDate.length < 6) return strDate;
     else {
       switch(strDate.length) {
         case 8 :
           strYY = strDate.substring(0, 4);
           strMM = strDate.substring(4, 6);
           strDD = strDate.substring(6, 8);
           break;
         case 7 :
           strYY = strDate.substring(0, 3);
           strMM = strDate.substring(3, 5);
           strDD = strDate.substring(5, 7);
           break;
         case 6 :
           strYY = strDate.substring(0, 2);
           strMM = strDate.substring(2, 4);
           strDD = strDate.substring(4, 6);
       }

     return parseFloat(strYY) + "/" + parseFloat(strMM) + "/" + parseFloat(strDD);
     }
   }
}