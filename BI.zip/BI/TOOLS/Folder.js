function Folder(folderDescription, fldLink , hreference) { //constructor
  //constant data
  this.desc = folderDescription
  this.fldLink = fldLink
  this.hreference = hreference
  this.id = -1
  this.navObj = 0
  this.iconImg = 0
  this.nodeImg = 0
  this.isLastNode = 0

  //dynamic data
  this.isOpen = true
  this.iconSrc = "../images/mfolderopen.gif"
  this.children = new Array
  this.nChildren = 0

  //methods
  this.initialize = initializeFolder
  this.setState = setStateFolder
  this.addChild = addChild
  this.createIndex = createEntryIndex
  this.hide = hideFolder
  this.display = display
  this.renderOb = drawFolder
  this.totalHeight = totalHeight
  this.subEntries = folderSubEntries
  this.outputLink = outputFolderLink
}

function setStateFolder(isOpen) {
  var subEntries
  var totalHeight
  var fIt = 0
  var i = 0

  if (isOpen == this.isOpen)
    return

  if (browserVersion == 2)
  {
    totalHeight = 0
    for (i = 0; i < this.nChildren; i++)
      totalHeight = totalHeight + this.children[i].navObj.clip.height
      subEntries = this.subEntries()
    if (this.isOpen)
      totalHeight = 0 - totalHeight
    for (fIt = this.id + subEntries + 1; fIt < nEntries; fIt++)
      indexOfEntries[fIt].navObj.moveBy(0, totalHeight)
  }
  this.isOpen = isOpen
  propagateChangesInState(this)
}

function propagateChangesInState(folder) {
  var i = 0

  if (folder.isOpen)   {
     if (folder.nodeImg)
        if (folder.isLastNode)
           folder.nodeImg.src = "../images/mmlastnode.gif"
        else
	   folder.nodeImg.src = "../images/mmnode.gif"
     folder.iconImg.src = "../images/mfolderopen.gif"
     for (i = 0; i < folder.nChildren; i++)
         folder.children[i].display()
  } else {
    if (folder.nodeImg)
       if (folder.isLastNode)
          folder.nodeImg.src = "../images/mplastnode.gif"
       else
	  folder.nodeImg.src = "../images/mpnode.gif"
    folder.iconImg.src = "../images/mfolderclosed.gif"
    for (i = 0; i < folder.nChildren; i++)
      folder.children[i].hide()
  }
}

function hideFolder() {
  if (browserVersion == 1) {
     if (this.navObj.style.display == "none") return
     this.navObj.style.display = "none"
  } else {
     if (this.navObj.visibility == "hiden") return
     this.navObj.visibility = "hiden"
  }

  this.setState(0)
}

function initializeFolder(level, lastNode, leftSide) {
  var j = 0
  var i = 0
  var numberOfFolders
  var numberOfDocs
  var nc
  var auxEv = ""

  nc = this.nChildren
  this.createIndex()

  if (browserVersion > 0)
     auxEv = "<a hidefocus=true href='javascript:clickOnNode(" + this.id + ")'>"
  else
     auxEv = "<a>"

  if (level>0)
     if (lastNode) { //the last 'brother' in the children array
        this.renderOb(leftSide + auxEv + "<img name='nodeIcon" + this.id + "' src='../images/mmlastnode.gif' width=16 height=22 border=0></a>")
        leftSide = leftSide + "<img src='../images/mblank.gif' width=16 height=22>"
        this.isLastNode = 1
     } else {
        this.renderOb(leftSide + auxEv + "<img name='nodeIcon" + this.id + "' src='../images/mmnode.gif' width=16 height=22 border=0></a>")
        leftSide = leftSide + "<img src='../images/mvertline.gif' width=16 height=22>"
        this.isLastNode = 0
     } else
       if (this.desc != "") this.renderOb("")

     if (nc > 0) {
        level = level + 1
        for (i = 0 ; i < this.nChildren; i++) {
            if (i == this.nChildren-1)
               this.children[i].initialize(level, 1, leftSide)
            else
               this.children[i].initialize(level, 0, leftSide)
        }
     }
}

function drawFolder(leftSide) {
  if (browserVersion == 2) {
     if (! doc.yPos) doc.yPos = 8
     doc.write("<layer id='folder" + this.id + "' top=" + doc.yPos + " visibility=hiden>")
  }

  doc.write("<table ")
  if (browserVersion == 1)
     doc.write(" id='folder" + this.id + "' style='position:block;' ")
  doc.write(" border=0 cellspacing=0 cellpadding=0>")
  doc.write("<tr><td>")
  doc.write(leftSide)
  this.outputLink("folder")
  doc.write("<img name='folderIcon" + this.id + "' ")
  doc.write("src='" + this.iconSrc + "' border=0></a>")
  doc.write("</td><td valign=middle nowrap>")
  if (USETEXTLINKS) {
     this.outputLink("text")
     doc.write(this.desc + "</a>")
  } else
     doc.write(this.desc)
  doc.write("</td>")
  doc.write("</table>")

  if (browserVersion == 2) {
     doc.write("</layer>")
  }

  if (browserVersion == 1) {
     this.navObj = doc.all["folder" + this.id]
     this.iconImg = doc.all["folderIcon" + this.id]
     this.nodeImg = doc.all["nodeIcon" + this.id]
  } else
     if (browserVersion == 2) {
        this.navObj = doc.layers["folder" + this.id]
        this.iconImg = this.navObj.document.images["folderIcon" + this.id]
        this.nodeImg = this.navObj.document.images["nodeIcon" + this.id]
        doc.yPos=doc.yPos + this.navObj.clip.height
     }
  }

function outputFolderLink(linkObj) {
  if ((linkObj == "folder" && this.fldLink == "1") || this.fldLink == "2") {
     doc.write("<a hidefocus=true href='javascript:clickOnFolder(" + this.id + ")'")
     doc.write(">")
  } else
     doc.write("<a>")
}

function addChild(childNode) {
  this.children[this.nChildren] = childNode
  this.nChildren++
  return childNode
}

function folderSubEntries() {
  var i = 0
  var se = this.nChildren

  for (i = 0; i < this.nChildren; i++) {
      if (this.children[i].children) //is a folder
         se = se + this.children[i].subEntries()
  }

  return se
}

// Methods common to both objects (pseudo-inheritance)
// ********************************************************

function display() {
  if (browserVersion == 1)
     this.navObj.style.display = "block"
  else
     this.navObj.visibility = "show"
}

function createEntryIndex() {
  this.id = nEntries
  indexOfEntries[nEntries] = this
  nEntries++
}

// total height of subEntries open
function totalHeight() { //used with browserVersion == 2
  var h = this.navObj.clip.height
  var i = 0

  if (this.isOpen) //is a folder and _is_ open
     for (i = 0 ; i < this.nChildren; i++)
         h = h + this.children[i].totalHeight()

  return h
}

// Events
// *********************************************************

function clickOnFolder(folderId) {
  clickOnNode(folderId)
}

function clickOnNode(folderId) {
  var clickedFolder = 0
  var state = 0

  clickedFolder = indexOfEntries[folderId]
  state = clickedFolder.isOpen

  if (callget == 1 && ! state) {
     document.location.href = "FILMG012L.aspx?strPath=" + clickedFolder.hreference
     if (clickedFolder.hreference != "") parent.fraFile.location.href = 'FILMG013L.aspx?strPath=' + clickedFolder.hreference
     else parent.fraFile.location.href = "../BLANK.htm"
  } else clickedFolder.setState(0)
}

function initializeDocument() {
  if (doc.all)
    browserVersion = 1 //IE4
  else
    if (doc.layers)
      browserVersion = 2 //NS4
    else
      browserVersion = 0 //other

  Root.initialize(0, 1, "")

  if (Root.desc != "")
    Root.display()

  // close the whole tree
  for (i = 0; i < Root.nChildren; i++)
      if (Root.children[i].iconSrc.indexOf("mfolderopen") > 0)
         clickOnNode(Root.children[i].id)

  callget = 1

  if (browserVersion > 0) {
    doc.write("<layer top=" + indexOfEntries[nEntries-1].navObj.top + ">&nbsp;</layer>")
  }
}

// Auxiliary Functions for Folder-Treee backward compatibility
// *********************************************************

function gFld(description, fldLink, hreference) {
  description = description
  folder = new Folder(description, fldLink, hreference)
  return folder
}

function insFld(parentFolder, childFolder) {
  return parentFolder.addChild(childFolder)
}

// Global variables
// ****************

USETEXTLINKS = 1
indexOfEntries = new Array
nEntries = 0
doc = document
browserVersion = 0
selectedFolder = 0
callget = 0