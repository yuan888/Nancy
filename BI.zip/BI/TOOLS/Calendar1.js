// �����
var intDataType;
var weekend = [0,6];
var gNow = new Date();
var gDiv;
var gTxt;
var gCal;
var intDivY = 0;
Calendar.Months = ["�@", "�G", "�T", "�|", "��", "��","�C", "�K", "�E", "�Q", "�Q�@", "�Q�G"];
Calendar.DOMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
Calendar.lDOMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
Calendar.get_month = Calendar_get_month;
Calendar.get_daysofmonth = Calendar_get_daysofmonth;
Calendar.calc_month_year = Calendar_calc_month_year;

function Calendar(p_month, p_year) {
  if (p_month == null && p_year == null) return;

  if (p_month == null) {
     this.gMonthName = null;
     this.gMonth = null;
     this.gShowNextMonth = false;
  } else {
     this.gMonthName = Calendar.get_month(p_month);
     this.gMonth = new Number(p_month);
     this.gShowNextMonth = false;
  }

  this.gYear = p_year;
}

function Calendar_get_month(monthNo) { return Calendar.Months[monthNo]; }

function Calendar_get_daysofmonth(monthNo, p_year) {
  if (p_year % 4 == 0) {
     if (p_year % 100 == 0 && p_year % 400 != 0) return Calendar.DOMonth[monthNo];
     else return Calendar.lDOMonth[monthNo];
  } else return Calendar.DOMonth[monthNo];
}

function Calendar_calc_month_year(p_Month, p_Year, incr) {
  var ret_arr = new Array();

  if (incr == -1) {
     if (p_Month == 0) {
        ret_arr[0] = 11;
        ret_arr[1] = parseFloat(p_Year) - 1;
     } else {
        ret_arr[0] = parseFloat(p_Month) - 1;
        ret_arr[1] = parseFloat(p_Year);
     }
  } else if (incr == 1) {
     if (p_Month == 11) {
        ret_arr[0] = 0;
        ret_arr[1] = parseFloat(p_Year) + 1;
     } else {
        ret_arr[0] = parseFloat(p_Month) + 1;
        ret_arr[1] = parseFloat(p_Year);
     }
  }

  return ret_arr;
}

Calendar.prototype.getMonthlyCalendarCode = function() {
  var vCode = "";
  var vHeader_Code = "";
  var vData_Code = "";

  vHeader_Code = this.cal_header();
  vData_Code = this.cal_data();
  vCode = vHeader_Code + vData_Code + "</TABLE>";
  return vCode;
}

Calendar.prototype.show = function() {
  var vCode = "";
  var prevMMYYYY = Calendar.calc_month_year(this.gMonth, this.gYear, -1);
  var prevMM = prevMMYYYY[0];
  var prevYYYY = prevMMYYYY[1];
  var nextMMYYYY = Calendar.calc_month_year(this.gMonth, this.gYear, 1);
  var nextMM = nextMMYYYY[0];
  var nextYYYY = nextMMYYYY[1];
  var yearType = "";
  var year = 0;

  if (intDataType == 6 || intDataType == 10) {
  	 yearType = "�褸";
  	 year = this.gYear;
  } else {
  	 yearType = "����";
  	 year = this.gYear - 1911;
  }

  vCode = "<TABLE onBlur=\"btnCalendar_onBlur('divCalendar')\" WIDTH='100%' BORDER=0 CELLSPACING=0 CELLPADDING=0>" +
          "<TR CLASS=\"Text14\">" +
          "<TH WIDTH=\"25%\" STYLE=\"cursor:hand\" onClick=\"Build('" + this.gMonth + "', '" +
          (parseFloat(this.gYear)-1) + "')\"><FONT COLOR=\"BLUE\" TITLE=\"��֦~��\">[ �� ]</FONT></TH>" +
          "<TH WIDTH=\"25%\" STYLE=\"cursor:hand\" onClick=\"Build('" + prevMM + "', '" +
          prevYYYY + "')\"><FONT COLOR=\"BLUE\" TITLE=\"��֤��\">[ �� ]</FONT></TH>" +
          "<TH WIDTH=\"25%\" STYLE=\"cursor:hand\" onClick=\"Build('" + nextMM + "', '" +
          nextYYYY + "')\"><FONT COLOR=\"BLUE\" TITLE=\"�W�[���\">[ �� ]</FONT></TH>" +
          "<TH WIDTH=\"25%\" STYLE=\"cursor:hand\" onClick=\"Build('" + this.gMonth + "', '" +
          (parseFloat(this.gYear)+1) + "')\"><FONT COLOR=\"BLUE\" TITLE=\"�W�[�~��\">[ �� ]</FONT></TH></TR></TABLE>" +
          "<TABLE onBlur=btnCalendar_onBlur('divCalendar') CELLSPACING=0 CELLPADDING=1 BORDER=1 WIDTH='100%'>" +
          "<CAPTION onBlur=btnCalendar_onBlur('divCalendar') CLASS=\"Text16\">" + yearType + year + "�~" + this.gMonthName + "��</CAPTION>" +
          this.getMonthlyCalendarCode();
  return vCode;
}

Calendar.prototype.cal_header = function() {
  var vCode = "";
  vCode = "<TR CLASS=\"Text14\" BGCOLOR=\"Silver\">" +
          "<TH onBlur=btnCalendar_onBlur('divCalendar') WIDTH='14.25%'>��</TH>" +
          "<TH onBlur=btnCalendar_onBlur('divCalendar') WIDTH='14.25%'>�@</TH>" +
          "<TH onBlur=btnCalendar_onBlur('divCalendar') WIDTH='14.25%'>�G</TH>" +
          "<TH onBlur=btnCalendar_onBlur('divCalendar') WIDTH='14.25%'>�T</TH>" +
          "<TH onBlur=btnCalendar_onBlur('divCalendar') WIDTH='14.25%'>�|</TH>" +
          "<TH onBlur=btnCalendar_onBlur('divCalendar') WIDTH='14.25%'>��</TH>" +
          "<TH onBlur=btnCalendar_onBlur('divCalendar') WIDTH='14.25%'>��</TH>";
          "</TR>";
  return vCode;
}

Calendar.prototype.cal_data = function() {
  var vDate = new Date();
  vDate.setDate(1);
  vDate.setMonth(this.gMonth);
  vDate.setFullYear(this.gYear);
  var vFirstDay = vDate.getDay();
  var vDay = 1;
  var vLastDay = Calendar.get_daysofmonth(this.gMonth, this.gYear);
  var vOnLastDay = 0;
  var vCode = "";
  vCode = "<TR CLASS=\"Text14\" ALIGN=\"CENTER\">\n";

  for (i = 0; i<vFirstDay; i++) {
      vCode += "<TD" + this.write_weekend_string(i) + " onBlur=btnCalendar_onBlur('divCalendar')>&nbsp;</TD>\n";
  }

  for (j = vFirstDay; j < 7; j++) {
      vCode += "<TD" + this.write_weekend_string(j) +
             " onClick=\"tdDate_onClick('" + vDay +"')\">" +
             this.format_day(vDay) + "</TD>\n";
      vDay = vDay + 1;
  }

  vCode += "</TR>\n";

  for (k = 2; k < 7; k++) {
      vCode += "<TR CLASS=\"Text14\" ALIGN=\"CENTER\">";
      for (j = 0; j < 7; j++) {
          vCode += "<TD" + this.write_weekend_string(j) +
                   " onClick=\"tdDate_onClick('" +vDay +"')\">" +
      this.format_day(vDay) + "</TD>\n";
      vDay = vDay + 1;
      if (vDay > vLastDay) {
         vOnLastDay = 1;
         break;
      }
    }
    if (j == 6)	vCode += "</TR>";
    if (vOnLastDay == 1) break;
  }

  for (m = 1; m < (7 - j); m++) {
      if (this.gShowNextMonth)
         vCode += "<TD" + this.write_weekend_string(j+m) + "><FONT COLOR='gray'>" + m + "</FONT></TD>\n";
      else vCode += "<TD" + this.write_weekend_string(j+m) + ">&nbsp;</TD>\n";
  }

  return vCode;
}

Calendar.prototype.format_day = function(vday) {
  var vNowDay = gNow.getDate();
  var vNowMonth = gNow.getMonth();
  var vNowYear = gNow.getFullYear();
  if (vday == vNowDay && this.gMonth == vNowMonth && this.gYear == vNowYear) {
     return ("<FONT COLOR=\"RED\"><B>" + vday + "</B></FONT>");
  } else return (vday);
}

Calendar.prototype.write_weekend_string = function(vday) {
  var i;
  for (i = 0; i<weekend.length; i++) {
      if (vday == weekend[i]) return (" BGCOLOR=\"#FFB997\"");
  }
  return "";
}

Calendar.prototype.format_data = function(p_day) {
  var vData;
  var vDD = p_day;
  var vMonth = 1 + this.gMonth;
  var vY4 = new String(this.gYear);
  vData = vY4 + "\/" + vMonth + "\/" + vDD;
  return vData;
}

function Build(p_month, p_year) {
  gCal = new Calendar(p_month, p_year);
  gDiv.innerHTML = gCal.show();
}

function Show_Calendar(objDiv, objTxt, strMonth, strYear) {
  if (strMonth == "" || strMonth == null) p_month = new String(gNow.getMonth());
  else p_month = strMonth;
  if (strYear == "" || strYear == null) p_year = new String(gNow.getFullYear().toString());
  else p_year = strYear;

  gDiv = objDiv;
  gTxt = objTxt;

  var objBtn = document.elementFromPoint(window.event.clientX, window.event.clientY);

  if (parent.frs2) {
     intIndex = parent.frs2.cols.indexOf(",");
     intCol = parseFloat(parent.frs2.cols.substring(0, intIndex));
     intFrame = 0;
  } else {
  	intCol = 0;
  	intFrame = -2;
  }

  if (intCol + event.clientX + 200 < screen.availwidth)
     gDiv.style.pixelLeft = event.clientX - GetAbsoluteLeft(objBtn.name) +
       GetAbsoluteLeft(gTxt.name) - event.offsetX - 3 + intFrame;
  else
     gDiv.style.pixelLeft = event.clientX - GetAbsoluteLeft(objBtn.name) +
       GetAbsoluteLeft(gTxt.name) - event.offsetX - 116 + intFrame;

  if (screen.width <= 800) intHeight = 600;
  else intHeight = 768;

  if (event.clientY + 275 < intHeight) gDiv.style.pixelTop = GetAbsoluteTop(gTxt.name) + 23;
  else gDiv.style.pixelTop = GetAbsoluteTop(gTxt.name) - 170;

  Build(p_month, p_year);
  gDiv.style.display = "";
}

function tdDate_onClick(strDay) {
	if (intDataType == 10)
		 gTxt.value = gCal.gYear + "/" + (gCal.gMonth + 1) + "/" + strDay;
  else if (intDataType == 9)
		 gTxt.value = (gCal.gYear - 1911) + "/" + (gCal.gMonth + 1) + "/" + strDay;
  else if (intDataType == 6)
  	 gTxt.value = gCal.gYear * 10000 + (gCal.gMonth + 1) * 100 + parseFloat(strDay);
  else
  	 gTxt.value = ((10000000 + (gCal.gYear - 1911) * 10000 + (gCal.gMonth + 1) * 100 + parseFloat(strDay)).toString()).substring(1, 8);

  gDiv.style.display = "none";
}

function btnCalendar_onBlur(strDiv) {

  var objEvent = window.event;

  if (strDiv == null || strDiv == "") strDiv = "divSubWin";

  if ((objEvent.clientX > 0) && (objEvent.clientY > 0) &&
      (objEvent.clientX < document.body.clientWidth) &&
      (objEvent.clientY < document.body.clientHeight)) {
      var objTmp = document.elementFromPoint(objEvent.clientX, objEvent.clientY);

      while ((objTmp.tagName != "BODY") && (objTmp.id != strDiv))
	    objTmp = objTmp.offsetParent;

      if (objTmp.id == strDiv) return;
  }

  document.getElementById(strDiv).style.display = "none";
}

function btnCalendar_onClick(objTxt, intType) {
// �p�G�t�@�Ӥ������}�ҡA�h�N������
  if (gTxt)
     if (objTxt.name != gTxt.name) divCalendar.style.display = "none";

  if (divCalendar.style.display == "none") {
     strYear = "";
     strMonth = "";

     if (! intType) intDataType = 10;
     else intDataType = intType;

     if (CheckDate(objTxt, intDataType) == 0) {
     	  if (intDataType >= 9) strDate = ChangeDateFormat(objTxt.value, "1");
     	  else strDate = objTxt.value;

        if (strDate.length == 8) {
           strYear = strDate.substring(0, 4);
           strMonth = (parseFloat(strDate.substring(4, 6)) - 1).toString();
        } else {
           strYear = parseFloat(strDate.substring(0, 3)) + 1911;
           strMonth = (parseFloat(strDate.substring(3, 5)) - 1).toString();
        }
     }

     Show_Calendar(divCalendar, objTxt, strMonth, strYear);
  } else divCalendar.style.display = "none";
}