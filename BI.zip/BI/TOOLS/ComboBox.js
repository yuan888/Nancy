function ComboBox_onClick(objBtn) {
  if (objBtn.Init == "false") return;

  var objSlt = document.getElementById("slt" + objBtn.name.substring(3));

  if (objSlt.style.display == "none") {
     objDiv = document.getElementById("div" + objBtn.name.substring(3));
     objSlt.style.width = objDiv.offsetWidth;
     objSlt.options.selectedIndex = -1;
     objSlt.style.display = "";
  } else objSlt.style.display = "none";
}

function ComboBox_onKeyUp(objComboBox) {
  var objTxt = document.getElementById("txt" + objComboBox.name.substring(3));
  var objSlt = document.getElementById("slt" + objComboBox.name.substring(3));

  if (objSlt.style.display == "none") return;
  if (objSlt.length == 0) return;
  if (objTxt.value == "") return;

  intLength = objTxt.value.length;

  for (var intI = 0; intI < objSlt.length; intI++)
      if (objSlt.options[intI].value.substring(0, intLength) == objTxt.value) {
         objSlt.options.selectedIndex = intI;
         return;
      }
}

function ComboBox_onChange(objSlt) {
  var objTxt = document.getElementById("txt" + objSlt.name.substring(3));

  if (objSlt.options.selectedIndex >= 0)
     objTxt.value = objSlt.options[objSlt.options.selectedIndex].text;
  objSlt.style.display = "none";
}

function ComboBox_onBlur(objBtn) {
  var objSlt = document.getElementById("slt" + objBtn.name.substring(3));

  objSlt.style.display = "none";
}