Imports System.Data
Imports System.Data.SqlClient
Imports Yuan

Namespace Sample

Public Class GRID3021
    Inherits System.Web.UI.Page
    Protected WithEvents Message As System.Web.UI.WebControls.Label
    Protected WithEvents btnPreviousPage As System.Web.UI.WebControls.Button
    Protected WithEvents btnNextPage As System.Web.UI.WebControls.Button
    Protected WithEvents grdData As System.Web.UI.WebControls.DataGrid

    Dim objTools As Tools = Tools.GetInstance()

#Region " Web Form �]�p�u�㲣�ͪ��{���X "

    '���I�s�� Web Form �]�p�u�㪺���n���C
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: ����k�I�s�� Web Form �]�p�u�㪺���n��
        '�ФŨϥε{���X�s�边�ӭק復�C
        InitializeComponent()
    End Sub

#End Region
    Dim StartIndex As Integer
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        ' �]�w�����U�u�W�@���v�P�u�U�@���v���s�K���� NavigateToPage �{��
        AddHandler btnPreviousPage.Click, AddressOf NavigateToPage
        AddHandler btnNextPage.Click, AddressOf NavigateToPage

        If Not IsPostBack Then
           StartIndex = 0

           ' �H�U�o�q�{���X�ΨӨ��o��ƪ�����ưO���ƥءA
           ' �ñN�������� DataGrid ����� VirtualItemCount �ݩʡC
           grdData.VirtualItemCount = objTools.GetSqlScalar("select count(*) from bi_pgm")
           BindGridToSource(StartIndex, "�W�@��")
        End If
    End Sub

    Private Sub BindGridToSource(ByVal intStartPos As Integer, ByVal GoToPage As String)

        Dim cnSql As SqlConnection = objTools.GetConn()
        Dim cmdSql As SqlCommand

        Select Case GoToPage
            Case "�W�@��"
                cmdSql = New SqlCommand("select top 5 pgm_id,pgm_name,link_path,upd_date from bi_pgm where pgm_id >= @pgm_id order by pgm_id", cnSql)
                If intStartPos = 0 Then
                    cmdSql.Parameters.Add("@pgm_id", SqlDbType.NVarChar, 12).Value = ""
                Else
                    cmdSql.Parameters.Add("@pgm_id", SqlDbType.NVarChar, 12).Value = ViewState((grdData.CurrentPageIndex + 1).ToString)
                End If
            Case "�U�@��"
                cmdSql = New SqlCommand("select top 5 pgm_id,pgm_name,link_path,upd_date from bi_pgm where pgm_id > @pgm_id order by pgm_id", cnSql)
                cmdSql.Parameters.Add("@pgm_id", SqlDbType.NVarChar, 12).Value = grdData.Items(4).Cells(0).Text
        End Select

        Dim drSql As SqlDataReader = cmdSql.ExecuteReader()
        grdData.DataSource = drSql
        grdData.DataBind()
        drSql.Close()
        cnSql.Close()

        ViewState((grdData.CurrentPageIndex + 1).ToString) = grdData.Items(0).Cells(0).Text
        ShowPageStatus(grdData.VirtualItemCount)
    End Sub

    Private Sub ShowPageStatus(ByVal nRecords As Integer)
        Message.Text = _
        "��ƨӷ��@��<b><FONT color= #ff0000> " & nRecords & " </FONT></b>����ưO���C" & _
        "�`�@��<b><FONT color= #ff0000> " & grdData.PageCount & " </FONT></b>��" & "�A" & _
        "�ثe�O��<b><FONT color= #ff0000> " & (grdData.CurrentPageIndex + 1) & " </FONT></b>���C"
    End Sub

    Private Sub NavigateToPage(ByVal sender As Object, ByVal e As System.EventArgs)
        Dim PageInfo As String = CType(sender, System.Web.UI.WebControls.Button).CommandName
        Select Case PageInfo
            Case "�W�@��"
                If (grdData.CurrentPageIndex > 0) Then
                    grdData.CurrentPageIndex -= 1
                End If
            Case "�U�@��"
                If (grdData.CurrentPageIndex < (grdData.PageCount - 1)) Then
                    grdData.CurrentPageIndex += 1
                Else
                    Return
                End If
        End Select
        StartIndex = grdData.CurrentPageIndex * grdData.PageSize

        ' ���sô���ܸ�ƨӷ�
        BindGridToSource(StartIndex, PageInfo)
    End Sub

End Class
End Namespace