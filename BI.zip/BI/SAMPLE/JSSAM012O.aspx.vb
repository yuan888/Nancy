Namespace Sample
Public Class JSSAM012O
    Inherits System.Web.UI.Page
    Protected WithEvents ltl1 As System.Web.UI.WebControls.Literal
    Protected WithEvents ltl2 As System.Web.UI.WebControls.Literal
    Protected WithEvents txtPgmID As System.Web.UI.WebControls.TextBox
    Protected WithEvents frmOption As System.Web.UI.htmlControls.htmlForm
    Protected WithEvents sltPgmType As System.Web.UI.WebControls.DropDownList

#Region " Web Form �]�p�u�㲣�ͪ��{���X "

    '���I�s�� Web Form �]�p�u�㪺���n���C
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: ����k�I�s�� Web Form �]�p�u�㪺���n��
        '�ФŨϥε{���X�s�边�ӭק復�C
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        If Not IsPostBack Then
            Dim objTools As Yuan.Tools = Yuan.Tools.GetInstance()
            Dim dr As Object
            Dim strSQL As String = "select param_value,param_text from bi_pgm_param " & _
                                   "where param_type='P01' order by param_text"

            dr = objTools.GetReader(strSQL)

            sltPgmType.DataSource = dr
            sltPgmType.DataValueField = "param_value"
            sltPgmType.DataTextField = "param_text"
            sltPgmType.DataBind()
            dr.Close()

            Dim objItem As New System.Web.UI.WebControls.ListItem("ALL", "")
            sltPgmType.Items.Add(objItem)

            frmOption.Attributes.Add("onSubmit", "return frmOption_onSubmit(this)")
            ltl1.Text = "<span class='Text18'><b>" & _
                        Request.QueryString("strPgmName") & _
                        "</b></span>"
            ltl2.Text = "<script> " & _
                        "document.frmOption.action = 'GRID3011P.aspx'; " & _
                        "document.frmOption.__VIEWSTATE.value = ''; " & _
                        "document.frmOption.__VIEWSTATE.name = 'ReName'; " & _
                        "</script>"
        End If

    End Sub

End Class
End Namespace