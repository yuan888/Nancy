Imports Microsoft.VisualBasic
Imports Yuan
Imports BI

Namespace Sample
Public Class GRID2012Q

  Public Sub Process()
    Dim strSQL, strPgmID, strAction, strAryJS, strOraIndex, strSQLIndex, strOp, _
        strOrder, strQPK1, strQPK2, strPPK1, strPPK2 As String
    Dim intPageSize As Integer
    Dim objCC As Object = System.Web.HttpContext.Current
    Dim objTools As Tools = Tools.GetInstance()

    If Not objCC.Request.QueryString("txtPgmID") Is Nothing Then
       strPgmID = objTools.ConvStr(objCC.Request.QueryString("txtPgmID"))
    End If

    intPageSize = CInt(objCC.Request.QueryString("hidPageSize"))

  ' �j�M
    If strPgmID <> "" Then

       If objTools.Database = objTools.DatabaseType.ORACLE Then
          strSQL = "select /*+ index_asc(bi_pgm bi_pgm_pk) */ pgm_id,pgm_name," & _
                   "link_path,pgm_type,author,group_id,order_no,upd_user,upd_date,comm from bi_pgm " & _
                   "where pgm_id like '" & strPgmID & "%' and rownum<=" & _
                   (intPageSize+1).ToString()
       Else
          strSQL = "select top " & (intPageSize+1).ToString() & " pgm_id,pgm_name," & _
                   "link_path,pgm_type,author,group_id,order_no,upd_user,upd_date,comm from bi_pgm " & _
                   "where pgm_id like '" & strPgmID & "%'"
          strOrder = "pgm_id"
       End If

  ' ����
    Else
       Dim intRowNum As Integer = intPageSize + 1

       strAction = objCC.Request.QueryString("strAction")

       If strAction = "First" OrElse strAction = "Next" Then
          strOraIndex = "index_asc"
          strOp = ">"
       Else

          If strAction <> "Refresh" Then
             strOraIndex = "index_desc"
             strSQLIndex = " desc"
             strOp = "<"
           ' �p�G�`���Ƥj�󭶼Ƥj�p�A�h�}�C��h�̫�@�ӡA�̫�}�C�˸m
             strAryJS = "if (intRow > parent.fraMain.intPageSize) {" & vbCrLf & _
                        "intRow--;" & vbCrLf & _
                        "strAryData.length = intRow;" & vbCrLf & _
                        "strAryData = strAryData.reverse();" & vbCrLf & _
                        "intRow++; }" & vbCrLf & _
                        "else strAryData = strAryData.reverse();"
          Else
             strOraIndex = "index_asc"
             strSQLIndex = ""
             strOp = ">="
          End If

          If strAction = "Last" Then
             Dim dr As Object

             strSQL = "select count(*) cnt from bi_pgm"
             dr = objTools.GetReader(strSQL)
             dr.Read()
             intRowNum = dr.Item(0) Mod intPageSize
             If intRowNum = 0 Then intRowNum = intPageSize
             dr.Close()
          End If

       End If

       If objTools.Database = objTools.DatabaseType.ORACLE Then
          strSQL = "select /*+ " & strOraIndex & "(bi_pgm bi_pgm_pk) */ pgm_id,pgm_name," & _
                   "link_path,pgm_type,author,group_id,order_no,upd_user,upd_date,comm from bi_pgm " & _
                   "where rownum<=" & (intRowNum).ToString()
       Else
          strSQL = "select top " & (intRowNum).ToString() & " pgm_id,pgm_name," & _
                   "link_path,pgm_type,author,group_id,order_no,upd_user,upd_date,comm from bi_pgm"
          strOrder = "pgm_id" & strSQLIndex
       End If
     ' �j�M���
       strQPK1 = objCC.Request.QueryString("strQPK1")

       If strQPK1 <> "" Then

          If strSQL.indexOf("where")>0 Then
             strSQL &= " and pgm_id like"
          Else
             strSQL &= " where pgm_id like"
          End If

          strSQL &= " '" & strQPK1 & "%'"
       End If
     ' ½�����
       strPPK1 = objCC.Request.QueryString("strPPK1")

       If strPPK1 <> "" Then

          If strSQL.indexOf("where") > 0 Then
             strSQL &= " and pgm_id"
          Else
             strSQL &= " where pgm_id"
          End If

          strSQL &= strOp & "'" & strPPK1 & "'"
       End If

    End If

    Dim objBackStage As BackStage = BackStage.GetInstance()
'   �p�G½�W���ɡA�o�쪺��Ƶ��Ƶ��Ƥ����@���A�h���s½��Ĥ@��
'   SetTable(1)����]�O�û��u���@�������
    objCC.Response.Write("<html><head>" & vbCrLf & _
      "<meta http-equiv=""Content-Type"" " & _
      "content=""text/html; charset=big5"">" & vbCrLf & _
      "<script language=JavaScript>" & vbCrLf & _
      "parent.fraMain.frmQuery.btnQuery.disabled = false;" & vbCrLf & _
      objBackStage.GetData(strSQL, strOrder, 1) & _
      "if ('Prev'=='" & strAction & "' && intRow < parent.fraMain.intPageSize)" & vbCrLf & _
      "parent.fraMain.btnChgPage_onClick('First', 'GRID2013Q');" & vbCrLf & _
      "else {" & vbCrLf & _
      strAryJS & vbCrLf & _
      "parent.fraMain.intRow = intRow;" & vbCrLf & _
      "parent.fraMain.intCol = intCol;" & vbCrLf & _
      "parent.fraMain.strAryData = strAryData;" & vbCrLf & _
      "parent.fraMain.SetTable(1);" & vbCrLf & _
      "parent.fraMain.divLoadWait.style.display = 'none';" & vbCrLf & _
      "parent.fraMain.divAll.style.display = '';" & vbCrLf & _
      "document.location.href = '../BLANK.htm'; }" & vbCrLf & _
      "</script>" & vbCrLf & _
      "</head><body></body></html>")
  End Sub

End Class
End Namespace