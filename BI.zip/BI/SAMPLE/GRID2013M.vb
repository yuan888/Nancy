Imports Microsoft.VisualBasic
Imports Yuan
Imports BI

Namespace Sample
Public Class GRID2013M

  Public Sub Process()
    Dim strSQL, strAction, strMsg, strJS, strLastJS As String
    Dim objCC As Object = System.Web.HttpContext.Current
    Dim objBackStage As BackStage = BackStage.GetInstance()

    strLastJS = "document.location.href = '../BLANK.htm';"
    strAction = objCC.Request.QueryString("hidAction")

    If objBackStage.ChkUserAuth(strAction) Then
       Dim datNow As Date
       Dim blnCheckOk As Boolean = True
       Dim strPK, strPgmID, strPgmName, strLinkPath, strPgmType, strAuthor , _
           strGroupID, strComm As String
       Dim intOrderNo As Integer
       Dim cn, dr As Object
       Dim objTools As Tools = Tools.GetInstance()

       strPgmID = objTools.ConvStr(objCC.Request.QueryString("txtPgmID1"))
       strGroupID = objTools.ConvStr(objCC.Request.QueryString("txtGroupID"))

       If strAction <> "INS" Then
          strPK = objCC.Request.QueryString("txtPK")
       End If

       If strAction <> "DEL" Then

          If strAction = "INS" Then
             strSQL = "select pgm_id from bi_pgm " & _
                      "where pgm_id='" & strPgmID & "'"
          Else
             strSQL = "select pgm_id from bi_pgm " & _
                      "where pgm_id='" & strPgmID & "' and " & _
                      "pgm_id<>'" & strPK & "'"
          End If

          cn = objTools.GetConn()
          dr = objTools.GetReader(strSQL, cn)

          If dr.HasRows Then
             blnCheckOk = False
             strMsg = "�{���N���w�s�b�I"
          End If

          dr.Close()

          If blnCheckOk AndAlso strGroupID <> "" Then
             strSQL = "select group_id from bi_pgm_group " & _
                      "where group_id='" & strGroupID & "'"
             dr = objTools.GetReader(strSQL, cn)

             If Not dr.Read() Then
                blnCheckOk = False
                strMsg = "�L�����s�եN���I"
             End If

             dr.Close()
          End If

          cn.Close()
       End If

       If Not blnCheckOk Then
          strJS = "parent.fraMain.frmMain.btnSubmit.disabled = false;" & vbCrLf & _
                  "parent.fraMain.frmMain.btnReset.disabled = false;"
       Else
          Dim strOldGroupID, strTransSQL(7) As String
          Dim intOldOrderNo, intSQLCnt As Integer
          Dim blnRunTrans As Boolean =True
          Dim strUserID As String = objBackStage.GetUserID()

          If strAction <> "INS" Then
             strOldGroupID = objTools.ConvStr(objCC.Request.QueryString("hidOldGroupID"))
             intOldOrderNo = CInt(objCC.Request.QueryString("hidOldOrderNo"))
          End If

          If strAction <> "DEL" Then
             strPgmName = objTools.ConvStr(objCC.Request.QueryString("txtPgmName"))
             strLinkPath = objTools.ConvStr(objCC.Request.QueryString("txtLinkPath"))
             strPgmType = objTools.ConvStr(objCC.Request.QueryString("sltPgmType"))
             strAuthor = objTools.ConvStr(objCC.Request.QueryString("sltAuthor"))
             strComm = objTools.ConvComm(objCC.Request.QueryString("txtComm"))

             If objCC.Request.QueryString("txtOrderNo").Trim() <> "" Then
                intOrderNo = CInt(objCC.Request.QueryString("txtOrderNo"))
             Else
                intOrderNo = 0
             End If

             datNow = System.DateTime.Now
             strJS = "parent.fraMain.frmMain.txtUptUser.value = '" & _
                     strUserID & "';" & vbCrlf & _
                     "parent.fraMain.frmMain.txtUptDate.value = '" & _
                     datNow.ToString() & "';" & vbCrlf
          End If

          Select Case strAction
            Case "INS"
              strMsg = "�s�W"
              strTransSQL(0) = "update bi_pgm_group set order_no=order_no+1 " & _
                               "where parent='" & strGroupID & "' and order_no>=" & _
                               intOrderNo.ToString()
              strTransSQL(1) = "update bi_pgm set order_no=order_no+1 " & _
                               "where group_id='" & strGroupID & "' and order_no>=" & _
                               intOrderNo.ToString()
              strTransSQL(2) = "insert into bi_pgm(pgm_id,pgm_name,link_path," & _
                               "pgm_type,author,group_id,order_no,comm,upd_user) " & _
                               "values('" & strPgmID & "','" & _
                               strPgmName & "','" & strLinkPath & "','" & _
                               strPgmType & "','" & strAuthor & "','" & _
                               strGroupID & "'," & intOrderNo.ToString() & ",'" & _
                               strComm & "','" & _
                               strUserID & "')"
              intSQLCnt = 2
              strJS &= "parent.fraMain.Ins_Data();"
            Case "UPD"
              strMsg = "�ק�"
              intSQLCnt = -1

              If strGroupID = strOldGroupID Then '�P�@�s�դ�����

                 If intOrderNo <> intOldOrderNo Then

                    If intOrderNo < intOldOrderNo Then ' ���W��
                       strTransSQL(0) = "update bi_pgm_group set order_no=order_no+1 " & _
                                        "where parent='" & strGroupID & "' and order_no between " & _
                                        intOrderNo.ToString() & " and " & (intOldOrderNo-1).ToString()
                       strTransSQL(1) = "update bi_pgm set order_no=order_no+1 " & _
                                        "where group_id='" & strGroupID & "' and order_no between " & _
                                        intOrderNo.ToString() & " and " & (intOldOrderNo-1).ToString()
                    Else ' ���U��
                       strTransSQL(0) = "update bi_pgm_group set order_no=order_no-1 " & _
                                        "where parent='" & strGroupID & "' and order_no between " & _
                                        (intOldOrderNo+1).ToString() & " and " & intOrderNo.ToString()
                       strTransSQL(1) = "update bi_pgm set order_no=order_no-1 " & _
                                        "where group_id='" & strGroupID & "' and order_no between " & _
                                        (intOldOrderNo+1).ToString() & " and " & intOrderNo.ToString()
                    End If

                    intSQLCnt = 1

                 End If

              Else '���P�s�դ�����
                 strTransSQL(0) = "update bi_pgm_group set order_no=order_no-1 " & _
                                  "where parent='" & strOldGroupID & "' and order_no>" & _
                                  intOldOrderNo.ToString()
                 strTransSQL(1) = "update bi_pgm set order_no=order_no-1 " & _
                                  "where group_id='" & strOldGroupID & "' and order_no>" & _
                                  intOldOrderNo.ToString()
                 strTransSQL(2) = "update bi_pgm_group set order_no=order_no+1 " & _
                                  "where parent='" & strGroupID & "' and order_no>=" & _
                                  intOrderNo.ToString()
                 strTransSQL(3) = "update bi_pgm set order_no=order_no+1 " & _
                                  "where group_id='" & strGroupID & "' and order_no>=" & _
                                  intOrderNo.ToString()
                 intSQLCnt = 3

              End If

              If strPgmID <> strPK AndAlso objTools.Database = objTools.DatabaseType.ORACLE Then
                 intSQLCnt += 1
                 strTransSQL(intSQLCnt) = "insert into bi_pgm(pgm_id,pgm_name,link_path," & _
                                          "pgm_type,author,group_id,order_no,comm,upd_user) " & _
                                          "values('" & strPgmID & "','" & _
                                          strPgmName & "','" & strLinkPath & "','" & _
                                          strPgmType & "','" & strAuthor & "','" & _
                                          strGroupID & "'," & intOrderNo.ToString() & ",'" & _
                                          strComm & "','" & strUserID & "')"
                 intSQLCnt += 1
                 strTransSQL(intSQLCnt) = "update bi_user_auth set pgm_id='" & _
                                          strPgmID & "' where pgm_id='" & _
                                          strPK & "'"
                 intSQLCnt += 1
                 strTransSQL(intSQLCnt) = "delete from bi_pgm where pgm_id='" & strPK & "'"
              Else
                 intSQLCnt += 1
                 strTransSQL(intSQLCnt) = "update bi_pgm set pgm_id='" & strPgmID & _
                                          "',pgm_name='" & strPgmName & _
                                          "',link_path='" & strLinkPath & _
                                          "',pgm_type='" & strPgmType & _
                                          "',author='" & strAuthor & _
                                          "',group_id='" & strGroupID & _
                                          "',order_no=" & intOrderNo.ToString() & _
                                          ",comm='" & strComm & _
                                          "',upd_user='" & strUserID & _
                                          "',upd_date="
                 strTransSQL(intSQLCnt) &= objTools.GetDbDate()
                 strTransSQL(intSQLCnt) &= " where pgm_id='" & strPK & "'"
              End If

              strJS &= "parent.fraMain.frmMain.txtPK.value = '" & _
                       strPgmID & "';" & vbCrlf & _
                       "parent.fraMain.frmMain.hidOldGroupID.value='" & _
                       strGroupID & "';" & vbCrlf & _
                       "parent.fraMain.frmMain.hidOldOrderNo.value='" & _
                       intOrderNo.ToString() & "';" & vbCrlf & _
                       "parent.fraMain.Upd_Data();"
            Case "DEL"
              strMsg = "�R��"
              strTransSQL(0) = "update bi_pgm_group set order_no=order_no-1 " & _
                               "where parent='" & strOldGroupID & "' and order_no>" & _
                               intOldOrderNo.ToString()
              strTransSQL(1) = "update bi_pgm set order_no=order_no-1 " & _
                               "where group_id='" & strOldGroupID & "' and order_no>" & _
                               intOldOrderNo.ToString()
              strTransSQL(2) = "delete from bi_pgm where pgm_id='" & strPK & "'"
              intSQLCnt = 2
              strLastJS = "parent.fraMain.frmMain.reset();" & vbCrLf & _
                          "parent.fraMain.frmMain.hidAction.value= '';" & vbCrLf & _
                          "parent.fraMain.DisableFrmMainText(true);" & vbCrLf & _
                          "parent.fraMain.btnChgPage_onClick('Refresh','GRID2013Q','GRID2011L');"
          End Select

          ReDim Preserve strTransSQL(intSQLCnt)

          If blnRunTrans Then

             If objTools.RunTransaction(strTransSQL) Then
                strMsg &= "�����I"
             Else
                strMsg = "�t�ο��~�A�L�k����" & strMsg & "�C\n\n�Ь��t�κ޲z�̳B�z�I"
                strJS = ""
             End If

          End If

       End If

    Else
       strMsg = "�L�v���@�~�I"
    End If

    objCC.Response.Write("<html><head>" & vbCrLf & _
     "<meta http-equiv=""Content-Type"" " & _
      "content=""text/html; charset=big5"">" & vbCrLf & _
      "<script language=JavaScript>" & vbCrLf & _
      "parent.fraMain.ResetAllBtn();" & vbCrLf & _
      strJs & vbCrLf & _
      "parent.fraMain.frmPage.btnIns.disabled = false;" & vbCrLf & _
      "parent.fraMain.frmQuery.btnQuery.disabled = false;" & vbCrLf & _
      "alert('" & strMsg & "');" & vbCrLf & _
      strLastJS & vbCrLf & _
      "</script>" & vbCrLf & _
      "</head><body></body></html>")
  End Sub

End Class
End Namespace