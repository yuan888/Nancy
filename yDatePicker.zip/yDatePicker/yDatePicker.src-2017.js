﻿(function($) {
  var cal = $("#divYCalendar");
  var ie = (-[1,] ? 0 : (document.documentMode ? document.documentMode : (window.XMLHttpRequest ? 7 : 6)));
  var init = false;
  var lang = {
    today: "今天",   // appears in bottom bar
    wk: "周",
    weekend: "0,6",  // 0 = Sunday, 1 = Monday, etc.
    AM: "AM",
    PM: "PM",
    mn : [ "一月", "二月", "三月", "四月", "五月", "六月", "七月", "八月", "九月", "十月", "十一月", "十二月"],
    wn : [ "日", "一", "二", "三", "四", "五", "六"]
  };

  $.yDatePicker = {
    defaults: {
      titleFormat: "y MMM",
      dateFormat:  "y/M/d",
      firstDayWeek: 1, // first day of week for this locale; 0 = Sunday, 1 = Monday, etc.
      trigger: null,
      defaultDate: null,
      defaultTime: null,
      showTime: false,
      minDate: null,
      maxDate: null,
      imageUrl: "../Images/",
      debug: false
    }
  };

  $.fn.extend({
    yDatePicker: function(options, func) {
      var calDate, popY, fphm, opts = $.extend({}, $.yDatePicker.defaults, options);

      if (opts.imageUrl.substring(opts.imageUrl.length - 1) !== "/") {
        opts.imageUrl += "/";
      }

      if (opts.dateFormat.indexOf("yyy") >= 0 && opts.dateFormat.indexOf("yyyy") < 0 && !options.titleFormat) {
        opts.titleFormat = "yyy MMM";
      }

      if (! init) {
        $("<style type='text/css'>.yCalImgArrow{background-image:url(" + opts.imageUrl + "yDatePicker.gif);}</style>").appendTo("head");
        init = true;
      }

      function parseNum(n) {
        if (n !== "" && ! isNaN(n)) {
          return parseInt(n, 10);
        } else {
          return 0;
        }
      }

      function parseDate(val, fmt) {
        var reg = null, i = 0, chkDate = null;
        val = $.trim(val);

        if (!fmt) fmt = "yMMdd";

        switch (fmt) {
          case "yMMdd":
          case "yyyMMdd":
          case "yyyyMMdd":
            reg = /^(\d{2,4})(\d{2})(\d{2})$/;
            break;
          case "yMMdd HHmm":
          case "yyyMMdd HHmm":
          case "yyyyMMdd HHmm":
            reg = /^(\d{2,4})(\d{2})(\d{2}) (\d{2})(\d{2})$/;
            break;
        }

        if (reg) {
          fmt = fmt.replace("MM", " MM ").replace("HH", "HH ");
          var ary = val.match(reg);
          if (ary !== null) {
            val = "";
            for (i = 1; i <= ary.length - 1; i++) {
              val += ary[i] + " ";
            }
            val = $.trim(val);
          }
        }

        var y = 0, m = -1, d = 0, hr = 0, min = 0, v = val.split(/\W+/), f = fmt.split(/\W+/), j = 0;

        for (i = 0; i < v.length; ++i) {
          if (f[i] === "m" || f[i] === "mm") {
            min = parseNum(v[i]);
          } else if (f[i] === "H" || f[i] === "HH") {
            hr = parseNum(v[i]);
          } else if (f[i] === "d" || f[i] === "dd") {
            d = parseNum(v[i]);
          } else if (f[i] === "M" || f[i] === "MM") {
            m = parseNum(v[i]) - 1;
          } else if (f[i] === "MMM") {
            for (j = 0; j < 12; ++j) {
              if (lang.mn[j].toLowerCase() === v[i].toLowerCase()) { m = j; break; }
            }
          } else if (f[i] === "y" || f[i] === "yy" || f[i] === "yyy" || f[i] === "yyyy") {
            y = parseNum(v[i]);
            if (f[i] !== "yyy") {
              (y < 100) && (y += (y > 29) ? 1900 : 2000);
            } else {
              y += 1911;
            }
          }
        }

        if (y !== 0 && m !== -1 && d !== 0) {
          chkDate = new Date(y, m, d, hr, min, 0);
          if (chkDate.getFullYear() === y && chkDate.getMonth() === m && chkDate.getDate() === d &&
            chkDate.getHours() === hr && chkDate.getMinutes() === min) {
            return chkDate;
          } else {
            chkDate = null;
          }
        }

        y = 0; m = -1; d = 0;

        for (i = 0; i < v.length; ++i) {
          if (v[i].search(/[a-zA-Z]+/) !== -1) {
            var t = -1;
            for (j = 0; j < 12; ++j) {
              if (lang.mn[j].toLowerCase() === v[i].toLowerCase()) { t = j; break; }
            }
            if (t !== -1) {
              if (m !== -1) {
                d = m + 1;
              }
              m = t;
            }
          } else if (parseInt(v[i], 10) <= 12 && m === -1) {
            m = v[i] - 1;
          } else if (parseInt(v[i], 10) > 31 && y === 0) {
            y = parseInt(v[i], 10);

            if (fmt.indexOf("yyy") >= 0 && fmt.indexOf("yyyy") < 0) {
              y += 1911;
            } else {
              (y < 100) && (y += (y > 29) ? 1900 : 2000);
            }
          } else if (d === 0) {
            d = v[i];
          }
        }

        if (y !== 0 && m !== -1 && d !== 0) {
          chkDate = new Date(y, m, d, hr, min, 0);
          if (chkDate.getFullYear() !== y || chkDate.getMonth() !== m || chkDate.getDate() !== d ||
            chkDate.getHours() !== hr || chkDate.getMinutes() !== min) {
            chkDate = null;
          }
        }

        return chkDate;
      }

      function getLimitDate(limit, fmt) {
        var limitDate;

        switch (typeof limit) {
          case "object":
            limitDate = parseDate(limit.value, $(limit).data("dateFormat"));
            break;
          case "string":
            limitDate = parseDate(limit, fmt);
            break;
        }

        return limitDate;
      }

      function printDate(dt, fmt) {
        var min = dt.getMinutes(), hr = dt.getHours(), d = dt.getDate();
        var m = dt.getMonth(), y = dt.getFullYear(), wn = getWeekNum(dt), w = dt.getDay(), s = [];

        s["m"] = min; // minute, range 0 to 59
        s["mm"] = (min < 10) ? ("0" + min) : min; // minute, range 00 to 59
        s["H"] = hr; // hour, range 0 to 23
        s["HH"] = (hr < 10) ? ("0" + hr) : hr; // hour, range 00 to 23
        s["HHmm"] = s["HH"] + "" + s["mm"];
        s["d"] = d;
        s["dd"] = (d < 10) ? ("0" + d) : d;
        s["M"] = 1 + m;
        s["MM"] = (m < 9) ? ("0" + (1 + m)) : (1 + m);
        s["y"] = y;
        s["yy"] = new String(y).substr(2, 2);
        s["yyy"] = y - 1911;
        s["yyyy"] = y;
        s["w"] = wn;
        s["ww"] = (wn < 10) ? ("0" + wn) : wn;
        s["yMMdd"] = s["y"] + "" + s["MM"] + s["dd"];
        s["yyMMdd"] = s["yy"] + "" + s["MM"] + s["dd"];
        s["yyyMMdd"] = s["yyy"] + "" + s["MM"] + s["dd"];
        s["yyyyMMdd"] = s["y"] + "" + s["MM"] + s["dd"];
        s["MMM"] = lang.mn[m];

        fmt = fmt.replace("HHmm", "@" + s["HHmm"]);
        var re = /(.*)(\W|^)(H|HH|m|mm|d|dd|M|MM|y|yy|yyy|yyyy|MMM|Md|Mdd|w|ww|yMMdd|yyMMdd|yyyMMdd|yyyyMMdd)(\W|$)(.*)/;
        while (re.exec(fmt) !== null) {
          fmt = RegExp.$1 + RegExp.$2 + s[RegExp.$3] + RegExp.$4 + RegExp.$5;
        }
        return fmt.replace("@" + s["HHmm"], s["HHmm"]);
      }

      function getWeekNm(i) {
        return "<td" + (lang.weekend.indexOf(i) >= 0 ? " class='yCalWeekend'" : " class='yCalWeekDay'") +
          " width='12.5%' align='right'>" + lang.wn[i] + "</td>";
      }

      function getWeekNum(d) {
        var dayMS = 86400000, now = new Date(d.getFullYear(), d.getMonth(), d.getDate());
        var then = new Date(d.getFullYear(), 0, 1), time = now - then + 1, day = then.getDay();

        day = (day <= 4 ? 7 : 7 - day + 1);
        return Math.round(((time / dayMS) + day) / 7);
      }

      function getWeekTr() {
        var html = "<tr><td width='12.5%' class='yCalWeekF'>" + lang.wk + "</td>";

        for (i = opts.firstDayWeek; i <= 6; i ++) {
          html += getWeekNm(i);
        }

        for (i = 0; i < opts.firstDayWeek; i ++) {
          html += getWeekNm(i);
        }

        return html + "</tr>";
      }

      function setYearMonth(d, f) {
        var t1 = f.split(" ")[0], c = ["yCalTxtY", "yCalTxtM"], v = [d.getFullYear(), d.getMonth() + 1];
        var l = [4, 2], p = [0, 1], w = [24, 28], i;

        if (f.indexOf("yyy") >= 0) {
          l[0] = 3;
          v[0] -= 1911;
        }

        if (f.indexOf("MMM") >= 0) {
           if (ie > 6) { c[1] += " yCalTxtMie7"; }
           v[1] = lang.mn[v[1] - 1] ;
        }

        if (t1.indexOf("y") < 0) {
          p[0] = 1;
          p[1] = 0;
        }

        for (i = 0; i < 2; i++) {
          $(".yCalTitleYM input:eq(" + p[i] + ")")
            .removeClass("yCalTxtY yCalTxtM yCalTxtMie7")
            .addClass(c[i])
            .attr("maxlength", l[i])
            .val(v[i]);
          $(".yCalTitleYM td:eq(" + (p[i] + 2) + ")").attr("width", w[i] + "%");
        }
      }

      function getMonthDays(d) {
        var br = false, t = new Date(d.getFullYear(), d.getMonth(), 1), today = new Date(), tmp, m, cls, i;

        today = new Date(today.getFullYear(), today.getMonth(), today.getDate());
        html = "<div id='divYCal" + d.getFullYear() + (d.getMonth() + 1) + "' style='position:relative;'>" +
          "<table align='center' cellspacing='0' cellpadding='1' border='0' width='92%'>";
        t.setDate(t.getDate() + opts.firstDayWeek - (t.getDay() >= opts.firstDayWeek ? t.getDay() : t.getDay() + 7));

        for (i = 0; i <= 41; i++) {
          if (i % 7 === 0) {
            if (br) { break; }
            html += "<tr height='22'><td width='12.5%' class='yCalWeekF'>" + getWeekNum(t) + "</td>";
          }

          if (t.getMonth() === d.getMonth()) {
            m = "0";
            cls = (lang.weekend.indexOf(t.getDay()) >= 0 ? "yCalWeekend'" : "yCalWeekDay'");
          } else {
            if (t.getMonth() < d.getMonth()) {
              m = (t.getMonth() !== 0 ? "-1" : "+1");
            } else {
              m = (t.getMonth() !== 11 ? "+1" : "-1");
            }
            cls = (lang.weekend.indexOf(t.getDay()) >= 0 ? "yCalWeekendOth'" : "yCalWeekDayOth'");
          }

          if (t.valueOf() === today.valueOf()) { cls = "yCalBodyToday"; }

          html += "<td class='" + cls + "' width='12.5%' align='right'><div class='" +
            (dateCompare(t, false) ? "yCalDay" : "yCalDisabled' disabled='true") + "' m='" + m + "'>" + t.getDate() + "</div></td>";
          t.setDate(t.getDate() + 1);
          if (i % 7 === 6) { html += "</tr>"; }
          if (i >= 27 && t.getMonth() !== d.getMonth()) { br = true; }
        }

        html += "</table></div>";
        return html;
      }

      function setBody(d) {
        $("#divYCalBody")[0].style.height = "100%";
        $("#divYCalBody")[0].innerHTML = getMonthDays(d);
      }

      function setFoot() {
        $(".yCalFootTd").each(function(i) {
          var td;

          if (i === 0) {
             td = $(this);
             var div = td.find("div")[0], cls, dis, t = new Date(), a, w;
             t = new Date(t.getFullYear(), t.getMonth(), t.getDate());

             if (dateCompare(t, false)) {
               div.className = "yCalFootToday";
               div.removeAttribute("disabled");
             } else {
               div.className = "yCalDisabled";
               div.setAttribute("disabled", "true");
             }

             if (opts.showTime) {
                a = "right";
                w = "35%";
             } else {
                a = "center";
                w = "100%";
             }

             td[0].setAttribute("align", a);
             td[0].setAttribute("width", w);
          } else {
            td = $(this);
            var tb = td.find("table")[0];

            if (opts.showTime) {
              tb.style.display = "block";

              td.find("input").each(function(i){
                if (i === 0) {
                  $(this).val(calDate.getHours());
                } else {
                  $(this).val(calDate.getMinutes());
                }
              });
            } else {
              tb.style.display = "none";
            }
          }
        });
      }

      function showCal(t) {
        var p = t.position(), visibleH = document.documentElement.clientHeight;

        if (visibleH === 0) visibleH = document.getElementsByTagName("body")[0].clientHeight;
        if (visibleH === 0) visibleH = window.innerHeight;

        cal[0].style.left = (p.left - (ie >= 8 || ie === 0 ? 2 : 1)).toString() + "px";
        cal[0].style.display = "block";

        if (p.top + t[0].offsetHeight + cal[0].offsetHeight - (document.documentElement.scrollTop + document.body.scrollTop) < visibleH) {
          p.top += t[0].offsetHeight + (ie >= 8 || ie === 0 ? 2 : 0);
        } else {
          p.top -= cal.height() + 2 + (ie >= 8 || ie === 0 ? 2 : 0);
        }

        cal[0].style.top = p.top.toString() + "px";
      }

      function showYCont(divY, f) {
        var y = popY, nY = 0, m = calDate.getMonth(), div = null;

        $(".yCalPopY").unbind();
        divY.find("div").each(function(i) {
          if (i > 9) { return; }
          div = $(this)[0];
          nY = (i % 2 === 0 ? y + i - (i / 2) : y + i + 5 - ((i + 1) / 2));

          if (dateCompare(new Date(nY, m, 1), true)) {
            div.className = "yCalPopY";
            div.removeAttribute("disabled");
          } else {
            div.className = "yCalDisabled";
            div.setAttribute("disabled", "true");
          }

          if (f.indexOf("yyy") >= 0) { nY -= 1911; }
          div.innerHTML = nY;
        });
        $(".yCalPopY").hover(function() { $(this).toggleClass("yCalBorder"); });

        var pY = new Date(popY - 1, 12, 31), pYj = $(".yCalPopPY"), nYj = $(".yCalPopNY");

        nY = new Date(popY + 10, 1, 1);

        if (dateCompare(pY, false)) {
          pYj.removeClass("yCalDisabled");
        } else {
          pYj.addClass("yCalDisabled");
        }

        if (dateCompare(nY, false)) {
          nYj.removeClass("yCalDisabled");
        } else {
          nYj.addClass("yCalDisabled");
        }
      }

      function showMCont(divM) {
        var y = calDate.getFullYear(), m = 0;

        $(".yCalPopM").unbind();
        divM.find("div").each(function(i) {
          m = (i % 2 === 0 ? i - (i / 2) : i + 6 - ((i + 1) / 2));

          if (dateCompare(new Date(y, m, 1), true)) {
            $(this)[0].className = "yCalPopM";
            $(this)[0].removeAttribute("disabled");
          } else {
            $(this)[0].className = "yCalDisabled";
            $(this)[0].setAttribute("disabled", "true");
          }
        });
        $(".yCalPopM").hover(function() { $(this).toggleClass("yCalBorder"); });
      }

      function runMonth(nowM, d) {
        var nowDiv = $(nowM);

        setYearMonth(d, opts.titleFormat);
        nowDiv
          .after(getMonthDays(d).replace("relative;", "relative; top:-" + nowDiv.height() + "; left:" + nowDiv.width() + ";"))
          .animate({left:-(nowDiv.width())}, 200, function() {
            document.getElementById("divYCalBody").removeChild(nowDiv[0]);
          });

        var newDiv = $("#divYCal" + d.getFullYear() + (d.getMonth() + 1));

        $("#divYCalBody").css("height", newDiv.height());

        if (ie >= 7 || ie === 0) {
          newDiv.animate({left: 0}, 200, function(){ $(this).css("top", 0);});
        } else {
          newDiv.css({top: 0, left: 0});
        }
      }

      function imgEvtHandler(clsNm) {
        var t;

        if (clsNm.indexOf("yCalImg") >= 0 || clsNm.indexOf("yCalPopY") >= 0 || clsNm.indexOf("yCalPopM") >= 0) {
          t = new Date(calDate);

          if (clsNm.indexOf("yCalImg1") >= 0) {
            t = new Date(t.getFullYear() - 1, t.getMonth(), 1);
          } else if (clsNm.indexOf("yCalImg2") >= 0) {
            t.setMonth(calDate.getMonth() - 1);
          } else if (clsNm.indexOf("yCalImg3") >= 0) {
            t.setMonth(calDate.getMonth() + 1);
          } else if (clsNm.indexOf("yCalImg4") >= 0) {
            t = new Date(t.getFullYear() + 1, t.getMonth(), 1);
          } else if (clsNm.indexOf("yCalPopY") >= 0) {
            t = new Date(parseFloat(clsNm.replace("yCalPopY", "")), t.getMonth(), 1);
          } else if (clsNm.indexOf("yCalPopM") >= 0) {
            t = new Date(t.getFullYear(), parseFloat(clsNm.replace("yCalPopM", "")), 1);
          }

          if (dateCompare(t, true)) {
            var nowM = "#divYCal" + calDate.getFullYear() + (calDate.getMonth() + 1);

            calDate = t;
            runMonth(nowM, calDate);
          }
        } else if (clsNm.replace("PY", "").replace("NY", "").indexOf("yCalImg") >= 0) {
          t = (clsNm.indexOf("yCalPYImg") >= 0 ? new Date(popY - 1, 12, 31) : new Date(popY + 11, 1, 1));

          if (dateCompare(t, true)) {
            popY += (clsNm.indexOf("yCalPYImg") >= 0 ? -10 : 10);
            showYCont($("#divYCalY"), opts.titleFormat);
          }
        } else if (clsNm.replace("U", "").replace("D", "").indexOf("yCalImg") >= 0) {
          var txtT = $(".yCalTxtTime:eq(" + fphm + ")"), max = (fphm === 0 ? 23 : 59), val = 0;

          if (clsNm.indexOf("yCalUImg") >= 0) {
            val = parseFloat(txtT[0].value) + 1;
          } else {
            val = txtT[0].value = parseFloat(txtT[0].value) - 1;
          }

          if (val > max) {
            val = 0;
          } else if (val === -1) {
            val = max;
          }

          txtT[0].value = val;
        }
      }

      function calClose(cal) {
        $("body").unbind("mousedown");
        $(".yCalTxtYM, .yCalTxtTime").removeClass("yCalBorder").css("cursor", "pointer");
        $(".yCalDivYM, .yCalDivHm").hide();
        cal.hide();
      }

      function dateCompare(d, r) {  //compare to the date of max or min
        var ret = true, dVal = d.valueOf(), maxVal = opts.maxDate.valueOf(), minVal = opts.minDate.valueOf();

        if (! r) {
          if (dVal > maxVal || dVal < minVal) {
            ret = false;
          }
        } else {
          var end = new Date(d), endVal;

          end.setMonth(end.getMonth() + 1);
          end.setDate(end.getDate() - 1);
          endVal = end.valueOf();
          ret = false;

          if (endVal <= maxVal && dVal >= minVal) {
            ret = true;
          } else if (endVal >= maxVal && dVal <= maxVal) {
            ret = true;
          } else if (endVal >= minVal && dVal <= minVal) {
            ret = true;
          } else if (endVal >= maxVal && dVal <= minVal) {
            ret = true;
          }
        }

        return ret;
      }

      function timeCheck(o, d, f) {
        var max = (f === 0 ? 23 : 59);

        if (o.value === "" || parseFloat(o.value) > max) {
           if (f === 0) {
             o.value = d.getHours();
           } else {
             o.value = d.getMinutes();
          }
        }
      }

      function getDefault(cfg, ori) {
        var ret = ori;

        switch (typeof cfg) {
          case "number":
             ret = ori + cfg;
             break;
          case "string":
            if (! isNaN(cfg)) { ret = parseFloat(cfg); }
            break;
        }

        return ret;
      }

      function setTxtData(txt, dt, errCode) {
        var comVal = "";

        if (errCode === "" && dt) {
          comVal = printDate(dt, "yMMddHHmm");
        }

        txt.data("errCode", errCode);
        txt.data("compareVal", comVal);
      }

      function log(msg) {
        if (opts.debug) {
          if (window.console && window.console.log) {
            window.console.log("yDatePicker: " + msg);
          }
        }
      }

      var timeDiff = function(){
        var d, time;

        return {
          setStartTime:function (){
            d = new Date();
            time  = d.getTime();
          },
          getDiff:function (){
            d = new Date();
            return (d.getTime()-time);
          }
        };
      }();

      fphm = 0; // focus position of hour or minute: default hour

      return this.each(function() {
        var txt = $(this), span = null, html = "", clsNm = "", press = null, timer = [];
        var nowTimer = 0, obj = null, imgSrc = opts.imageUrl + "yDatePicker.gif";

        if ($.trim(txt.val()) === "" && (opts.defaultDate !== null || opts.defaultTime !== null)) {
          calDate = new Date();

          if (opts.defaultDate === null) { opts.defaultDate = 0; }
          switch (typeof opts.defaultDate) {
            case "number":
              calDate.setDate(calDate.getDate() + opts.defaultDate);
              break;
            case "object":
              if (typeof opts.defaultDate.getMonth !== "function") {
                calDate = new Date(getDefault(opts.defaultDate.y, calDate.getFullYear()), getDefault(opts.defaultDate.m, calDate.getMonth()), getDefault(opts.defaultDate.d, calDate.getDate()), 0, 0, 0);
              } else {
                calDate = opts.defaultDate;
              }

              break;
          }

          if (opts.showTime) {
            if (opts.defaultTime !== null) {
              calDate.setHours(getDefault(opts.defaultTime.h, calDate.getHours()));
              calDate.setMinutes(getDefault(opts.defaultTime.m, calDate.getMinutes()));
            }
          } else {
            calDate.setHours(0);
            calDate.setMinutes(0);
          }

          txt.val(printDate(calDate, opts.dateFormat));
          setTxtData(txt, calDate, "");
        } else {
          var errCode = "";

          if ($.trim(txt.val()) === "") {
            calDate = null;
            errCode = "empty";
          } else {
            calDate = parseDate(txt.val(), opts.dateFormat);
            if (! calDate) errCode = "format";
          }

          setTxtData(txt, calDate, errCode);
        }

        txt.data("dateFormat", opts.dateFormat);
        obj = txt;

        if (opts.trigger === null) {
          txt.after("<span class='yCalImg yCalImgArrow'></span>");
          span = $(txt[0].nextSibling);

          //If the parent of the text was hidden, show it.
          //Avoid the error of the image's height.
          var parHide = false;

          if (txt.parent().css("display") === "none") {
            parHide = true;
            txt.parent().css("display", "block");
          }

          // align the image to the middle of the text
          span.css({position:"relative",
            top:txt.position().top - span.position().top + (txt.outerHeight() - span.outerHeight()) / 2});

          if (parHide) {
            txt.parent().css("display", "none");
          }

          obj = span;
        } else if (opts.trigger) {
          if (opts.trigger.tagName) {
            obj = $(opts.trigger);
          }
        }

        obj.click({opts: opts, func: func}, function(e) {
          if (opts.debug) { timeDiff.setStartTime(); }

          opts = e.data.opts;
          func = e.data.func;

          if (options) {
            opts.minDate = getLimitDate(options.minDate, opts.dateFormat);
            opts.maxDate = getLimitDate(options.maxDate, opts.dateFormat);
          }

          if (! opts.minDate) { opts.minDate = new Date(1900, 0, 1); }
          if (! opts.maxDate) { opts.maxDate = new Date(2200, 11, 31); }

          calDate = parseDate(txt.val(), opts.dateFormat);
          if (! calDate) { calDate = new Date(); }
          calDate = new Date(calDate.getFullYear(), calDate.getMonth(), 1, calDate.getHours(), calDate.getMinutes(), 0);

          if (! cal[0]) { // only once
            var i;

            html = "<table class='yCalTitleYM' align='center' width='95%' cellspacing='0' cellpadding='1' border='0'><tr height='27'>";
            for (i = 1; i <= 6; i++) {
              if (i <= 2) {
                html += "<td width='12%'><div class='yCalImgYM'><img src='" + imgSrc + "' class='yCalImg" + i + "' /></div></td>";
              } else if (i <= 4) {
                html += "<td width='" + (i === 3 ? 24 : 28) +"%' align='center'><input type='text' class='yCalTxtYM' /></td>";
              } else {
                html += "<td width='12%'><div class='yCalImgYM'><img src='" + imgSrc + "' class='yCalImg" + (i - 2) + "' /></div></td>";
              }
            }
            html += "</tr></table>" +
              "<table class='yCalWeek' align='center' width='92%' cellspacing='0' cellpadding='1' border='0'><tr></tr></table>" +
              "<div id='divYCalBody' class='yCalDiv' style='position:relative;'></div>" +
              "<div id='divYCalFoot' class='yCalDiv'>" +
              "<table class='yCalFoot' width='92%' align='center' cellspacing='0' cellpadding='0' border='0'>" +
              "<tr align='center' valign='bottom' height='28'>" +
              "<td class='yCalFootTd'><div>" + lang.today + "</div></td>" +
              "<td class='yCalFootTd'>" +
              "<table class='yCalBorderTime' cellspacing='0' cellpadding='0'>" +
              "<tr height='19'><td width='37%'><input type='text' class='yCalTxtTime' hm='h' maxlength='2' /></td>" +
              "<td width='7%'>:</td><td width='37%'><input type='text' class='yCalTxtTime' hm='m' maxlength='2' /></td>" +
              "<td width='19%'><table cellspacing='0' cellpadding='0' border='0'>" +
              "<tr><td width=13><div class='yCalUD'><img src='" + imgSrc + "' class='yCalUImg' /></div></td></tr>" +
              "<tr><td width=13><div class='yCalUD'><img src='" + imgSrc + "' class='yCalDImg' /></div></td></tr>" +
              "</table></td></tr></table>" +
              "</td></tr><tr height='3'><td colspan='2'></td></tr></table></div>" +
              "<div id='divYCalY' class='yCalDivYM'>" +
              "<table align='center' width='96%' cellspacing='0' cellpadding='1' border='0'>";

            for (i = 0; i < 5; i ++) {
              html += "<tr height='22' align='center'><td width='50%'><div></div></td>" +
                "<td width='50%'><div></div></td></tr>";
            }

            html += "<tr height='18' align='center'><td><div class='yCalPopPY'><img src='" + imgSrc + "' class='yCalPYImg' /></div></td>" +
              "<td align='center'><div class='yCalPopNY'><img src='" + imgSrc + "' class='yCalNYImg' /></div></td></tr></table></div>" +
              "<div id='divYCalM' class='yCalDivYM'>" +
              "<table align='center' width='96%' cellspacing='0' cellpadding='1' border='0'>";

            for (i = 0; i < 6; i ++) {
              html += "<tr height='22' align='center'><td width='45%'><div>" + lang.mn[i] +
                "</div></td><td width='55%'><div>" + lang.mn[i + 6] + "</div></td></tr>";
            }

            html += "</table></div>" +
              "<div id='divYCalH' class='yCalDivHm'>" +
              "<table width='99%' cellspacing='0' cellpadding='1' border='0'>";

            for (i = 0; i < 24; i ++) {
              html += ((i + 1) % 6 === 1 ? "<tr height='22'>" : "");
              html += "<td><div>" + i + "</div></td>";
              html += ((i + 1) % 6 === 0 ? "</tr>" : "");
            }

            html += "</table></div>" +
              "<div id='divYCalMi' class='yCalDivHm'>" +
              "<table align='center' width='99%' cellspacing='0' cellpadding='0' border='0'>";

            for (i = 0; i < 12; i ++) {
              html += ((i + 1) % 6 === 1 ? "<tr height='22'>" : "");
              html += "<td><div>" + (i * 5) + "</div></td>";
              html += ((i + 1) % 6 === 0 ? "</tr>" : "");
            }

            html += "</table></div>";

            var d = document.createElement("div");

            d.id = "divYCalendar";
            d.className = "yCal";
            d.innerHTML = html;
            document.body.appendChild(d);
            cal = $(d);

            $(".yCalImgYM, .yCalPopPY, .yCalPopNY, .yCalDivHm div").hover(
              function() { $(this).toggleClass("yCalBorder"); });

            $(".yCalTxtYM, .yCalTxtTime")
              .keypress(function(e) {
                var code = (e.keyCode > 0 ? e.keyCode : e.which), codeOk = "8,37,39,46";

                if (codeOk.indexOf(code) < 0 && (code > 57 || code < 48)) {
                  return false;
                }
              })
              .focus(function() {
                this.select();
                return false;
            });

            $(".yCalTxtTime").keydown(function(e) {
              if (e.keyCode === 13 || e.which === 13) {
                var txtHm = $(this);

                txtHm.removeClass("yCalBorder").css("cursor", "pointer");
                $(".yCalDivHm").hide();
                txt.focus();
                timeCheck(txtHm[0], calDate, fphm);
              }
            });

            $(document).on("mouseenter", ".yCalDay, .yCalFootToday", function() {
              $(this).addClass("yCalBorder");
            }).on("mouseleave", ".yCalDay, .yCalFootToday", function() {
              $(this).removeClass("yCalBorder");
            });
          }

          $(".yCalTxtYM").unbind("keydown").keydown(function(e) {
             if (e.keyCode === 13 || e.which === 13) {
               var txtYM = $(this), nowM = "";

               txtYM.removeClass("yCalBorder").css("cursor", "pointer");
               $(".yCalDivYM").hide();
               txt.focus();

               if (parseFloat(txtYM.attr("maxlength")) === 2) {
                 // month text
                 if (isNaN(txtYM.val())) { return; }
                 var m = parseFloat(txtYM.val());

                 if (m > 12 || m < 1) { m = calDate.getMonth() + 1; }

                 if (m !== calDate.getMonth() + 1) {
                   nowM = "#divYCal" + calDate.getFullYear() + (calDate.getMonth() + 1);
                   calDate = new Date(calDate.getFullYear(), m - 1, 1);
                   runMonth(nowM, calDate);
                 }

                 if (opts.titleFormat.indexOf("MMM") >= 0) {
                   txtYM.val(lang.mn[m - 1]);
                 } else {
                   txtYM.val(m);
                 }

               } else {
                 // year text
                 var y = parseFloat(txtYM.val());

                 if (opts.titleFormat.indexOf("yyy") >= 0) { y += 1911; }
                 if (y === calDate.getFullYear()) { return; }

                 if (! dateCompare(new Date(y, calDate.getMonth(), 1), true)) {
                   y = calDate.getFullYear();
                   if (opts.titleFormat.indexOf("yyy") >= 0) { y -= 1911; }
                   txtYM.val(y);
                 } else {
                   nowM = "#divYCal" + calDate.getFullYear() + (calDate.getMonth() + 1);
                   calDate = new Date(y, calDate.getMonth(), 1);
                   runMonth(nowM, calDate);
                 }
               }
             }
          });

          setYearMonth(calDate, opts.titleFormat);
          $(".yCalWeek tr:last").after(getWeekTr()).remove();
          setBody(calDate);
          setFoot();
          showCal(txt);

          $("body").mousedown(function(e) {
            var obj = e.target, tmp = obj;

            clsNm = "";
            for (; tmp !== null && tmp !== cal[0]; tmp = tmp.parentNode) { }
            if (! tmp) {
              calClose(cal);
            } else {
              var imgClick = false;

              clsNm = obj.className;

              if (clsNm.indexOf("yCalDisabled") >= 0) { return; }

              // recover text and hide the popup of year and month
              if (clsNm.indexOf("yCalPYImg") < 0 && clsNm.indexOf("yCalNYImg") < 0) {
                $(".yCalTxtYM, .yCalTxtTime").removeClass("yCalBorder").css("cursor", "pointer");
                $(".yCalDivYM, .yCalDivHm").hide();
                $(".yCalTxtY").val(calDate.getFullYear() - (opts.titleFormat.indexOf("yyy") >= 0 ? 1911 : 0));
                $(".yCalTxtM").val(lang.mn[calDate.getMonth()]);
                if (opts.showTime) { timeCheck($(".yCalTxtTime")[fphm], calDate, fphm); }
              }

              var pos, m, i;

              if (clsNm.indexOf("yCalImgYM") >= 0) {
                //year or month image clicked
                imgClick = true;
                clsNm = obj.innerHTML;
              } else if (clsNm.indexOf("yCalImg") >= 0) {
                //year or month image clicked
                imgClick = true;
              } else if (clsNm.indexOf("yCalTxtYM") >= 0) {
                var txtYM = $(obj);

                pos = txtYM.position();
                txtYM.addClass("yCalBorder").css("cursor", "text");

                if (parseFloat(txtYM.attr("maxlength")) !== 2) {
                  //year text clicked
                  var dY = $("#divYCalY");

                  popY = calDate.getFullYear() - 5;
                  showYCont(dY, opts.titleFormat, popY);
                  dY.css({top: pos.top + txtYM.outerHeight(),
                    left: pos.left - (dY.width() - txtYM.outerWidth()) / 2}).show();
                } else {
                  //month text clicked
                  txtYM.val(calDate.getMonth() + 1);
                  var dM = $("#divYCalM");

                  showMCont(dM);
                  dM.css({top: pos.top + txtYM.outerHeight() + (ie > 6 ? 3 : 0),
                    left: pos.left - (dM.width() - txtYM.outerWidth()) / 2}).show();
                }
              } else if (clsNm.indexOf("yCalDay") >= 0 || clsNm.indexOf("yCalFootToday") >= 0) {
                //day or today clicked
                if (clsNm.indexOf("yCalDay") >= 0) {
                  m = obj.getAttribute("m");

                  if (m === "-1") {
                    calDate.setMonth(calDate.getMonth() - 1);
                  } else if (m === "+1") {
                    calDate.setMonth(calDate.getMonth() + 1);
                  }

                  calDate = new Date(calDate.getFullYear(), calDate.getMonth(), obj.innerHTML);
                } else {
                  calDate = new Date();
                }

                if (opts.showTime) {
                  var h;

                  $(".yCalTxtTime").each(function(i) {
                    if (i === 0) {
                      h = $(this).val();
                    } else {
                      m = $(this).val();
                    }
                  });

                  calDate = new Date(calDate.getFullYear(), calDate.getMonth(), calDate.getDate(), h, m);
                }

                if (typeof func === "function") {
                  if (func(calDate, printDate(calDate, opts.dateFormat))) { txt.val(printDate(calDate, opts.dateFormat)); }
                } else {
                  txt.val(printDate(calDate, opts.dateFormat));
                }

                setTxtData(txt, calDate, "");
                calClose(cal);
              } else if (clsNm.indexOf("yCalPopY") >= 0) {
                //year menu clicked
                $(".yCalTxtY").removeClass("yCalBorder").css("cursor", "pointer");

                if (parseFloat(obj.innerHTML) + (opts.titleFormat.indexOf("yyy") < 0 ? 0 : 1911) !== calDate.getFullYear()) {
                  imgEvtHandler("yCalPopY" + (opts.titleFormat.indexOf("yyy") < 0 ? obj.innerHTML : parseFloat(obj.innerHTML) + 1911));
                }
              } else if (clsNm.indexOf("yCalPopM") >= 0) {
                //month menu clicked
                $(".yCalTxtM").removeClass("yCalBorder").css("cursor", "pointer");

                for (i = 0; i < 12; i++) {
                  if (lang.mn[i].toLowerCase() === obj.innerHTML) { break; }
                }

                if (i !== calDate.getMonth()) {
                  imgEvtHandler("yCalPopM" + i);
                } else {
                  $(".yCalTxtM").val(lang.mn[i]);
                }
              } else if (clsNm.indexOf("yCalPYImg") >= 0 || clsNm.indexOf("yCalNYImg") >= 0) {
                //years move clicked
                if (obj.parentNode.className.indexOf("yCalDisabled") < 0) {
                  imgClick = true;
                }
              } else if (clsNm.indexOf("yCalTxtTime") >= 0) {
                var txtHM = $(obj), div;

                pos = txtHM.position();
                txtHM.addClass("yCalBorder").css("cursor", "text");

                if (obj.getAttribute("hm") === "h") {
                  //hour text clicked
                  div = $("#divYCalH");
                  fphm = 0;
                } else {
                  //minute text clicked
                  div = $("#divYCalMi");
                  fphm = 1;
                }

                div.css({top: pos.top - div.height() - 4,
                  left: pos.left - (div.width() - txtHM.outerWidth()) / 2 - fphm * 5}).show();
              } else if (clsNm.indexOf("yCalUImg") >= 0 || clsNm.indexOf("yCalDImg") >= 0) {
                imgClick = true;
              } else if (clsNm.indexOf("yCalBorder") >= 0) {
                // popup hour or minute clicked
                if (obj.innerHTML.length <= 2) { $(".yCalTxtTime:eq(" + fphm + ")").val(obj.innerHTML); }
//              } else {
//                alert(clsNm);
              }

              if (imgClick) {
                imgEvtHandler(clsNm);

                if (press) {
                   for (i = 0; i < timer.length; i++) {
                     clearInterval(timer.shift());
                   }
                } else {
                  press = obj;
                  $(press).one("mouseup mouseleave", function(e) {
                    $(this).unbind("mouseup mouseleave");
                    press = null;
                    $(this).removeClass("yCalBorder");
                  });
                  timer.push(setInterval(function() {
                    if (press) {
                      imgEvtHandler(clsNm);
                    } else {
                       for (i = 0; i < timer.length; i++) {
                         clearInterval(timer.shift());
                       }
                    }
                  }, 200));
                }
              }
            }
          });

          if (opts.debug) { log("timeDiff=" + timeDiff.getDiff()); }
        });

        txt.blur({opts: opts}, function(e) {
          var opts = e.data.opts, txt = $(this), dt = null, errCode = "";

          if ($.trim(txt.val()) === "") {
            errCode = "empty";
          } else {
            dt = parseDate(txt.val(), opts.dateFormat);

            if (! dt) {
              errCode = "format";
            }
          }

          setTxtData(txt, dt, errCode);
        });
     });
    }
  });
})(jQuery);